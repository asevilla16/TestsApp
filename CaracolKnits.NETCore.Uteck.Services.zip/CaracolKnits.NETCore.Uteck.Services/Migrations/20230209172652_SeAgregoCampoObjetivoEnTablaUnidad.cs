﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CaracolKnits.NETCore.Uteck.Services.Migrations
{
    public partial class SeAgregoCampoObjetivoEnTablaUnidad : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Objective",
                schema: "Commons",
                table: "UnitAdvancement_Transactions",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Objective",
                schema: "Commons",
                table: "UnitAdvancement",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Objective",
                schema: "Commons",
                table: "UnitAdvancement_Transactions");

            migrationBuilder.DropColumn(
                name: "Objective",
                schema: "Commons",
                table: "UnitAdvancement");
        }
    }
}
