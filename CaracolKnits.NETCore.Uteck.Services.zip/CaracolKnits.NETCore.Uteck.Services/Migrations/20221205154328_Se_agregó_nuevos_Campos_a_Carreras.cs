﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CaracolKnits.NETCore.Uteck.Services.Migrations
{
    public partial class Se_agregó_nuevos_Campos_a_Carreras : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "TimeResource",
                schema: "Commons",
                table: "Resource_Transactions",
                newName: "ApprovalRate");

            migrationBuilder.RenameColumn(
                name: "TimeResource",
                schema: "Commons",
                table: "Resource",
                newName: "ApprovalRate");

            migrationBuilder.AddColumn<string>(
                name: "ResourceType",
                schema: "Commons",
                table: "Resource_Transactions",
                type: "nvarchar(10)",
                maxLength: 10,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ResourceType",
                schema: "Commons",
                table: "Resource",
                type: "nvarchar(10)",
                maxLength: 10,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ApprovalRate",
                schema: "Commons",
                table: "Career_Transactions",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<bool>(
                name: "HasFollowUp",
                schema: "Commons",
                table: "Career_Transactions",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<int>(
                name: "QuantityWeeksEnabled",
                schema: "Commons",
                table: "Career_Transactions",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "ApprovalRate",
                schema: "Commons",
                table: "Career",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<bool>(
                name: "HasFollowUp",
                schema: "Commons",
                table: "Career",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<int>(
                name: "QuantityWeeksEnabled",
                schema: "Commons",
                table: "Career",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ResourceType",
                schema: "Commons",
                table: "Resource_Transactions");

            migrationBuilder.DropColumn(
                name: "ResourceType",
                schema: "Commons",
                table: "Resource");

            migrationBuilder.DropColumn(
                name: "ApprovalRate",
                schema: "Commons",
                table: "Career_Transactions");

            migrationBuilder.DropColumn(
                name: "HasFollowUp",
                schema: "Commons",
                table: "Career_Transactions");

            migrationBuilder.DropColumn(
                name: "QuantityWeeksEnabled",
                schema: "Commons",
                table: "Career_Transactions");

            migrationBuilder.DropColumn(
                name: "ApprovalRate",
                schema: "Commons",
                table: "Career");

            migrationBuilder.DropColumn(
                name: "HasFollowUp",
                schema: "Commons",
                table: "Career");

            migrationBuilder.DropColumn(
                name: "QuantityWeeksEnabled",
                schema: "Commons",
                table: "Career");

            migrationBuilder.RenameColumn(
                name: "ApprovalRate",
                schema: "Commons",
                table: "Resource_Transactions",
                newName: "TimeResource");

            migrationBuilder.RenameColumn(
                name: "ApprovalRate",
                schema: "Commons",
                table: "Resource",
                newName: "TimeResource");
        }
    }
}
