﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CaracolKnits.NETCore.Uteck.Services.Migrations
{
    public partial class CambiandoEsquemalatablaposition : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameTable(
                name: "Position_Transactions",
                newName: "Position_Transactions",
                newSchema: "Commons");

            migrationBuilder.RenameTable(
                name: "Position",
                newName: "Position",
                newSchema: "Commons");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameTable(
                name: "Position_Transactions",
                schema: "Commons",
                newName: "Position_Transactions");

            migrationBuilder.RenameTable(
                name: "Position",
                schema: "Commons",
                newName: "Position");
        }
    }
}
