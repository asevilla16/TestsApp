﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CaracolKnits.NETCore.Uteck.Services.Migrations
{
    public partial class SeCambioNombredeCamposSeSeguimientoOscar : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "ApprovalRate",
                schema: "Commons",
                table: "Unit_Transactions",
                newName: "NotaAprobacion");

            migrationBuilder.RenameColumn(
                name: "ApprovalRate",
                schema: "Commons",
                table: "Unit",
                newName: "NotaAprobacion");

            migrationBuilder.RenameColumn(
                name: "OSCARSeguimiento",
                schema: "Commons",
                table: "Career_Transactions",
                newName: "OscarSeguimiento");

            migrationBuilder.RenameColumn(
                name: "OSCARSeguimiento",
                schema: "Commons",
                table: "Career",
                newName: "OscarSeguimiento");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "NotaAprobacion",
                schema: "Commons",
                table: "Unit_Transactions",
                newName: "ApprovalRate");

            migrationBuilder.RenameColumn(
                name: "NotaAprobacion",
                schema: "Commons",
                table: "Unit",
                newName: "ApprovalRate");

            migrationBuilder.RenameColumn(
                name: "OscarSeguimiento",
                schema: "Commons",
                table: "Career_Transactions",
                newName: "OSCARSeguimiento");

            migrationBuilder.RenameColumn(
                name: "OscarSeguimiento",
                schema: "Commons",
                table: "Career",
                newName: "OSCARSeguimiento");
        }
    }
}
