﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CaracolKnits.NETCore.Uteck.Services.Migrations
{
    public partial class Se_Modifico_Nombre_de_Campo_de_Configuraciones : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Valor",
                schema: "Commons",
                table: "Configuration_Transactions",
                newName: "Value");

            migrationBuilder.RenameColumn(
                name: "Valor",
                schema: "Commons",
                table: "Configuration",
                newName: "Value");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Value",
                schema: "Commons",
                table: "Configuration_Transactions",
                newName: "Valor");

            migrationBuilder.RenameColumn(
                name: "Value",
                schema: "Commons",
                table: "Configuration",
                newName: "Valor");
        }
    }
}
