﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CaracolKnits.NETCore.Uteck.Services.Migrations
{
    public partial class SeCorrigioCampoQuestionTypeId : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
        


            migrationBuilder.RenameColumn(
                name: "QuestionType ",
                schema: "Commons",
                table: "Question_Transactions",
                newName: "QuestionType");

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "QuestionType_Transactions",
                schema: "Commons");

            migrationBuilder.RenameColumn(
                name: "QuestionType",
                schema: "Commons",
                table: "Question_Transactions",
                newName: "QuestionType ");

            migrationBuilder.AddColumn<int>(
                name: "FacilityId",
                schema: "Commons",
                table: "Question",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "Name",
                schema: "Commons",
                table: "Question",
                type: "nvarchar(250)",
                maxLength: 250,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "PositionJob",
                schema: "Commons",
                table: "Question",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: false,
                defaultValue: "");
        }
    }
}
