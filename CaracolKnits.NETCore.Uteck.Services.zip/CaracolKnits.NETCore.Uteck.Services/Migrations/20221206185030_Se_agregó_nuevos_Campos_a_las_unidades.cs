﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CaracolKnits.NETCore.Uteck.Services.Migrations
{
    public partial class Se_agregó_nuevos_Campos_a_las_unidades : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ApprovalRate",
                schema: "Commons",
                table: "Unit_Transactions",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "ApprovalRate",
                schema: "Commons",
                table: "Unit",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ApprovalRate",
                schema: "Commons",
                table: "Unit_Transactions");

            migrationBuilder.DropColumn(
                name: "ApprovalRate",
                schema: "Commons",
                table: "Unit");
        }
    }
}
