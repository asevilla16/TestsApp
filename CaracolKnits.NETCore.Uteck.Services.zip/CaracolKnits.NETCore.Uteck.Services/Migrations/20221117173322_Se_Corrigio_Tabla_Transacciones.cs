﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CaracolKnits.NETCore.Uteck.Services.Migrations
{
    public partial class Se_Corrigio_Tabla_Transacciones : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Code",
                schema: "Commons",
                table: "User_Transactions");

            migrationBuilder.DropColumn(
                name: "Type",
                schema: "Commons",
                table: "Configuration_Transactions");

            migrationBuilder.AddColumn<string>(
                name: "EmailAddress",
                schema: "Commons",
                table: "User_Transactions",
                type: "nvarchar(200)",
                maxLength: 200,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "LanguageId",
                schema: "Commons",
                table: "User_Transactions",
                type: "nvarchar(2)",
                maxLength: 2,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "UserName",
                schema: "Commons",
                table: "User_Transactions",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "EmailAddress",
                schema: "Commons",
                table: "User_Transactions");

            migrationBuilder.DropColumn(
                name: "LanguageId",
                schema: "Commons",
                table: "User_Transactions");

            migrationBuilder.DropColumn(
                name: "UserName",
                schema: "Commons",
                table: "User_Transactions");

            migrationBuilder.AddColumn<int>(
                name: "Code",
                schema: "Commons",
                table: "User_Transactions",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "Type",
                schema: "Commons",
                table: "Configuration_Transactions",
                type: "nvarchar(150)",
                maxLength: 150,
                nullable: false,
                defaultValue: "");
        }
    }
}
