﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CaracolKnits.NETCore.Uteck.Services.Migrations
{
    public partial class SeAgregoCampoPAraRegistrarNotaTotalEnCarreras : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UnitAdvancement_Career_CareerId",
                schema: "Commons",
                table: "UnitAdvancement");

            migrationBuilder.DropForeignKey(
                name: "FK_UnitAdvancement_CareerAdvancement_CareerAdvancementId",
                schema: "Commons",
                table: "UnitAdvancement");

            migrationBuilder.DropIndex(
                name: "IX_UnitAdvancement_CareerId",
                schema: "Commons",
                table: "UnitAdvancement");

            migrationBuilder.DropColumn(
                name: "CareerId",
                schema: "Commons",
                table: "UnitAdvancement");

            migrationBuilder.RenameColumn(
                name: "CareerId",
                schema: "Commons",
                table: "UnitAdvancement_Transactions",
                newName: "CareerAdvancementId");

            migrationBuilder.AlterColumn<int>(
                name: "CareerAdvancementId",
                schema: "Commons",
                table: "UnitAdvancement",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddColumn<int>(
                name: "TotalScore",
                schema: "Commons",
                table: "CareerAdvancement_Transactions",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "TotalScore",
                schema: "Commons",
                table: "CareerAdvancement",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddForeignKey(
                name: "FK_UnitAdvancement_CareerAdvancement_CareerAdvancementId",
                schema: "Commons",
                table: "UnitAdvancement",
                column: "CareerAdvancementId",
                principalSchema: "Commons",
                principalTable: "CareerAdvancement",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UnitAdvancement_CareerAdvancement_CareerAdvancementId",
                schema: "Commons",
                table: "UnitAdvancement");

            migrationBuilder.DropColumn(
                name: "TotalScore",
                schema: "Commons",
                table: "CareerAdvancement_Transactions");

            migrationBuilder.DropColumn(
                name: "TotalScore",
                schema: "Commons",
                table: "CareerAdvancement");

            migrationBuilder.RenameColumn(
                name: "CareerAdvancementId",
                schema: "Commons",
                table: "UnitAdvancement_Transactions",
                newName: "CareerId");

            migrationBuilder.AlterColumn<int>(
                name: "CareerAdvancementId",
                schema: "Commons",
                table: "UnitAdvancement",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<int>(
                name: "CareerId",
                schema: "Commons",
                table: "UnitAdvancement",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_UnitAdvancement_CareerId",
                schema: "Commons",
                table: "UnitAdvancement",
                column: "CareerId");

            migrationBuilder.AddForeignKey(
                name: "FK_UnitAdvancement_Career_CareerId",
                schema: "Commons",
                table: "UnitAdvancement",
                column: "CareerId",
                principalSchema: "Commons",
                principalTable: "Career",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_UnitAdvancement_CareerAdvancement_CareerAdvancementId",
                schema: "Commons",
                table: "UnitAdvancement",
                column: "CareerAdvancementId",
                principalSchema: "Commons",
                principalTable: "CareerAdvancement",
                principalColumn: "Id");
        }
    }
}
