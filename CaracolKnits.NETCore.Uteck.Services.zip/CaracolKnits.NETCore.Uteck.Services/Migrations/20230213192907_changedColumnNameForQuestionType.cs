﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CaracolKnits.NETCore.Uteck.Services.Migrations
{
    public partial class changedColumnNameForQuestionType : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Question_QuestionType_QuestionType ",
                schema: "Commons",
                table: "Question");

            migrationBuilder.RenameColumn(
                name: "QuestionType ",
                schema: "Commons",
                table: "Question",
                newName: "QuestionTypeId");

            migrationBuilder.RenameIndex(
                name: "IX_Question_QuestionType ",
                schema: "Commons",
                table: "Question",
                newName: "IX_Question_QuestionTypeId");

            migrationBuilder.AddForeignKey(
                name: "FK_Question_QuestionType_QuestionTypeId",
                schema: "Commons",
                table: "Question",
                column: "QuestionTypeId",
                principalSchema: "Commons",
                principalTable: "QuestionType",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Question_QuestionType_QuestionTypeId",
                schema: "Commons",
                table: "Question");

            migrationBuilder.RenameColumn(
                name: "QuestionTypeId",
                schema: "Commons",
                table: "Question",
                newName: "QuestionType ");

            migrationBuilder.RenameIndex(
                name: "IX_Question_QuestionTypeId",
                schema: "Commons",
                table: "Question",
                newName: "IX_Question_QuestionType ");

            migrationBuilder.AddForeignKey(
                name: "FK_Question_QuestionType_QuestionType ",
                schema: "Commons",
                table: "Question",
                column: "QuestionType ",
                principalSchema: "Commons",
                principalTable: "QuestionType",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
