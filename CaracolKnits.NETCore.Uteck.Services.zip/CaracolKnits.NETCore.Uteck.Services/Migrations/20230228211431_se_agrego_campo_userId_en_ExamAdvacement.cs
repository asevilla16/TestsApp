﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CaracolKnits.NETCore.Uteck.Services.Migrations
{
    public partial class se_agrego_campo_userId_en_ExamAdvacement : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_ExamAdvancement_UnitAdvancementId",
                schema: "Commons",
                table: "ExamAdvancement");

            migrationBuilder.AddColumn<int>(
                name: "UnitAdvancementId",
                schema: "Commons",
                table: "ExamAdvancement_Transactions",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "UserId",
                schema: "Commons",
                table: "ExamAdvancement_Transactions",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "UserId",
                schema: "Commons",
                table: "ExamAdvancement",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_ExamAdvancement_UnitAdvancementId",
                schema: "Commons",
                table: "ExamAdvancement",
                column: "UnitAdvancementId",
                unique: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_ExamAdvancement_UnitAdvancementId",
                schema: "Commons",
                table: "ExamAdvancement");

            migrationBuilder.DropColumn(
                name: "UnitAdvancementId",
                schema: "Commons",
                table: "ExamAdvancement_Transactions");

            migrationBuilder.DropColumn(
                name: "UserId",
                schema: "Commons",
                table: "ExamAdvancement_Transactions");

            migrationBuilder.DropColumn(
                name: "UserId",
                schema: "Commons",
                table: "ExamAdvancement");

            migrationBuilder.CreateIndex(
                name: "IX_ExamAdvancement_UnitAdvancementId",
                schema: "Commons",
                table: "ExamAdvancement",
                column: "UnitAdvancementId");
        }
    }
}
