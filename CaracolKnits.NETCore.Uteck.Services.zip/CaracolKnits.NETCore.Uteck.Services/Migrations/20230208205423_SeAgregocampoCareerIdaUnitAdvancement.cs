﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CaracolKnits.NETCore.Uteck.Services.Migrations
{
    public partial class SeAgregocampoCareerIdaUnitAdvancement : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "CareerId",
                schema: "Commons",
                table: "UnitAdvancement_Transactions",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "CareerId",
                schema: "Commons",
                table: "UnitAdvancement",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CareerId",
                schema: "Commons",
                table: "UnitAdvancement_Transactions");

            migrationBuilder.DropColumn(
                name: "CareerId",
                schema: "Commons",
                table: "UnitAdvancement");
        }
    }
}
