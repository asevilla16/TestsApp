﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CaracolKnits.NETCore.Uteck.Services.Migrations
{
    public partial class Se_agregórelacióncarreraplanta : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "FacilityId",
                schema: "Commons",
                table: "Career_Transactions",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "FacilityId",
                schema: "Commons",
                table: "Career",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Career_FacilityId",
                schema: "Commons",
                table: "Career",
                column: "FacilityId");

            migrationBuilder.AddForeignKey(
                name: "FK_Career_Facility_FacilityId",
                schema: "Commons",
                table: "Career",
                column: "FacilityId",
                principalSchema: "Commons",
                principalTable: "Facility",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Career_Facility_FacilityId",
                schema: "Commons",
                table: "Career");

            migrationBuilder.DropIndex(
                name: "IX_Career_FacilityId",
                schema: "Commons",
                table: "Career");

            migrationBuilder.DropColumn(
                name: "FacilityId",
                schema: "Commons",
                table: "Career_Transactions");

            migrationBuilder.DropColumn(
                name: "FacilityId",
                schema: "Commons",
                table: "Career");
        }
    }
}
