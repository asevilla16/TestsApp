﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CaracolKnits.NETCore.Uteck.Services.Migrations
{
    public partial class SeAgregoCampoNameResouceAdvancement : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Resource",
                schema: "Commons",
                table: "ResourceAdvancement_Transactions",
                type: "nvarchar(150)",
                maxLength: 150,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Resource",
                schema: "Commons",
                table: "ResourceAdvancement",
                type: "nvarchar(150)",
                maxLength: 150,
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Resource",
                schema: "Commons",
                table: "ResourceAdvancement_Transactions");

            migrationBuilder.DropColumn(
                name: "Resource",
                schema: "Commons",
                table: "ResourceAdvancement");
        }
    }
}
