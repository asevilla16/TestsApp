﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CaracolKnits.NETCore.Uteck.Services.Migrations
{
    public partial class SeAgregoCampoUserIdResouceAdvanceme : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "CareerAdvancementId",
                schema: "Commons",
                table: "ResourceAdvancement_Transactions",
                newName: "UnitAdvancementId");

            migrationBuilder.AddColumn<int>(
                name: "TimeResource",
                schema: "Commons",
                table: "ResourceAdvancement_Transactions",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "TimeResource",
                schema: "Commons",
                table: "ResourceAdvancement_Transactions");

            migrationBuilder.RenameColumn(
                name: "UnitAdvancementId",
                schema: "Commons",
                table: "ResourceAdvancement_Transactions",
                newName: "CareerAdvancementId");
        }
    }
}
