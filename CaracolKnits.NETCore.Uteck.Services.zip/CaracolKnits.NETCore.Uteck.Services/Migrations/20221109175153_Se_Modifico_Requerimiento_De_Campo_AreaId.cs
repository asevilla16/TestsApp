﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CaracolKnits.NETCore.Uteck.Services.Migrations
{
    public partial class Se_Modifico_Requerimiento_De_Campo_AreaId : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_User_Area_AreaId",
                schema: "Commons",
                table: "User");

            migrationBuilder.AlterColumn<int>(
                name: "AreaId",
                schema: "Commons",
                table: "User",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddForeignKey(
                name: "FK_User_Area_AreaId",
                schema: "Commons",
                table: "User",
                column: "AreaId",
                principalSchema: "Commons",
                principalTable: "Area",
                principalColumn: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_User_Area_AreaId",
                schema: "Commons",
                table: "User");

            migrationBuilder.AlterColumn<int>(
                name: "AreaId",
                schema: "Commons",
                table: "User",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_User_Area_AreaId",
                schema: "Commons",
                table: "User",
                column: "AreaId",
                principalSchema: "Commons",
                principalTable: "Area",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
