﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CaracolKnits.NETCore.Uteck.Services.Migrations
{
    public partial class Secambiócamposenlatablacarreras : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "HasFollowUp",
                schema: "Commons",
                table: "Career_Transactions");

            migrationBuilder.DropColumn(
                name: "HasFollowUp",
                schema: "Commons",
                table: "Career");

            migrationBuilder.RenameColumn(
                name: "QuantityWeeksEnabled",
                schema: "Commons",
                table: "Career_Transactions",
                newName: "OSCARSeguimiento");

            migrationBuilder.RenameColumn(
                name: "ApprovalRate",
                schema: "Commons",
                table: "Career_Transactions",
                newName: "NotaAprobacion");

            migrationBuilder.RenameColumn(
                name: "QuantityWeeksEnabled",
                schema: "Commons",
                table: "Career",
                newName: "OSCARSeguimiento");

            migrationBuilder.RenameColumn(
                name: "ApprovalRate",
                schema: "Commons",
                table: "Career",
                newName: "NotaAprobacion");

            migrationBuilder.AddColumn<string>(
                name: "UserFullName",
                schema: "Commons",
                table: "CareerAdvancement_Transactions",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "UserName",
                schema: "Commons",
                table: "CareerAdvancement_Transactions",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "UserFullName",
                schema: "Commons",
                table: "CareerAdvancement",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "UserName",
                schema: "Commons",
                table: "CareerAdvancement",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "NoSemanas",
                schema: "Commons",
                table: "Career_Transactions",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "NoSemanas",
                schema: "Commons",
                table: "Career",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "UserFullName",
                schema: "Commons",
                table: "CareerAdvancement_Transactions");

            migrationBuilder.DropColumn(
                name: "UserName",
                schema: "Commons",
                table: "CareerAdvancement_Transactions");

            migrationBuilder.DropColumn(
                name: "UserFullName",
                schema: "Commons",
                table: "CareerAdvancement");

            migrationBuilder.DropColumn(
                name: "UserName",
                schema: "Commons",
                table: "CareerAdvancement");

            migrationBuilder.DropColumn(
                name: "NoSemanas",
                schema: "Commons",
                table: "Career_Transactions");

            migrationBuilder.DropColumn(
                name: "NoSemanas",
                schema: "Commons",
                table: "Career");

            migrationBuilder.RenameColumn(
                name: "OSCARSeguimiento",
                schema: "Commons",
                table: "Career_Transactions",
                newName: "QuantityWeeksEnabled");

            migrationBuilder.RenameColumn(
                name: "NotaAprobacion",
                schema: "Commons",
                table: "Career_Transactions",
                newName: "ApprovalRate");

            migrationBuilder.RenameColumn(
                name: "OSCARSeguimiento",
                schema: "Commons",
                table: "Career",
                newName: "QuantityWeeksEnabled");

            migrationBuilder.RenameColumn(
                name: "NotaAprobacion",
                schema: "Commons",
                table: "Career",
                newName: "ApprovalRate");

            migrationBuilder.AddColumn<bool>(
                name: "HasFollowUp",
                schema: "Commons",
                table: "Career_Transactions",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "HasFollowUp",
                schema: "Commons",
                table: "Career",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }
    }
}
