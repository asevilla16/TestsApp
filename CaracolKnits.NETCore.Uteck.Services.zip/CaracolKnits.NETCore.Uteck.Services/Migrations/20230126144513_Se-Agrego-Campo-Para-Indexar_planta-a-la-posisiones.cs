﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CaracolKnits.NETCore.Uteck.Services.Migrations
{
    public partial class SeAgregoCampoParaIndexar_plantaalaposisiones : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "FacilityId",
                schema: "Commons",
                table: "Position_Transactions",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "FacilityId",
                schema: "Commons",
                table: "Position",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Position_FacilityId",
                schema: "Commons",
                table: "Position",
                column: "FacilityId");

            migrationBuilder.AddForeignKey(
                name: "FK_Position_Facility_FacilityId",
                schema: "Commons",
                table: "Position",
                column: "FacilityId",
                principalSchema: "Commons",
                principalTable: "Facility",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Position_Facility_FacilityId",
                schema: "Commons",
                table: "Position");

            migrationBuilder.DropIndex(
                name: "IX_Position_FacilityId",
                schema: "Commons",
                table: "Position");

            migrationBuilder.DropColumn(
                name: "FacilityId",
                schema: "Commons",
                table: "Position_Transactions");

            migrationBuilder.DropColumn(
                name: "FacilityId",
                schema: "Commons",
                table: "Position");
        }
    }
}
