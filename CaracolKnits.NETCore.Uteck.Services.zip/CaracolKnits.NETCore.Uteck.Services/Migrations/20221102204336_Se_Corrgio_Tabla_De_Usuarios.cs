﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CaracolKnits.NETCore.Uteck.Services.Migrations
{
    public partial class Se_Corrgio_Tabla_De_Usuarios : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "FirstLastName",
                schema: "Commons",
                table: "User_Transactions");

            migrationBuilder.DropColumn(
                name: "SecondLastName",
                schema: "Commons",
                table: "User_Transactions");

            migrationBuilder.DropColumn(
                name: "SecondName",
                schema: "Commons",
                table: "User_Transactions");

            migrationBuilder.DropColumn(
                name: "FirstLastName",
                schema: "Commons",
                table: "User");

            migrationBuilder.DropColumn(
                name: "SecondLastName",
                schema: "Commons",
                table: "User");

            migrationBuilder.DropColumn(
                name: "SecondName",
                schema: "Commons",
                table: "User");

            migrationBuilder.RenameColumn(
                name: "FirstName",
                schema: "Commons",
                table: "User_Transactions",
                newName: "FullName");

            migrationBuilder.RenameColumn(
                name: "FirstName",
                schema: "Commons",
                table: "User",
                newName: "FullName");

            migrationBuilder.AddColumn<string>(
                name: "Password",
                schema: "Commons",
                table: "User_Transactions",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Password",
                schema: "Commons",
                table: "User",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Password",
                schema: "Commons",
                table: "User_Transactions");

            migrationBuilder.DropColumn(
                name: "Password",
                schema: "Commons",
                table: "User");

            migrationBuilder.RenameColumn(
                name: "FullName",
                schema: "Commons",
                table: "User_Transactions",
                newName: "FirstName");

            migrationBuilder.RenameColumn(
                name: "FullName",
                schema: "Commons",
                table: "User",
                newName: "FirstName");

            migrationBuilder.AddColumn<string>(
                name: "FirstLastName",
                schema: "Commons",
                table: "User_Transactions",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "SecondLastName",
                schema: "Commons",
                table: "User_Transactions",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "SecondName",
                schema: "Commons",
                table: "User_Transactions",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "FirstLastName",
                schema: "Commons",
                table: "User",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "SecondLastName",
                schema: "Commons",
                table: "User",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "SecondName",
                schema: "Commons",
                table: "User",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true);
        }
    }
}
