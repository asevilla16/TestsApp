﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CaracolKnits.NETCore.Uteck.Services.Migrations
{
    public partial class Seagregocamposparalearchivoenrecursos : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "FileExtension",
                schema: "Commons",
                table: "Resource_Transactions",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "FileName",
                schema: "Commons",
                table: "Resource_Transactions",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "FileExtension",
                schema: "Commons",
                table: "Resource",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "FileName",
                schema: "Commons",
                table: "Resource",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "FileExtension",
                schema: "Commons",
                table: "Resource_Transactions");

            migrationBuilder.DropColumn(
                name: "FileName",
                schema: "Commons",
                table: "Resource_Transactions");

            migrationBuilder.DropColumn(
                name: "FileExtension",
                schema: "Commons",
                table: "Resource");

            migrationBuilder.DropColumn(
                name: "FileName",
                schema: "Commons",
                table: "Resource");
        }
    }
}
