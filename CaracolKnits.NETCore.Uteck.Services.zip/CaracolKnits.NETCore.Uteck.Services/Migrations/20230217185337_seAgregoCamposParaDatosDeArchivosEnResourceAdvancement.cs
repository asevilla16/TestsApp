﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CaracolKnits.NETCore.Uteck.Services.Migrations
{
    public partial class seAgregoCamposParaDatosDeArchivosEnResourceAdvancement : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "FileExtension",
                schema: "Commons",
                table: "ResourceAdvancement_Transactions",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "FileName",
                schema: "Commons",
                table: "ResourceAdvancement_Transactions",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "ItemId",
                schema: "Commons",
                table: "ResourceAdvancement_Transactions",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "ResourceType",
                schema: "Commons",
                table: "ResourceAdvancement_Transactions",
                type: "nvarchar(10)",
                maxLength: 10,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "FileExtension",
                schema: "Commons",
                table: "ResourceAdvancement",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "FileName",
                schema: "Commons",
                table: "ResourceAdvancement",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "ItemId",
                schema: "Commons",
                table: "ResourceAdvancement",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "ResourceType",
                schema: "Commons",
                table: "ResourceAdvancement",
                type: "nvarchar(10)",
                maxLength: 10,
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "FileExtension",
                schema: "Commons",
                table: "ResourceAdvancement_Transactions");

            migrationBuilder.DropColumn(
                name: "FileName",
                schema: "Commons",
                table: "ResourceAdvancement_Transactions");

            migrationBuilder.DropColumn(
                name: "ItemId",
                schema: "Commons",
                table: "ResourceAdvancement_Transactions");

            migrationBuilder.DropColumn(
                name: "ResourceType",
                schema: "Commons",
                table: "ResourceAdvancement_Transactions");

            migrationBuilder.DropColumn(
                name: "FileExtension",
                schema: "Commons",
                table: "ResourceAdvancement");

            migrationBuilder.DropColumn(
                name: "FileName",
                schema: "Commons",
                table: "ResourceAdvancement");

            migrationBuilder.DropColumn(
                name: "ItemId",
                schema: "Commons",
                table: "ResourceAdvancement");

            migrationBuilder.DropColumn(
                name: "ResourceType",
                schema: "Commons",
                table: "ResourceAdvancement");
        }
    }
}
