﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CaracolKnits.NETCore.Uteck.Services.Migrations
{
    public partial class Sequitopromedioderecurso : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ApprovalRate",
                schema: "Commons",
                table: "Resource_Transactions");

            migrationBuilder.DropColumn(
                name: "ApprovalRate",
                schema: "Commons",
                table: "Resource");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ApprovalRate",
                schema: "Commons",
                table: "Resource_Transactions",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "ApprovalRate",
                schema: "Commons",
                table: "Resource",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
