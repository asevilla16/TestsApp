﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CaracolKnits.NETCore.Uteck.Services.Migrations
{
    public partial class se_agrego_campo_conexion_entre_examen_y_unidad : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_ExamAdvancement_UnitAdvancementId",
                schema: "Commons",
                table: "ExamAdvancement");

            migrationBuilder.CreateIndex(
                name: "IX_ExamAdvancement_UnitAdvancementId",
                schema: "Commons",
                table: "ExamAdvancement",
                column: "UnitAdvancementId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_ExamAdvancement_UnitAdvancementId",
                schema: "Commons",
                table: "ExamAdvancement");

            migrationBuilder.CreateIndex(
                name: "IX_ExamAdvancement_UnitAdvancementId",
                schema: "Commons",
                table: "ExamAdvancement",
                column: "UnitAdvancementId",
                unique: true);
        }
    }
}
