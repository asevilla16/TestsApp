using System;
using Caracolknits.ShippingCenter.Api.Infraestructure.Core;
using Caracolknits.ShippingCenter.Api.Infraestructure.Core.RestClient;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.AreaAppServices;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.CareerAppServices;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.ConfigurationAppServices;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.FacilityAppServices;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.RolAppServices;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.SecurityAppServices;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.UnitAppServices;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.UserAppService;
using Microsoft.Extensions.DependencyInjection;
using CaracolKnits.NETCore.Uteck.Services.Infraestructure.Data.UnitOfWork;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using Microsoft.Extensions.Configuration;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.ResourceAppServices;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.PositionAppServices;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.EnrollmentAppServices;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.ExamMasterAppServices;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.QuestionAppService;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.CareerAdvancementAppServices;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.UnitAdvancementAddServices;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.ResourceAdvancementAppServices;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.DetailQuestionAnswerAppServices;

namespace CaracolKnits.NETCore.Uteck.Services.DependencyInjection
{
    public class Container
    {
        private readonly IServiceCollection _services;
        private readonly IConfiguration Configuration;
        public Container(IServiceCollection services, IConfiguration configuration)
        {
            if (services == null) throw new ArgumentException(nameof(services));

            _services = services;
            Configuration = configuration;

            InitializeUnitsOfWork();
            InitializeApplicationServices();
            InitializeDomainServices();
            InitializeRepositories();
        }

        private void InitializeRepositories()
        {
            _services.AddScoped(typeof(IGenericRepository<>), typeof(GenericRepository<>));
        }

        private void InitializeDomainServices()
        {
        }

        private void InitializeApplicationServices()
        {
            _services.AddScoped(typeof(IUserAppService), typeof(UserAppService));
            _services.AddScoped(typeof(IRolAppService), typeof(RolAppService));
            _services.AddScoped(typeof(IFacilityAppService), typeof(FacilityAppService));
            _services.AddScoped(typeof(IAreaAppService), typeof(AreaAppService));
            _services.AddScoped(typeof(ISecurityAppService), typeof(SecurityAppService));
            _services.AddScoped(typeof(IConfigurationAppService), typeof(ConfigurationAppService));
            _services.AddScoped(typeof(ICareerAppService), typeof(CareerAppService));
            _services.AddScoped(typeof(IUnitAppService), typeof(UnitAppService));
            _services.AddScoped(typeof(IResourceAppService), typeof(ResourceAppService));
            _services.AddScoped(typeof(IPositionAppService), typeof(PositionAppService));
            _services.AddScoped(typeof(IEnrollmentAppServices), typeof(EnrollmentAppService));
            _services.AddScoped<IExamMasterAppService, ExamMasterAppService>();
            _services.AddScoped<IQuestionAppService, QuestionAppService>();
            _services.AddScoped(typeof(ICareerAdvancementAppService), typeof(CareerAdvancementAppService));
            _services.AddScoped(typeof(IUnitAdvancementAppService), typeof(UnitAdvancementAppService));
            _services.AddScoped(typeof(IResourceAdvancementAppService), typeof(ResourceAdvancementAppService));
            _services.AddScoped<IDetailQuestionAnswerAppService, DetailQuestionAnswerAppService>();


            _services.AddScoped(typeof(IRestClientFactory), typeof(HttpRestClientFactory));
            _services.AddScoped(typeof(IRestClient), typeof(HttpRestClient));
            var clientFactory = new HttpRestClientFactory();
            RestClientFactory.SetCurrent(clientFactory);
            var translationManager = new TranslationManager(Configuration);
            Translations.SetCurrent(translationManager);
        }

        private void InitializeUnitsOfWork()
        {
            _services.AddScoped(typeof(IQueryableUnitOfWork), typeof(DataContext));
        }
    }
}