﻿using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.CareerAdvancementAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.CareerAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ExamAdvancementAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ResourceAdvancementAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UserAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UnitAdvancementAgg
{
    [Table(nameof(UnitAdvancement), Schema = "Commons")]
    public class UnitAdvancement : BaseEntity
    {
        [Required]
        [Column("UnitId")]
        public int UnitId { get; set; }

        [Required]
        [Column("CareerId")]
        public int CareerId { get; set; }

        [Required]
        [Column("UserId")]
        public int UserId { get; set; }

        [Required, StringLength(100)]
        [Column("Unit")]
        public string Unit { get; set; }

        [Required]
        [Column("Objective")]
        [DataType(DataType.Text)]
        public string Objective { get; set; }

        [Column("InitialDate")]
        public DateTime? InitialDate { get; set; }


        [Column("FinalDate")]
        public DateTime? FinalDate { get; set; }

        [Required]
        [Column("TimeSpent")]
        public int TimeSpent { get; set; }

        [Required]
        [Column("Progress")]
        public int Progress { get; set; }


        [Required, StringLength(50)]
        [Column("Period")]
        public string Period { get; set; }

        [Required]
        [Column("TotalScore")]
        public int TotalScore { get; set; }

        [Required]
        [Column("IsOpen")]
        public int IsOpen { get; set; }

        [Required]
        [Column("IsReplacement")]
        public int IsReplacement { get; set; }

        [Required]
        [Column("NumReplacement")]
        public int NumReplacement { get; set; }

        [Required]
        [Column("NotaAprobacion")]
        public int NotaAprobacion { get; set; }


        [Required]
        [ForeignKey("CareerAdvancementId")]
        public int CareerAdvancementId { get; set; }
        public virtual CareerAdvancement CareerAdvancement { get; set; }
        public virtual ICollection<ResourceAdvancement> ResourceAdvancement { get; set; }
        public virtual ICollection<ExamAdvancement> ExamAdvancement { get; set; }
    }
}
