﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.PermissionByRolAgg
{
    [Table(nameof(PermissionByRol), Schema = "Commons")]
    public class PermissionByRol : BaseEntity
    {
        [Required]
        [Column("RolId")]
        public int RolId { get; set; }

        [Required]
        [Column("PermissionId")]
        public int PermissionId { get; set; }

    }
}
