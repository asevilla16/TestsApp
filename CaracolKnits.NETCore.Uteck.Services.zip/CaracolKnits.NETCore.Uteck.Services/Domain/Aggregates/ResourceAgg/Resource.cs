﻿using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UnitAgg;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ResourceAgg
{
    [Table(nameof(Resource), Schema = "Commons")]
    public class Resource : BaseEntity
    {
        [Required]
        [StringLength(150)]
        [Column("Name")]
        public string Name { get; set; }

        [Required]
        [DataType(DataType.Text)]
        [Column("ResourceUrl")]
        public string ResourceUrl { get; set; }

        [Required]
        [Column("IsRequired")]
        public int IsRequired { get; set; }

        [Column("TimeRequired")]
        public int TimeRequired { get; set; }

        [Column("ResourceType"), StringLength(10)]
        public string ResourceType { get; set; }

        [Required]
        [Column("FileExtension")]
        public string FileExtension { get; set; }

        [Required]
        [Column("FileName")]
        public string FileName { get; set; }

        [Required]
        [Column("ItemId")]
        public string ItemId { get; set; }

        [Required]
        [ForeignKey("UnitId")]
        public int UnitId { get; set; }
        public virtual Unit Unit { get; set; }
    }
}
