﻿using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.CareerAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ExamnAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ResourceAgg;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UnitAgg
{
    [Table(nameof(Unit), Schema = "Commons")]
    public class Unit: BaseEntity
    {
        [Required]
        [StringLength(150)]
        [Column("Name")]
        public string Name { get; set; }

        [Required]
        [Column("Objective")]
        [DataType(DataType.Text)]
        public string Objective { get; set; }

        [Required]
        [Column("NotaAprobacion")]
        public int NotaAprobacion { get; set; }

        [Required]
        [ForeignKey("CareerId")]
        public int CareerId { get; set; }
        public virtual Career Career { get; set; }

        public virtual ICollection<Resource> Resource { get; set; }
        public virtual ICollection<Examn> Examn { get; set; }
    }
}
