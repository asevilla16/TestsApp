﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UnitAgg
{
    [Table(nameof(Unit_Transactions), Schema = "Commons")]
    public class Unit_Transactions : BaseEntity
    {
        [Required]
        [StringLength(150)]
        [Column("Name")]
        public string Name { get; set; }

        [Required]
        [Column("Objective")]
        [DataType(DataType.Text)]
        public string Objective { get; set; }

        [Required]
        [Column("NotaAprobacion")]
        public int NotaAprobacion { get; set; }

        [Required]
        [Column("CareerId")]
        public int CareerId { get; set; }
    }
}
