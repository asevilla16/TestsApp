﻿using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.PositionAgg
{
    [Table(nameof(Position_Transactions), Schema = "Commons")]
    public class Position_Transactions : BaseEntity
    {
        [Required]
        [StringLength(50)]
        [Column("PositionJob")]
        public string PositionJob { get; set; }

        [Required]
        [StringLength(250)]
        [Column("Name")]
        public string Name { get; set; }

        [Required]
        [Column("FacilityId")]
        public int FacilityId { get; set; }


    }
}
