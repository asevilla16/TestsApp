﻿using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.AreaAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.FacilityAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UserAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.PositionAgg
{
    [Table(nameof(Position), Schema = "Commons")]
    public class Position : BaseEntity
    {

        [Required]
        [StringLength(50)]
        [Column("PositionJob")]
        public string PositionJob { get; set; }

        [Required]
        [StringLength(250)]
        [Column("Name")]
        public string Name { get; set; }

        [Required]
        [ForeignKey("FacilityId")]
        public int FacilityId { get; set; }

        public virtual Facility Facility { get; set; }

        public virtual ICollection<User> User { get; set; }
    }
}
