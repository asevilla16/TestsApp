﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ExamnAgg
{
    [Table(nameof(Examn_Transactions), Schema = "Commons")]
    public class Examn_Transactions : BaseEntity
    {
        [Required]
        [StringLength(150)]
        [Column("Name")]
        public string Name { get; set; }

        [Required]
        [Column("ExamTime")]
        public int ExamTime { get; set; }

        [Required]
        [Column("NumberQuestions")]
        public int NumberQuestions { get; set; }

        [Required]
        [Column("UnitId")]
        public int UnitId { get; set; }
    }
}
