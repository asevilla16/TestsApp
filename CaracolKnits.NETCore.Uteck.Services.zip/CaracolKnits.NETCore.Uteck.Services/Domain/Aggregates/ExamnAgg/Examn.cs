﻿using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UnitAgg;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.QuestionAgg;
using System.Collections.Generic;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ExamnAgg
{
    [Table(nameof(Examn), Schema = "Commons")]
    public class Examn : BaseEntity
    {
        [Required]
        [StringLength(150)]
        [Column("Name")]
        public string Name { get; set; }

        [Required]
        [Column("ExamTime")]
        public int ExamTime { get; set; }

        [Required]
        [Column("NumberQuestions")]
        public int NumberQuestions { get; set; }

        [Required]
        [ForeignKey("UnitId")]
        public int UnitId { get; set; }
        public virtual Unit Unit { get; set; }
        public virtual ICollection<Question> Questions { get; set; }
    }
}
