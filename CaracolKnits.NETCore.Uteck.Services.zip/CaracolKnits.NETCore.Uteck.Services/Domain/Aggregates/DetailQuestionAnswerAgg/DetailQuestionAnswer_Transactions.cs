﻿using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ExamAdvancementAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.DetailQuestionAnswerAgg
{
    [Table(nameof(DetailQuestionAnswer_Transactions), Schema = "Commons")]
    public class DetailQuestionAnswer_Transactions : BaseEntity
    {
        [Required]
        [Column("ExamId")]
        public int ExamId { get; set; }

        [Required]
        [StringLength(150)]
        [Column("NameExam")]
        public string NameExam { get; set; }


        [Required, StringLength(50)]
        [Column("Quetion")]
        public string Quetion { get; set; }

        [Required, StringLength(100)]
        [Column("CorrectAnswer")]
        public string CorrectAnswer { get; set; }

        [Required, StringLength(100)]
        [Column("SelectedAnswer")]
        public string SelectedAnswer { get; set; }

    }
}
