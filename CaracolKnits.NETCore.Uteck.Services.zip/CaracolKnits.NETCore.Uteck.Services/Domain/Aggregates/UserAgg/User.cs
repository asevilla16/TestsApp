using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.RolAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.AreaAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.PositionAgg;
using System.Collections.Generic;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.CareerAdvancementAgg;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UserAgg
{
    [Table(nameof(User), Schema = "Commons")]
    public class User : BaseEntity
    {
        [Required, StringLength(50)]
        [Column("UserName")]
        public string UserName { get; set; }

        [Required, StringLength(50)]
        [Column("FullName")]
        public string FullName { get; set; }

        [Required]
        [Column("Password")]
        public string Password { get; set; }

        [Required, StringLength(5)]
        [Column("Facility_Id")]
        public string Facility_Id { get; set; }

        [Column("EmailAddress")]
        [StringLength(200)]
        public string EmailAddress { get; set; }

        [Column("LanguageId")]
        [Required, StringLength(2)]
        public string LanguageId { get; set; }

        [ForeignKey("AreaId")]
        public int? AreaId { get; set; }
        public virtual Area Area { get; set; }

        [Required]
        [ForeignKey("RolId")]
        public int RolId { get; set; }
        public virtual Rol Rol { get; set; }

        [ForeignKey("PositionJobId")]
        public int PositionJobId { get; set; }
        public virtual Position Position { get; set; }
        public virtual ICollection<CareerAdvancement> CareerAdvancement { get; set; }

    }
}