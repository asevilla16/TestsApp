﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UserAgg
{
    [Table(nameof(User_Transactions), Schema = "Commons")]
    public class User_Transactions : BaseEntity
    {
        [Required, StringLength(50)]
        [Column("UserName")]
        public string UserName { get; set; }

        [Required, StringLength(50)]
        [Column("FullName")]
        public string FullName { get; set; }

        [Required]
        [Column("Password")]
        public string Password { get; set; }

        [Required, StringLength(5)]
        [Column("Facility_Id")]
        public string Facility_Id { get; set; }

        [Column("EmailAddress")]
        [StringLength(200)]
        public string EmailAddress { get; set; }

        [Column("LanguageId")]
        [Required, StringLength(2)]
        public string LanguageId { get; set; }

        [Required]
        [Column("AreaId")]
        public int? AreaId { get; set; }

        [Required]
        [Column("RolId")]
        public int RolId { get; set; }

        [Column("PositionJobId")]
        public int? PositionJobId { get; set; }

    }
}
