﻿using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ResourceAdvancementAgg
{
    [Table(nameof(ResourceAdvancement_Transactions), Schema = "Commons")]
    public class ResourceAdvancement_Transactions : BaseEntity
    {
        [Required]
        [Column("ResourceId")]
        public int ResourceId { get; set; }

        [Required]
        [StringLength(150)]
        [Column("Resource")]
        public string Resource { get; set; }

        [Required]
        [Column("UnitId")]
        public int UnitId { get; set; }

        [Required]
        [Column("IsRequired")]
        public int IsRequired { get; set; }

        [Required]
        [DataType(DataType.Text)]
        [Column("ResourceUrl")]
        public string ResourceUrl { get; set; }

        [Required, StringLength(50)]
        [Column("UserName")]
        public string UserName { get; set; }

        [Column("ResourceType"), StringLength(10)]
        public string ResourceType { get; set; }

        [Required]
        [Column("FileExtension")]
        public string FileExtension { get; set; }

        [Required]
        [Column("FileName")]
        public string FileName { get; set; }

        [Required]
        [Column("ItemId")]
        public string ItemId { get; set; }

        [Required, StringLength(100)]
        [Column("UserFullName")]
        public string UserFullName { get; set; }

        [Column("InitialDate")]
        public DateTime? InitialDate { get; set; }


        [Column("FinalDate")]
        public DateTime? FinalDate { get; set; }

        [Required]
        [Column("TimeResource")]
        public int TimeResource { get; set; }

        [Required]
        [Column("TimeSpent")]
        public int TimeSpent { get; set; }

        [Required]
        [Column("Progress")]
        public int Progress { get; set; }


        [Required, StringLength(50)]
        [Column("Period")]
        public string Period { get; set; }

        [Required]
        [Column("IsOpen")]
        public int IsOpen { get; set; }

        [Required]
        [Column("IsReplacement")]
        public int IsReplacement { get; set; }

        [Required]
        [Column("NumReplacement")]
        public int NumReplacement { get; set; }

        [Required]
        [Column("UserId")]
        public int UserId { get; set; }

        [Required]
        [Column("UnitAdvancementId")]
        public int UnitAdvancementId { get; set; }
    }
}
