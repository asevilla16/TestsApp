﻿using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ExamAdvancementAgg
{
    [Table(nameof(ExamAdvancement_Transactions), Schema = "Commons")]
    public class ExamAdvancement_Transactions: BaseEntity
    {
        [Required]
        [Column("ExamId")]
        public int ExamId { get; set; }

        [Required]
        [StringLength(150)]
        [Column("NameExam")]
        public string NameExam { get; set; }

        [Required]
        [Column("ExamTime")]
        public int ExamTime { get; set; }

        [Required]
        [Column("NumberQuestions")]
        public int NumberQuestions { get; set; }

        [Required, StringLength(50)]
        [Column("UserName")]
        public string UserName { get; set; }

        [Required, StringLength(100)]
        [Column("UserFullName")]
        public string UserFullName { get; set; }

        [Column("InitialDate")]
        public DateTime? InitialDate { get; set; }


        [Column("FinalDate")]
        public DateTime? FinalDate { get; set; }

        [Required]
        [Column("TimeSpent")]
        public int TimeSpent { get; set; }

        [Required, StringLength(50)]
        [Column("Period")]
        public string Period { get; set; }

        [Required]
        [Column("IsOpen")]
        public int IsOpen { get; set; }

        [Required]
        [Column("TotalScore")]
        public int TotalScore { get; set; }

        [Required]
        [Column("UserId")]
        public int UserId { get; set; }

        [Required]
        [Column("UnitAdvancementId")]
        public int UnitAdvancementId { get; set; }
    }
}
