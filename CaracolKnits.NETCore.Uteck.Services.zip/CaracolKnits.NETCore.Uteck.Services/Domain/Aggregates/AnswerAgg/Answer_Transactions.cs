﻿using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.AnswerAgg
{
    [Table(nameof(Answer_Transactions), Schema = "Commons")]
    public class Answer_Transactions : BaseEntity
    {
        [Required]
        [StringLength(150)]
        [Column("Description")]
        public string Description { get; set; }

        [Required]
        [Column("IsCorrectAnswer")]
        public bool IsCorrectAnswer { get; set; }

        [Required]
        [Column("QuestionId")]
        public int QuestionId { get; set; }
    }
}
