﻿using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.FacilityAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UnitAgg;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.CareerAgg
{
    [Table(nameof(Career), Schema = "Commons")]
    public class Career : BaseEntity
    {
        [Required]
        [StringLength(150)]
        [Column("Name")]
        public string Name { get; set; }

        [Required]
        [Column("Description")]
        [DataType(DataType.Text)]
        public string Description { get; set; }

        [Required]
        [Column("NotaAprobacion")]
        public int NotaAprobacion { get; set; }

        [Required]
        [Column("OscarSeguimiento")]
        public int OscarSeguimiento { get; set; }

        [Column("NoSemanas")]
        public int NoSemanas { get; set; }

        [Required]
        [ForeignKey("FacilityId")]
        public int FacilityId { get; set; }
        public virtual Facility Facility { get; set; }

        public virtual ICollection<Unit> Unit { get; set; }
    }
}
