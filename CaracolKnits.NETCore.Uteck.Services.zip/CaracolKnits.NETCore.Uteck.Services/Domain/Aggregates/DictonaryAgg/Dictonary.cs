﻿using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.DictonaryAgg
{
    [Table(nameof(Dictonary), Schema = "Commons")]
    public class Dictonary : BaseEntity
    {
        [Required]
        [StringLength(10)]
        [Column("LanguageId")]
        public string LanguageId { get; set; }

        [Required]
        [StringLength(250)]
        [Column("Key")]
        public string Key { get; set; }

        [Required]
        [StringLength(250)]
        [Column("Value")]
        public string Value { get; set; }

        [StringLength(250)]
        [Column("Description")]
        public string Description { get; set; }
    }
}
