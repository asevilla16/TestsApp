﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.CareerByPositionAgg
{
    [Table(nameof(CareerByPosition), Schema = "Commons")]
    public class CareerByPosition : BaseEntity
    {
        [Required]
        [Column("CareerId")]
        public int CareerId { get; set; }

        [Required]
        [Column("PositionId")]
        public int PositionId { get; set; }
    }
}
