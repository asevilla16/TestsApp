﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ConfigurationAgg
{
    [Table(nameof(Configuration_Transactions), Schema = "Commons")]
    public class Configuration_Transactions : BaseEntity
    {

        [Required]
        [Column("Facility"), StringLength(10)]
        public string Facility { get; set; }

        [Required]
        [Column("Description"), StringLength(150)]
        public string Description { get; set; }

        [Required]
        [ForeignKey("Attribute"), StringLength(150)]
        public string Attribute { get; set; }

        [Required]
        [Column("Value")]
        public string Value { get; set; }
    }
}
