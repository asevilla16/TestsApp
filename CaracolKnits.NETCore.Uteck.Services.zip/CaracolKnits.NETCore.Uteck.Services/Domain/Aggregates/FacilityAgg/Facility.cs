﻿using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.AreaAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.CareerAgg;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.PositionAgg;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.FacilityAgg
{
    [Table(nameof(Facility), Schema = "Commons")]
    public class Facility : BaseEntity
    {

        [Required, StringLength(10)]
        [Column("Facility_Id")]
        public string Facility_Id { get; set; }

        [Required, StringLength(100)]
        [Column("Name")]
        public string Name { get; set; }

        [Column("Description"), StringLength(150)]
        public string Description { get; set; }

        [Column("ImageLogo")]
        [DataType(DataType.Text)]
        public string ImageLogo { get; set; }

        public virtual ICollection<Career> Career { get; set; }
        public virtual ICollection<Position> Position { get; set; }
        public virtual ICollection<Area> Area { get; set; }
    }
}
