﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.FacilityAgg
{
    [Table(nameof(Facility_Transactions), Schema = "Commons")]
    public class Facility_Transactions : BaseEntity
    {
        [Required, StringLength(10)]
        [Column("Facility_Id")]
        public string Facility_Id { get; set; }

        [Required, StringLength(100)]
        [Column("Name")]
        public string Name { get; set; }

        [Column("Description"), StringLength(150)]
        public string Description { get; set; }

        [Column("ImageLogo")]
        [DataType(DataType.Text)]
        public string ImageLogo { get; set; }
    }
}
