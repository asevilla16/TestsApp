﻿using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.AnswerAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ExamnAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.QuestionTypeAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.QuestionAgg
{
    [Table(nameof(Question), Schema = "Commons")]
    public class Question : BaseEntity
    {
        [Required]
        [StringLength(150)]
        [Column("Description")]
        public string Description { get; set; }

        [DataType(DataType.Text)]
        public string ImageURL { get; set; }

        [Required]
        [ForeignKey("QuestionTypeId")]
        public int QuestionTypeId { get; set; }
        public virtual QuestionType QuestionType { get; set; } 

        [Required]
        [ForeignKey("ExamId")]
        public int ExamId { get; set; }

        public virtual Examn Exam { get; set; }
        public virtual ICollection<Answer> Answers { get; set; }
    }
}
