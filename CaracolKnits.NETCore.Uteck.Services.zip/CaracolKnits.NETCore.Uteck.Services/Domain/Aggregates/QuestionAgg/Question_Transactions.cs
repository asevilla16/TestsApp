﻿using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ExamnAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.QuestionAgg
{
    [Table(nameof(Question_Transactions), Schema = "Commons")]
    public class Question_Transactions : BaseEntity
    {
        [Required]
        [StringLength(150)]
        [Column("Description")]
        public string Description { get; set; }

        [DataType(DataType.Text)]
        public string ImageURL { get; set; }

        [Required]
        [Column("QuestionTypeId")]
        public int QuestionTypeId { get; set; }

        [Required]
        [Column("ExamId")]
        public int ExamId { get; set; }

    }
}
