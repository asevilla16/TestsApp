﻿using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UnitAdvancementAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UnitAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UserAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.CareerAdvancementAgg
{
    [Table(nameof(CareerAdvancement), Schema = "Commons")]
    public class CareerAdvancement : BaseEntity
    {
        [Required]
        [Column("CareerId")]
        public int CareerId { get; set; }

        [Required, StringLength(100)]
        [Column("Career")]
        public string Career { get; set; }

        [Required]
        [DataType(DataType.Text)]
        [Column("Description")]
        public string Description { get; set; }

        [Required, StringLength(50)]
        [Column("UserName")]
        public string UserName { get; set; }

        [Required, StringLength(100)]
        [Column("UserFullName")]
        public string UserFullName { get; set; }

        [Column("InitialDate")]
        public DateTime? InitialDate { get; set; }


        [Column("FinalDate")]
        public DateTime? FinalDate { get; set; }

        [Required]
        [Column("TimeSpent")]
        public int TimeSpent { get; set; }

        [Required]
        [Column("Progress")]
        public int Progress { get; set; }


        [Required, StringLength(50)]
        [Column("Period")]
        public string Period { get; set; }


        [Required]
        [Column("IsOpen")]
        public int IsOpen { get; set; }

        [Required]
        [Column("TotalScore")]
        public int TotalScore { get; set; }

        [Required]
        [Column("NotaAprobacion")]
        public int NotaAprobacion { get; set; }

        [Required]
        [Column("NoSemanas")]
        public int NoSemanas { get; set; }

        [Required]
        [ForeignKey("UserId")]
        public int UserId { get; set; }
        public virtual User User { get; set; }
        public virtual ICollection<UnitAdvancement> UnitAdvancement { get; set; }

    }
}
