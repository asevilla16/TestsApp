﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.AreaAgg
{
    [Table(nameof(Area_Transactions), Schema = "Commons")]
    public class Area_Transactions : BaseEntity
    {
        [Required]
        [Column("Code")]
        public int Code { get; set; }

        [Required, StringLength(100)]
        [Column("Name")]
        public string Name { get; set; }

        [Required]
        [Column("FacilityId")]
        public int FacilityId { get; set; }
    }
}
