﻿using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UserAgg;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.RolAgg
{
    [Table(nameof(Rol), Schema = "Commons")]
    public class Rol : BaseEntity
    {
        [Column("RolName"), StringLength(100)]
        public string RolName { get; set; }
        public virtual ICollection<User> User { get; set; }
    }
}
