﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.RolAgg
{
    [Table(nameof(Rol_Transactions), Schema = "Commons")]
    public class Rol_Transactions : BaseEntity
    {
        [Column("RolName"), StringLength(100)]
        public string RolName { get; set; }
    }
}
