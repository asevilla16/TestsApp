﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.DictonaryAppServices;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Core
{
    public class TranslationManager : ITranslationManager
    {
        private readonly IConfiguration Configuration;
        public TranslationManager(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public IDictonaryAppService Create()
        {
            return new DictonaryAppService(Configuration);
        }
    }
}
