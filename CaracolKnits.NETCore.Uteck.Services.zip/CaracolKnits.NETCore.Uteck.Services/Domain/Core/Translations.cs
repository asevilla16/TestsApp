﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.DictonaryAppServices;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Core
{
    public static class Translations
    {
        static ITranslationManager _translationFactory;
        public static void SetCurrent(ITranslationManager translationFactory)
        {
            _translationFactory = translationFactory;
        }
        public static IDictonaryAppService CreateTranslation()
        {

            return _translationFactory.Create();
        }

        public const string thisPlantAlreadyExists = "ThisPlantAlreadyExists";
        public const string thisAreaAlreadyExists = "ThisAreaAlreadyExists";
        public const string thereIsAlreadyACareerWithThatNameInThePlant = "ThereIsAlreadyACareerWithThatNameInThePlant";
        public const string careerDoesNotExist = "CareerDoesNotExist";
        public const string thereAreNoCareersToAssign = "ThereAreNoCareersToAssign";
        public const string noCareersToUnassign = "NoCareersToUnassign";
        public const string theseCareerAreAlreadyAssigned = "TheseCareerAreAlreadyAssigned";
        public const string thereIsAlreadyAUnitWithThatNameInThisCareer = "ThereIsAlreadyAUnitWithThatNameInThisCareer";
        public const string unitDoesNotExist = "UnitDoesNotExist";
        public const string aPermissionWithThatNameAlreadyExists = "APermissionWithThatNameAlreadyExists";
        public const string thePermissionIsAlreadyAssignedToTheRole = "ThePermissionIsAlreadyAssignedToTheRole";
        public const string roleDoesNotexist = "RoleDoesNotexist";
        public const string permissionDoesNotExist = "PermissionDoesNotExist";
        public const string roleAlreadyExists = "RoleAlreadyExists";
        public const string aResourceWithThatNameAlreadyExistsOnThisUnit = "AResourceWithThatNameAlreadyExistsOnThisUnit";
        public const string theConfigurationDoesNotExist = "TheConfigurationDoesNotExist";
        public const string theResourceDoesNotExist = "TheResourceDoesNotExist";
    }
  

}
