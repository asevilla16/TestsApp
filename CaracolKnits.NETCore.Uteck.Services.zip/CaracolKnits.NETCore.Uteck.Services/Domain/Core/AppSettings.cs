﻿namespace CaracolKnits.NETCore.Uteck.Services.Domain.Core
{
    public class AppSettings
    {
        public string Secreto { get; set; }
    }
}
