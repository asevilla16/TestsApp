using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services
{
    public interface IUnitOfWork : IDisposable
    {
        void Commit();
        Task CommitAsync();
        void CommitAndRefreshChanges();
        Task CommitAsync(TransactionInfo transactionInfo);
    }
}