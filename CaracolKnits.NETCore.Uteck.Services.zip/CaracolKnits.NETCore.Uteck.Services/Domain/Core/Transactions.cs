﻿namespace CaracolKnits.NETCore.Uteck.Services.Domain.Core
{
    public static class Transactions
    {
        public const string createUser = "CreateUser";
        public const string deletePermission = "DeletePermission";
        public const string deleteTariffPosition = "DeleteTariffPosition";
        public const string deleteRole = "DeleteRole";
        public const string insert = "Insert";
        public const string update = "Update";
        public const string createPermission = "CreatePermission";
        public const string createRole = "CreateRole";
        public const string provideAccess = "ProvideAccess";
        public const string creteTariffPosition = "CreteTariffPosition";
        public const string updateTariffPosition = "UpdateTariffPosition";
        public const string IMPORT_INVOICE_FROM_CTS = "IMPORT_INVOICE_FROM_CTS";
        public const string REMOVE_INVOICE_FROM_CTS = "REMOVE_INVOICE_FROM_CTS";
        public const string CreateExportOrders = "CreateExportOrders";
        public const string UpdtaeExportOrders = "UpdtaeExportOrders";
        public const string RemoveExportOrders = "RemoveExportOrders";
        public const string createFacility = "CreateFacility";
        public const string createConfiguration = "CreateConfiguration";
        public const string updatePassword = "UpdatePassword";
        public const string deleteUser = "DeleteUser";
        public const string createCareer = "CreateCareer";
        public const string assignCareerToPosition = "AssignCareerToPosition";
        public const string unAssignCareerToArea = "UnAssignCareerToArea";
        public const string createUnit = "CreateUnit";
        public const string deleteUnit = "DeleteUnit";
        public const string editUnit = "EditUnit";
        public const string createResource = "CreateResource";
        public const string createExam = "CreateExam";
        public const string registerInitialDate = "RegisterInitialDate";
        public const string registerFinalDate = "RegisterFinalDate";
        public const string registerProgress = "RegisterProgress";
        public const string openExam= "OpenExam";
        public const string closeExam = "CloseExam";
    }
}
