﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Core
{
    public static class TransactionInfoFactory
    {
        public static TransactionInfo CrearTransactionInfo(UserInfoDto userInfoDTO, string transaccionId)
        {
            //ValidarArgumentosUserInfo(userInfoDTO);

            TransactionInfo transactionInfo = new TransactionInfo(userInfoDTO.CreatedBy, transaccionId);

            transactionInfo.GenerateTransactions = true;

            return transactionInfo;
        }

        internal static object CrearTransactionInfo(UserInfoDto requestUserInfo, object iMPORT_INVOICE_FROM_CTS)
        {
            throw new NotImplementedException();
        }
    }
}
