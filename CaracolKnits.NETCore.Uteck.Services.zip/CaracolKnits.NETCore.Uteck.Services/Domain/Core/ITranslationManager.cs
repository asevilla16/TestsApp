﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.DictonaryAppServices;

namespace CaracolKnits.NETCore.Uteck.Services.Domain.Core
{
    public interface ITranslationManager
    {
        IDictonaryAppService Create();
    }
}
