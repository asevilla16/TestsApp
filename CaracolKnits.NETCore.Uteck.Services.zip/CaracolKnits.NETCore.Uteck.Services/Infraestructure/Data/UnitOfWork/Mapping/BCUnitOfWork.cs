using Microsoft.EntityFrameworkCore;

namespace CaracolKnits.NETCore.Uteck.Services.Infraestructure.Data.UnitOfWork.Mapping
{
    public class BCUnitOfWork : DbContext
    {

    }
}