namespace CaracolKnits.NETCore.Uteck.Services
{
    public interface IGenericDataContext : IQueryableUnitOfWork
    {
    }
}