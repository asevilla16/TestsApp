using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.AnswerAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.AreaAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.CareerAdvancementAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.CareerAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.CareerByPositionAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.CareerByUserAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ConfigurationAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.DetailQuestionAnswerAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.DictonaryAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ExamAdvancementAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ExamnAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.FacilityAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.PermissionAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.PermissionByRolAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.PositionAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.QuestionAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.QuestionTypeAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ResourceAdvancementAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ResourceAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.RolAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UnitAdvancementAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UnitAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UserAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using CaracolKnits.NETCore.Uteck.Services.Infraestructure.Core;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace CaracolKnits.NETCore.Uteck.Services.Infraestructure.Data.UnitOfWork
{
    public class DataContext : DbContext, IQueryableUnitOfWork
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {

        }
        public DbSet<Answer> Answer { get; set; }
        public DbSet<Answer_Transactions> Answer_Transactions { get; set; }
        public DbSet<User> User { get; set; }
        public DbSet<User_Transactions> User_Transactions { get; set; }
        public DbSet<Area> Area { get; set; }
        public DbSet<Area_Transactions> Area_Transactions { get; set; }
        public DbSet<Career> Career { get; set; }
        public DbSet<Career_Transactions> Career_Transactions { get; set; }
        public DbSet<CareerByUser> CareerByUser { get; set; }
        public DbSet<CareerByUser_Transactions> CareerByUser_Transactions { get; set; }
        public DbSet<CareerByPosition> CareerByArea { get; set; }
        public DbSet<CareerByPosition_Transactions> CareerByArea_Transactions { get; set; }
        public DbSet<Examn> Examn { get; set; }
        public DbSet<Examn_Transactions> Examn_Transactions { get; set; }
        public DbSet<Facility> Facility { get; set; }
        public DbSet<Facility_Transactions> Facility_Transactions { get; set; }
        public DbSet<Question> Question { get; set; }
        public DbSet<Question_Transactions> Question_Transactions { get; set; }
        public DbSet<QuestionType> QuestionType { get; set; }
        public DbSet<QuestionType_Transactions> QuestionType_Transactions { get; set; }
        public DbSet<Resource> Resource { get; set; }
        public DbSet<Resource_Transactions> Resource_Transactions { get; set; }
        public DbSet<Rol> Rol { get; set; }
        public DbSet<Rol_Transactions> Rol_Transactions { get; set; }
        public DbSet<Unit> Unit { get; set; }
        public DbSet<Unit_Transactions> Unit_Transactions { get; set; }
        public DbSet<Permission> Permission { get; set; }
        public DbSet<Permission_Transactions> Permission_Transactions { get; set; }
        public DbSet<PermissionByRol> PermissionByRol { get; set; }
        public DbSet<PermissionByRol_Transactions> PermissionByRol_Transactions { get; set; }
        public DbSet<Configuration> Configuration { get; set; }
        public DbSet<Configuration_Transactions> Configuration_Transactions { get; set; }
        public DbSet<Dictonary> Dictionary { get; set; }
        public DbSet<Position> Position { get; set; }
        public DbSet<Position_Transactions> Position_Transactions { get; set; }
        public DbSet<CareerAdvancement> CareerAdvancement { get; set; }
        public DbSet<CareerAdvancement_Transactions> CareerAdvancement_Transactions { get; set; }
        public DbSet<UnitAdvancement> UnitAdvancement { get; set; }
        public DbSet<UnitAdvancement_Transactions> UnitAdvancement_Transactions { get; set; }
        public DbSet<ResourceAdvancement_Transactions> ResourceAdvancement_Transactions { get; set; }
        public DbSet<ResourceAdvancement> ResourceAdvancement { get; set; }
        public DbSet<DetailQuestionAnswer> DetailQuestionAnswer { get; set; }
        public DbSet<DetailQuestionAnswer_Transactions> DetailQuestionAnswer_Transactions { get; set; }
        public DbSet<ExamAdvancement> ExamAdvancement { get; set; }
        public DbSet<ExamAdvancement_Transactions> ExamAdvancement_Transactions { get; set; }



        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // modelBuilder.Entity<Produce>();

        }

        void IQueryableUnitOfWork.ApplyCurrentValues<TEntity>(TEntity original, TEntity current)
        {
            //if it is not attached, attach original and set current values
            Entry(original).CurrentValues.SetValues(current);
        }

        void IQueryableUnitOfWork.Attach<TEntity>(TEntity item)
        {
            //attach and set as unchanged
            Entry(item).State = EntityState.Unchanged;
        }

        void IUnitOfWork.Commit()
        {
            base.SaveChanges();
        }

        async Task IUnitOfWork.CommitAsync()
        {
            await base.SaveChangesAsync();
        }
        void IUnitOfWork.CommitAndRefreshChanges()
        {
            bool saveFailed;

            do
            {
                try
                {
                    base.SaveChanges();

                    saveFailed = false;
                }
                catch (DbUpdateConcurrencyException ex)
                {
                    saveFailed = true;

                    ex.Entries.ToList()
                              .ForEach(entry => entry.OriginalValues.SetValues(entry.GetDatabaseValues()));
                }
            } while (saveFailed);
        }
        private IEnumerable<EntityEntry> GetChangedDbEntityEntries()
        {
            return ChangeTracker.Entries().Where(
                e =>
                (e.Entity is Entity || e.Entity is BaseEntity) &&
                (e.State == EntityState.Modified || e.State == EntityState.Added || e.State == EntityState.Deleted));
        }

        private static void AplicarInformacionTransaccion(EntityEntry item, string nombrePropiedad, object valorPropiedad)
        {
            if (item != null && item.Entity != null)
            {
                PropertyInfo propInfoEntity = item.Entity.GetType().GetProperty(nombrePropiedad);
                if (propInfoEntity != null)
                {
                    propInfoEntity.SetValue(item.Entity, valorPropiedad, null);
                }
            }
        }

        private void ApplyTransactionInfo(TransactionInfo transaction, EntityEntry entry)
        {
            ((BaseEntity)entry.Entity).TransactionDate = DateTime.Now;
            ((BaseEntity)entry.Entity).TransactionDescription = entry.State.ToString();
            ((BaseEntity)entry.Entity).ModifiedBy = transaction.ModifiedBy;

            if (!((BaseEntity)entry.Entity).CreationDate.HasValue)
            {
                ((BaseEntity)entry.Entity).CreationDate = DateTime.Now;
            }


            AplicarInformacionTransaccion(entry, "TransactionType", transaction.TransactionType);
            AplicarInformacionTransaccion(entry, "TransactionUId", transaction.TransactionUId);
            AplicarInformacionTransaccion(entry, "TransactionDateUtc", transaction.TransactionDateUtc);
        }

        private static Type GetDomainEntityType(EntityEntry entry)
        {
            Type type = entry.Entity.GetType();
            if (type.FullName != null)
            {
                if (type.FullName.Contains("CaracolKnits.NETCore.Uteck.Services") || type.FullName.Contains("T4"))
                {
                    return type;
                }
                if (type.BaseType != null)
                {
                    return type.BaseType;
                }
            }

            return null;
        }

        private static string GetTransactionTableName(string tname)
        {
            if (tname.Contains("_Transactions"))
            {
                return tname;
            }

            string result = string.Format("{0}_Transactions", tname);

            return result;
        }

        private static EntityMapping CreateTableMapping(Type type, string tname)
        {
            return new EntityMapping { EntityType = type, TableName = tname, TransactionTableName = GetTransactionTableName(tname) };
        }

        private EntityMapping GetEntityMappingConfiguration(List<EntityMapping> tableMapping, EntityEntry entry)
        {
            var type = GetDomainEntityType(entry);

            var name = entry.Metadata.GetTableName();
            var schema = entry.Metadata.GetSchema();

            string nameTable = string.Format("{0}.{1}", schema, name);

            EntityMapping entityMapping = tableMapping.FirstOrDefault(m => m.EntityType == type);
            if (entityMapping == null)
            {
                entityMapping = CreateTableMapping(type, nameTable);
                tableMapping.Add(entityMapping);
            }
            return entityMapping;
        }

        private static List<string> GetPropertiesEntity(EntityEntry entry, PropertyValues originalValues)
        {
            List<string> propertyNames = new();
            var entity = entry.Entity;
            var entityType = entity.GetType();

            var properties = entry.OriginalValues.Properties;

            foreach (var prop in properties)
            {
                if (entityType.GetProperty(prop.Name) == null)
                    continue;
                var pp = entityType.GetProperty(prop.Name);
                if (pp.GetValue(entity) == null)
                    continue;

                propertyNames.Add(prop.Name);
            }

            return propertyNames;
        }

        private static void TryGeTransactionInfo(string property, TransactionInfo transaction, out object value)
        {
            value = property switch
            {
                "TransactionUId" => transaction.TransactionUId,
                "TransactionType" => transaction.TransactionType,
                "TransactionDate" => transaction.TransactionDate,
                "TransactionDateUtc" => transaction.TransactionDateUtc,
                "ModifiedBy" => transaction.ModifiedBy,
                "RowVersion" => transaction.RowVersion,
                _ => null,
            };
        }

        private static object GetEntityPropertyValue(EntityEntry entry, string prop, TransactionInfo transaction)
        {
            object value;
            TryGeTransactionInfo(prop, transaction, out value);
            if (value != null)
            {
                return value;
            }

            if (entry.State == EntityState.Deleted || entry.State == EntityState.Detached)
            {
                return prop == "TransactionDescription"
                           ? EntityState.Deleted.ToString()
                           : entry.Property(prop).OriginalValue;
            }
            var ret = entry.Property(prop).CurrentValue;

            return ret;
        }

        private static void CreateTransactionInsertStatement(EntityMapping entityMapping, EntityEntry entry,
                                                     TransactionInfo transaction, out string sqlInsert, out object[] objects)
        {
            var insert = new StringBuilder();
            var fields = new StringBuilder();
            var paramNames = new StringBuilder();
            var values = new List<object>();

            insert.AppendLine(string.Format("Insert Into {0} ", entityMapping.TransactionTableName));

            int index = 0;

            IEnumerable<string> propertyNames = entry.State == EntityState.Deleted
                                                    ? GetPropertiesEntity(entry, entry.OriginalValues)
                                                    : GetPropertiesEntity(entry, entry.CurrentValues); ;

            foreach (string property in propertyNames)
            {
                if (property == "Id") continue;

                string prop = property;
                if (prop != "RowVersion")
                {
                    if (fields.Length == 0)
                    {
                        fields.Append(string.Format(" ({0}", prop));
                        paramNames.Append(string.Format(" values ({0}{1}{2}", "{", index, "}"));
                    }
                    else
                    {
                        fields.Append(string.Format(", {0}", prop));
                        paramNames.Append(string.Format(", {0}{1}{2}", "{", index, "}"));
                    }

                    values.Add(GetEntityPropertyValue(entry, prop, transaction));
                    index++;
                }
            }

            fields.Append(string.Format(") "));
            paramNames.Append(string.Format(") "));

            insert.AppendLine(fields.ToString());
            insert.AppendLine(paramNames.ToString());

            sqlInsert = insert.ToString();
            objects = values.ToArray();
        }


        private static SqlCommandInfo GetSqlCommandInfo(TransactionInfo transaction, EntityEntry entry, EntityMapping entityMapping)
        {
            if (entityMapping.TableName.Contains("_Transacciones"))
            {
                return null;
            }

            string sqlInsert;
            object[] param;
            CreateTransactionInsertStatement(entityMapping, entry, transaction, out sqlInsert, out param);

            var sqlCommandInfo = new SqlCommandInfo(sqlInsert, param);
            return sqlCommandInfo;
        }
        public async Task CommitAsync(TransactionInfo transaction)
        {
            if (transaction == null) throw new ArgumentNullException(nameof(transaction));
            if (string.IsNullOrWhiteSpace(transaction.TransactionType)) throw new ArgumentException(nameof(transaction.TransactionType));
            if (string.IsNullOrWhiteSpace(transaction.ModifiedBy)) throw new ArgumentException(nameof(transaction.ModifiedBy));
            transaction.TransactionDate = DateTime.Now;

            try
            {
                base.Database.OpenConnection();
                // Resetenado el detalla de las transacciones.
                transaction.TransactionDetail = new List<TransactionDetail>();

                using (var scope = TransactionScopeFactory.GetTransactionScope())
                {
                    var changedEntities = new List<ModifiedEntityEntry>();
                    var tableMapping = new List<EntityMapping>();
                    var sqlCommandInfos = new List<SqlCommandInfo>();

                    IEnumerable<EntityEntry> changedDbEntityEntries = GetChangedDbEntityEntries();

                    //Actualiza la FechaTransaccion de cada entidad agregada, modificada o eliminada con la fecha del servidor
                    foreach (EntityEntry entry in changedDbEntityEntries)
                    {
                        ApplyTransactionInfo(transaction, entry);

                        if (transaction.GenerateTransactions)
                        {
                            // Get the deleted records info first
                            if (entry.State == EntityState.Deleted)
                            {
                                EntityMapping entityMapping = GetEntityMappingConfiguration(tableMapping, entry);
                                SqlCommandInfo sqlCommandInfo = GetSqlCommandInfo(transaction, entry, entityMapping);
                                if (sqlCommandInfo != null) sqlCommandInfos.Add(sqlCommandInfo);

                                transaction.AddDetail(entityMapping.TableName, entry.State.ToString(), transaction.TransactionType);
                            }
                            else
                            {
                                changedEntities.Add(new ModifiedEntityEntry(entry, entry.State.ToString()));
                            }
                        }
                    }

                    await base.SaveChangesAsync();

                    if (transaction.GenerateTransactions)
                    {
                        // Get the Added and Mdified records after changes, that way we will be able to get the generated .
                        foreach (ModifiedEntityEntry entry in changedEntities)
                        {
                            EntityMapping entityMapping = GetEntityMappingConfiguration(tableMapping, entry.EntityEntry);
                            SqlCommandInfo sqlCommandInfo = GetSqlCommandInfo(transaction, entry.EntityEntry, entityMapping);
                            if (sqlCommandInfo != null) sqlCommandInfos.Add(sqlCommandInfo);

                            transaction.AddDetail(entityMapping.TableName, entry.State, transaction.TransactionType);
                        }

                        // Adding Audit Detail Transaction CommandInfo.
                        //sqlCommandInfos.AddRange(GetAuditRecords(transaction));

                        // Insert Transaction and audit records.
                        foreach (SqlCommandInfo sqlCommandInfo in sqlCommandInfos)
                        {
                            Database.ExecuteSqlRaw(sqlCommandInfo.Sql, sqlCommandInfo.Parameters);
                        }
                    }

                    scope.Complete();
                }



            }
            finally
            {
                base.Database.CloseConnection();
            }
        }

    

        DbSet<TEntity> IQueryableUnitOfWork.CreateSet<TEntity>()
        {
            return Set<TEntity>();
        }

        void IQueryableUnitOfWork.SetModified<TEntity>(TEntity item)
        {
            throw new System.NotImplementedException();
        }
    }

}