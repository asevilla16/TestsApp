﻿namespace Caracolknits.ShippingCenter.Api.Infraestructure.Core.RestClient
{
    public interface IRestClientFactory
    {
        IRestClient Create(string baseAddress);
    }
}
