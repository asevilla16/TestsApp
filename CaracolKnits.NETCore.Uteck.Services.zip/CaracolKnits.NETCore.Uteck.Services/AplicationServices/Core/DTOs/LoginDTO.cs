﻿using System.Collections.Generic;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs
{
    public class LoginDTO : ResponseBase
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string Language { get; set; }
        public bool IsAuthenticated { get; set; }
        public string Email { get; set; }
        public string Facility { get; set; }
        public List<PermissionUser> PermissionUser { get; set; }
        public string Token { get; set; }
        public string TokenSp { get; set; }
        public string DriveId { get; set; }
    }

    public class PermissionUser
    {
        public int RolId { get; set; }
        public string Permission { get; set; }
    }
}
