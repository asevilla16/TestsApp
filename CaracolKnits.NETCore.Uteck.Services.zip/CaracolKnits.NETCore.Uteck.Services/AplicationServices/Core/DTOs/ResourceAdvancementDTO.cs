﻿using System;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs
{
    public class ResourceAdvancementDTO : ResponseBase
    {
        public int ResourceAdvancementId { get; set; }
        public int ResourceId { get; set; }
        public string Resource { get; set; }
        public int UnitId { get; set; }
        public string ResourceUrl { get; set; }
        public string UserName { get; set; }
        public string UserFullName { get; set; }
        public int IsRequired { get; set; }
        public DateTime? InitialDate { get; set; }
        public DateTime? FinalDate { get; set; }
        public int TimeResource { get; set; }
        public string ResourceType { get; set; }
        public string FileExtension { get; set; }
        public string FileName { get; set; }
        public string ItemId { get; set; }
        public int TimeSpent { get; set; }
        public int Progress { get; set; }
        public string Period { get; set; }
        public int IsOpen { get; set; }
        public int IsReplacement { get; set; }
        public int NumReplacement { get; set; }
        public int UserId { get; set; }
        public int UnitAdvancementId { get; set; }

    }
}
