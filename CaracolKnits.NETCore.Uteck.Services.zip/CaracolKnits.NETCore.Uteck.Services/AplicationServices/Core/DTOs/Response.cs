﻿namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs
{
    public class Response : ResponseBase
    {
    }
}
