﻿namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs
{
    public class PositionDTO : ResponseBase
    {
        public int PositionId { get; set; }
        public string PositionJob { get; set; }
        public string Name { get; set; }
        public int FacilityId { get; set; }

    }
}
