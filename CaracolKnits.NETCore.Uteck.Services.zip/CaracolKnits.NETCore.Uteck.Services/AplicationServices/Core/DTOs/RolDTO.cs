﻿using System.Collections.Generic;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs
{
    public class RolDTO : ResponseBase
    {
        public int RolId { get; set; }
        public string RolName { get; set; }
        public List<UserDTO> Users { get; set; }
    }
}
