﻿namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs
{
    public class UserCtsDTO : ResponseBase
    {
        public string Name { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public string FacilitiesAccesses { get; set; }
        public string Password { get; set; }
        public bool IsAuthenticated { get; set; }
        public string Language { get; set; }
    }
}
