﻿using System.Collections.Generic;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs
{
    public class ExamDTO : ResponseBase
    {
        public int id { get; set; }
        public string Name { get; set; }
        public int ExamTime { get; set; }
        public int NumberQuestions { get; set; }
        public int UnitId { get; set; }
        public virtual UnitDTO Unit { get; set; }
        public virtual List<QuestionDTO> Questions { get; set; }
    }
}
