﻿using System.Collections.Generic;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs
{
    public class CareersAndUsersByPositionJobDTO : ResponseBase
    {
        public int PositionId { get; set; }
        public List<UserForPositionsJob> UserForJobList { get; set; }
        public List<CareerForPositionsJob> CareerForJobList { get; set; }
    }

    public class UserForPositionsJob
    {
        public int UserId { get; set; }
        public int PositionJobId { get; set; }
        public string UserName { get; set; }
        public string Name { get; set; }
        public string PositionJob { get; set; }
        public bool IsSelected { get; set; }

    }

    public class CareerForPositionsJob
    {
        public int PositionJobId { get; set; }
        public int CareerId { get; set; }
        public string Description { get; set; }
        public int NotaAprobacion { get; set; }
        public int NoSemanas { get; set; }
        public string Name { get; set; }
        public bool IsSelected { get; set; }

    }
}
