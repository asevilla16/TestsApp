﻿using System.Collections.Generic;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs
{
    public class FacilityDTO : ResponseBase
    {
        public int FacilityId { get; set; }
        public string Facility_Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string ImageLogo { get; set; }

        public List<AreaDTO> Areas { get; set; }
        public List<PositionDTO> Position { get; set; }
    }
}
