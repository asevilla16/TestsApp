﻿namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs
{
    public class AnswerDTO : ResponseBase
    {
        public int id { get; set; }
        public string Description { get; set; }
        public bool IsCorrectAnswer { get; set; }
        public int QuestionId { get; set; }
        public virtual QuestionDTO Question { get; set; }
    }
}
