﻿using System.Collections.Generic;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs
{
    public class CareerDTO : ResponseBase
    {
        public int ResourceId { get; set; }
        public int CareerId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int FacilityId { get; set; }
        public int ApprovalRate { get; set; }
        public int HasFollowUp { get; set; }
        public int QuantityWeeksEnabled { get; set; }
        public List<UnitDTO> Units { get; set; }
    }
}
