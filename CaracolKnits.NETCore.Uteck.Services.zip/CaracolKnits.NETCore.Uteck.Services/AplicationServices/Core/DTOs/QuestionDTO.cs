﻿using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.QuestionTypeAgg;
using System.Collections.Generic;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs
{
    public class QuestionDTO : ResponseBase
    {
        public int id { get; set; }
        public string Description { get; set; }
        public string ImageURL { get; set; }
        public int QuestionTypeId { get; set; }
        public virtual QuestionType QuestionType { get; set; }
        public int ExamId { get; set; }
        public virtual ExamDTO Exam { get; set; }
        public virtual List<AnswerDTO> Answers { get; set; }
    }
}
