﻿using System;
using System.Collections.Generic;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs
{
    public class CareerAdvancementDTO : ResponseBase
    {
        public int CareerAdvancementId { get; set; }
        public int CareerId { get; set; }
        public string Career { get; set; }
        public string Description { get; set; }
        public string UserName { get; set; }
        public string UserFullName { get; set; }
        public DateTime? InitialDate { get; set; }
        public DateTime? FinalDate { get; set; }
        public int TimeSpent { get; set; }
        public int Progress { get; set; }
        public string Period { get; set; }
        public int IsOpen { get; set; }
        public int TotalScore { get; set; }
        public int NotaAprobacion { get; set; }
        public int NoSemanas { get; set; }
        public int UserId { get; set; }
        public List<UnitAdvancementDTO> UnitAdvancements { get; set; }
    }
}
