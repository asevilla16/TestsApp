﻿
namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs
{
    public class UserDTO : ResponseBase
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string FullName { get; set; }
        public string Facility_Id { get; set; }
        public string EmailAddress { get; set; }
        public string LanguageId { get; set; }
        public string RolName { get; set; }
        public string AreaName { get; set; }
        public string PositionJob { get; set; }
        public int RolId { get; set; }
        public int? PositionId { get; set; }
        public int? AreaId { get; set; }
    }
}
