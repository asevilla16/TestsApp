﻿
namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs
{
    public class PermissionByRolDTO : ResponseBase
    {
        public int PermissionByRolId { get; set; }
        public int RolId { get; set; }
        public int PermissionId { get; set; }
    }
}
