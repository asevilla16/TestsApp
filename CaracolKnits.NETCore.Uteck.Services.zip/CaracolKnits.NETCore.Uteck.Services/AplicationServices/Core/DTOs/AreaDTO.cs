﻿using System.Collections.Generic;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs
{
    public class AreaDTO : ResponseBase
    {
        public int AreaId { get; set; }
        public int Code { get; set; }
        public string Name { get; set; }
        public int FacilityId { get; set; }
        public List<UserDTO> Users { get; set; }
    }
}
