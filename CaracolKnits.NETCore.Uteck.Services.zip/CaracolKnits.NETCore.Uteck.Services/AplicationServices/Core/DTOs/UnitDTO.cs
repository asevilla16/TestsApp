﻿using System.Collections.Generic;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs
{
    public class UnitDTO : ResponseBase
    {
        public int UnitId { get; set; }
        public string Name { get; set; }
        public string Objective { get; set; }
        public int ApprovalRate { get; set; }
        public int CareerId { get; set; }
        public List<ResourceDTO> Resources { get; set; }
    }
}
