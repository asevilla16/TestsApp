﻿namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs
{
    public class EnrollmentMasiveDTO
    {
        public int UserId { get; set; }
        public int CarrerId { get; set; }
        public string UserNAme { get; set; }
        public string FullName { get; set; }
        public string CareerName { get; set; }
    }
}
