namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs
{
    public class ResponseBase
    {
        public string Message { get; set; }
        public bool Success { get; set; }
        public string ValidationErrorMessage { get; set; }
    }
}