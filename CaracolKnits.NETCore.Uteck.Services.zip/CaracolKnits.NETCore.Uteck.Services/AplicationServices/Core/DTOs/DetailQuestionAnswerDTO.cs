﻿namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs
{
    public class DetailQuestionAnswerDTO
    {
        public int DetailQuestionAnswerId { get; set; }
        public int ExamId { get; set; }
        public string NameExam { get; set; }
        public string Quetion { get; set; }
        public string CorrectAnswer { get; set; }
        public string SelectedAnswer { get; set; }
        public int ExamAdvancementId { get; set; }
    }
}
