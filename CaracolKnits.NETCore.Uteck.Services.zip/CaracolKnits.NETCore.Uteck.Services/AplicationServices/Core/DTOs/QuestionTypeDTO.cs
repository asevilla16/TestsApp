﻿namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs
{
    public class QuestionTypeDTO : ResponseBase
    {
        public int id { get; set; }
        public string Description { get; set; }
    }
}
