﻿
namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class ConfigurationRequest : RequestBase
    {
        public int ConfirutarionId { get; set; }
        public string Facility { get; set; }
        public string Description { get; set; }
        public string Attribute { get; set; }
        public string Value { get; set; }
    }
}
