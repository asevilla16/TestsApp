using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class RequestBase
    {
        public UserInfoDto RequestUserInfo { get; set; }
    }
}