﻿using System;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class CareerAdvancementRequest : RequestBase
    {
        public int CareerAdvancementId { get; set; }
        public int UserId { get; set; }
        public int UnitAdvancementId { get; set; }
        public int Progress { get; set; }
        public int NotaAprobacion { get; set; }
    }
}
