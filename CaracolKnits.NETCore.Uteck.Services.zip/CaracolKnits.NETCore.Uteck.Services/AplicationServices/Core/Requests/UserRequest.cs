﻿
namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class UserRequest : RequestBase
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string FullName { get; set; }
        public string Password { get; set; }
        public string Facility_Id { get; set; }
        public string EmailAddress { get; set; }
        public string LanguageId { get; set; }
        public int RolId { get; set; }
        public int AreaId { get; set; }

    }
}
