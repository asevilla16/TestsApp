﻿namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class UnitAdvancementRequest : RequestBase
    {
        public int UnitAdvancementId { get; set; }
        public int CareerAdvancementId { get; set; }
        public int Progress { get; set; }
        public int NotaAprobacion { get; set; }
    }
}
