﻿using System;
using System.Collections.Generic;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class ExamAdvancementRequest : RequestBase
    {
        public int ExamAdvancementId { get; set; }
        public int ExamId { get; set; }
        public string NameExam { get; set; }
        public int ExamTime { get; set; }
        public int NumberQuestions { get; set; }
        public string UserName { get; set; }
        public string UserFullName { get; set; }
        public DateTime? InitialDate { get; set; }
        public DateTime? FinalDate { get; set; }
        public int TimeSpent { get; set; }
        public string Period { get; set; }
        public int IsOpen { get; set; }
        public int TotalScore { get; set; }
        public int UnitAdvancementId { get; set; }
        public int UserId { get; set; }
        public List<DetailQuestionAnswerRequest> DetailsQuestionsAnswers { get; set; }

    }
}
