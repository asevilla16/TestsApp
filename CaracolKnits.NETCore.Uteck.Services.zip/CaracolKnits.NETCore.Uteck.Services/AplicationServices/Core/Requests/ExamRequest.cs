﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using System.Collections.Generic;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class ExamRequest : RequestBase
    {
        public int id { get; set; }
        public string Name { get; set; }
        public int ExamTime { get; set; }
        public int NumberQuestions { get; set; }
        public int UnitId { get; set; }
        public List<QuestionRequest> Questions { get; set; }
    }
}
