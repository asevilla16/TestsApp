﻿namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class AuthenticateAutomaticRequest : RequestBase
    {
        public string UserName { get; set; }
        public string Facility { get; set; }
    }
}
