﻿using System.Collections.Generic;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class QuestionRequest : RequestBase
    {
        public int id { get; set; }
        public string Description { get; set; }
        public string ImageURL { get; set; }
        public int QuestionTypeId { get; set; }
        public int ExamId { get; set; }
        public List<AnswerRequest> Answers { get; set; }
    }
}
