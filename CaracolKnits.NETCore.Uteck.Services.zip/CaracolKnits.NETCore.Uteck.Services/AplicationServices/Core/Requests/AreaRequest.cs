﻿
namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class AreaRequest : RequestBase
    {
        public int AreaId { get; set; }
        public int Code { get; set; }
        public string Name { get; set; }
        public int FacilityId { get; set; }
    }
}
