﻿namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class UnitRequest : RequestBase
    {
        public int UnitId { get; set; }
        public string Name { get; set; }
        public string Objective { get; set; }
        public int ApprovalRate { get; set; }
        public int CareerId { get; set; }
    }
}
