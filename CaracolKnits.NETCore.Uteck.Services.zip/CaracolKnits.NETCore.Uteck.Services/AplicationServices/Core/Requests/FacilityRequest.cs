﻿
using System.Collections.Generic;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class FacilityRequest : RequestBase
    {
        public int FacilityId { get; set; }
        public string Facility_Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string ImageLogo { get; set; }
        public ICollection<AreaRequest> Areas { get; set; }
    }
}
