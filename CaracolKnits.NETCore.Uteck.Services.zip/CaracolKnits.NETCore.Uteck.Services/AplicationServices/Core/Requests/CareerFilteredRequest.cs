﻿namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class CareerFilteredRequest : RequestBase
    {
        public int FacilityId { get; set; }
    }
}
