﻿
namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class PermissionByRolRequest : RequestBase
    {
        public int PermissionByRolId { get; set; }
        public int RolId { get; set; }
        public int PermissionId { get; set; }
    }
}
