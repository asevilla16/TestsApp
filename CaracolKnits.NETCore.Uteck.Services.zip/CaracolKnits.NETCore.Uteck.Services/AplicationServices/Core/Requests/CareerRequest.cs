﻿namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class CareerRequest : RequestBase
    {
        public int CareerId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int FacilityId { get; set; }
        public int NotaAprobacion { get; set; }
        public int OscarSeguimiento { get; set; }
        public int NoSemanas { get; set; }
    }
}
