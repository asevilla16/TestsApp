﻿using System.Collections.Generic;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class AssignCareerToPositionListRequest : RequestBase
    {
        public List<AssignCareerToPositionRequest> CareerToPositionList { get; set; }
    }
}
