﻿using Microsoft.AspNetCore.Http;
using Microsoft.SharePoint.Client;
using System;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class ResourceRequest : RequestBase
    {
        public int ResourceId { get; set; }
        public string Name { get; set; }
        public string ResourceUrl { get; set; }
        public int IsRequired { get; set; }
        public int TimeRequired { get; set; }
        public string ResourceType { get; set; }
        public string FileExtension { get; set; }
        public string FileName { get; set; }
        public string ItemId { get; set; }
        public int UnitId { get; set; }
    }
}
