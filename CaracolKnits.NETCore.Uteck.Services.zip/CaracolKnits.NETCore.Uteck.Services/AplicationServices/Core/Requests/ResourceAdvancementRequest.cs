﻿using System;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class ResourceAdvancementRequest : RequestBase
    {
        public int ResourceAdvancementId { get; set; }
        public DateTime? InitialDate { get; set; }
        public DateTime? FinalDate { get; set; }
        public int TimeResource { get; set; }
        public int TimeSpent { get; set; }
        public int Progress { get; set; }
    }
}
