﻿namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class PositionRequest : RequestBase
    {
        public int PositionId { get; set; }
        public string PositionJob { get; set; }
        public string Name { get; set; }
        public int FacilityId { get; set; }

    }
}
