﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using System.Collections.Generic;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class EnrollMasiveRequest : RequestBase
    {
        public List<CareersAndUsersByPositionJobDTO> CareersAndUsersByPositionJob { get; set; }
    }
}
