﻿namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class AnswerRequest
    {
        public int id { get; set; }
        public string Description { get; set; }
        public bool IsCorrectAnswer { get; set; }
        public int QuestionId { get; set; }
    }
}
