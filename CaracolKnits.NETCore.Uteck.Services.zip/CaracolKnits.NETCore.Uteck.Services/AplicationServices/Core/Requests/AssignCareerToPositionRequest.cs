﻿namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class AssignCareerToPositionRequest: RequestBase
    {
        public int CareerId { get; set; }
        public int PositionId { get; set; }
    }
}
