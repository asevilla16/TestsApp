﻿
namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class RolRequest : RequestBase
    {
        public int RolId { get; set; }
        public string RolName { get; set; }
    }
}
