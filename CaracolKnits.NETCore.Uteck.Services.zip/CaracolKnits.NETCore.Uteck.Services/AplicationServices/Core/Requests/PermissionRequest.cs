﻿
namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class PermissionRequest : RequestBase
    {
        public int PermissionId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
