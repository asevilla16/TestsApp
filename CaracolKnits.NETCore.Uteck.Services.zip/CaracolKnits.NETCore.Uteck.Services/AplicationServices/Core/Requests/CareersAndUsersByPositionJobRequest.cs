﻿using System.Collections.Generic;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests
{
    public class CareersAndUsersByPositionJobRequest : RequestBase
    {
        public List<int> PositionsJobIds { get; set; }
    }
}
