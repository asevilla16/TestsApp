﻿using System;
using CaracolKnits.NETCore.Uteck.Services;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices
{
    public abstract class BaseAppService : IDisposable
    {
        protected readonly IGenericRepository<IGenericDataContext> _repository;

        public BaseAppService(IGenericRepository<IGenericDataContext> repository)
        {
            _repository = repository;
        }

        public void Dispose()
        {
            _repository.Dispose();
        }
    }
}
