﻿using Caracolknits.ShippingCenter.Api.Infraestructure.Core;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.ConfigurationAppServices;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.PermissionAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.PermissionByRolAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.RolAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UserAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.Extensions.Options;
using System.Security.Claims;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.AreaAgg;
using CaracolKnits.NETCore.Uteck.Services.Infraestructure.Core.AuthenticateManager;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.PositionAgg;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.UserAppService
{
    public class UserAppService : BaseAppService, IUserAppService
    {
        private readonly IConfigurationAppService _configurationAppService;
        private readonly IWebHostEnvironment _environment;
        private readonly AppSettings _appSettings;

        public UserAppService(IGenericRepository<IGenericDataContext> repository,
                                IConfigurationAppService configurationAppService,
                                IWebHostEnvironment environment,
                                IOptions<AppSettings> appSettings) : base(repository)
        {
            _configurationAppService = configurationAppService;
            _environment = environment;
            _appSettings = appSettings.Value;
        }

        public async Task<LoginDTO> AuthenticateUser(LoginRequest request)
        {

            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.UserName, nameof(request.UserName));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.Password, nameof(request.Password));

            var password = CreateHash(request.UserName, request.Password);

            User user = await _repository.GetSingleAsync<User>(u => u.Password == password && u.UserName == request.UserName && u.IsActive == true);

            if (user == null)
            {
                return new LoginDTO { ValidationErrorMessage = "Usuario o contraseña incorrecta" };
            }

            var token = BuildToken(user);
            var authenticationManager = new AuthenticationManager();
            return new LoginDTO
            {
                UserId = user.Id,
                UserName = user.UserName,
                Language = user.LanguageId,
                Email = user.EmailAddress,
                Facility = user.Facility_Id,
                PermissionUser = await GetPermissionByUser(user.RolId),
                IsAuthenticated = true,
                Success = true,
                Token = token,
                TokenSp = await authenticationManager.GetToken(),
                DriveId = await authenticationManager.GetDriveId(),

            };

        }

        public async Task<LoginDTO> AuthenticateAutomatic(AuthenticateAutomaticRequest request)
        {
            ConfigurationDTO configurationDetail = await _configurationAppService.GetConfiguration("prueba", request.Facility, request.RequestUserInfo.Language);

            ThrowIf.Argument.IsNull(configurationDetail, configurationDetail.ValidationErrorMessage);

            bool isDevelopment = _environment.IsDevelopment();

            if (isDevelopment)
            {
                configurationDetail.Value = "http://localhost:53743/api/v1/";
                //configurationDetail.Value = "http://localhost:64627/api/v1/";
            }

            string baseUrl = string.Format("{0}/cross-cutting/authentication/find-user-with-password?userId={1}", configurationDetail.Value, request.UserName);

            UserCtsDTO userCTS = await Task.Run(async () => await RestClientFactory.CreateClient(baseUrl).GetAsync<UserCtsDTO>(baseUrl));

            if (userCTS == null)
            {
                return new LoginDTO { ValidationErrorMessage = "User doesn't exist or need import it" };
            }

            UserInfoDto requestUserInfo = new()
            {
                ModifiedBy = "CTS.NET",
                CreatedBy = "CTS.NET",
                TransactionType = "CreateUser",
                TransactionDescription = "Import user from CTS.NET"
            };

            User user = await _repository.GetSingleAsync<User>(u => u.UserName == userCTS.UserName && u.IsActive == true);

            TransactionInfo transactionInfo;

            if (user == null)
            {
                user = new User
                {
                    UserName = userCTS.UserName,
                    Password = userCTS.Password,
                    FullName = userCTS.Name,
                    EmailAddress = userCTS.Email,
                    LanguageId = userCTS.Language,
                    Facility_Id = request.Facility,
                    RolId = 3,
                };
                await _repository.AddAsync(user);

                transactionInfo = TransactionInfoFactory.CrearTransactionInfo(requestUserInfo, Transactions.createUser);
                await _repository.UnitOfWork.CommitAsync(transactionInfo);

            }

            if (user.Facility_Id != request.Facility)
            {
                return new LoginDTO { ValidationErrorMessage = "Debes Ingresar desde tu planta correspondiente" };
            }

            if (user.Password != userCTS.Password)
            {
                user.Password = userCTS.Password;
                _repository.Update(user);
                transactionInfo = TransactionInfoFactory.CrearTransactionInfo(requestUserInfo, Transactions.updatePassword);
                await _repository.UnitOfWork.CommitAsync(transactionInfo);

            }

            return new LoginDTO
            {
                UserName = user.UserName,
                Language = user.LanguageId,
                Email = user.EmailAddress,
                Facility = request.Facility,
                IsAuthenticated = true,
                Success = true,
                Token = BuildToken(user)
            };
        }

        public async Task<List<PermissionUser>> GetPermissionByUser(int rolId)
        {
            List<PermissionUser> permissionUserResponse = new();

            IEnumerable<PermissionByRol> permissionUser = await _repository.GetFilteredAsync<PermissionByRol>(x =>
                                                          x.RolId == rolId && x.IsActive == true);

            var permissionId = permissionUser.Select(x => x.PermissionId).ToList();

            IEnumerable<Permission> permission = await _repository.GetFilteredAsync<Permission>(i => permissionId.Contains(i.Id) && i.IsActive == true);
            permissionUserResponse = permission.Select(i => new PermissionUser
            {
                RolId = rolId,
                Permission = i.Name,
            }).ToList();

            return permissionUserResponse;
        }

        public async Task<List<UserDTO>> GetAllUsers()
        {

            var Users = await _repository.GetFilteredAsync<User>(x => x.IsActive == true);
            List<UserDTO> UsersResponse = Users.Select(x => new UserDTO
            {
                UserId = x.Id,
                UserName = x.UserName,
                FullName = x.FullName,
                Facility_Id = x.Facility_Id,
                LanguageId = x.LanguageId,
                EmailAddress = x.EmailAddress,
                RolId = x.RolId,
                AreaId = x.AreaId,
                PositionId= x.PositionJobId,
                RolName = GetRolName(x.RolId),
                AreaName = GetAreaName(x.AreaId),
                PositionJob = GetPositionJobName(x.PositionJobId),
                Success = true,

            }).ToList();

            return UsersResponse;
        }

        public string GetRolName(int rolId)
        {
            string rolName = "";

            var rol = _repository.GetSingle<Rol>(x => x.Id == rolId && x.IsActive == true);
            if (rol != null)
            {
                rolName = rol.RolName;
            }

            return rolName;
        }

        public string GetPositionJobName(int? PositionJobId)
        {
            string positionName = "";

            var position = _repository.GetSingle<Position>(x => x.Id == PositionJobId && x.IsActive == true);
            if (position != null)
            {
                positionName = String.Format("{0} {1}", position.PositionJob, position.Name);
            }

            return positionName;
        }

        public string GetAreaName(int? areaId)
        {
            string areaName = "";

            var area = _repository.GetSingle<Area>(x => x.Id == areaId && x.IsActive == true);
            if (area != null)
            {
                areaName = String.Format("{0} - {1}", area.Code, area.Name);
            }

            return areaName;
        }
        public async Task<UserDTO> GetUser(UserRequest request)
        {

            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.UserName, nameof(request.UserName));
            var user = await _repository.GetSingleAsync<User>(x => x.UserName == request.UserName && x.IsActive == true);
            if (user != null)
            {
                return new UserDTO { ValidationErrorMessage = "Usuario no existe" };
            }

            UserDTO UserResponse = new()
            {
                UserId = user.Id,
                UserName = user.UserName,
                FullName = user.FullName,
                Facility_Id = user.Facility_Id,
                EmailAddress = user.EmailAddress,
                LanguageId = user.LanguageId,
                RolId = user.RolId,
                AreaId = user.AreaId,
                Success = true,
            };

            return UserResponse;
        }

        public async Task<Response> CreateUser(UserRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.UserName, nameof(request.UserName));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.Password, nameof(request.Password));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.FullName, nameof(request.FullName));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.Facility_Id, nameof(request.Facility_Id));

            var UserExists = await _repository.GetSingleAsync<User>(x => x.UserName == request.UserName && x.IsActive == true);
            if (UserExists != null)
            {
                return new Response { ValidationErrorMessage = "Usurio ya existe" };
            }

            User NewUser = new()
            {
                UserName = request.UserName,
                Password = CreateHash(request.UserName, request.Password),
                FullName = request.FullName,
                Facility_Id = request.Facility_Id,
                AreaId = request.AreaId,
                EmailAddress = request.EmailAddress,
                LanguageId = request.LanguageId,
                RolId = request.RolId,
            };

            await _repository.AddAsync(NewUser);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.createUser);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);
            return new Response { Success = true };
        }

        public async Task<Response> UpdateUser(UserRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.UserName, nameof(request.UserName));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.Password, nameof(request.Password));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.FullName, nameof(request.FullName));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.Facility_Id, nameof(request.Facility_Id));

            var existingUser = await _repository.GetSingleAsync<User>(x => x.UserName == request.UserName && x.IsActive == true);

            if (existingUser == null)
            {
                return new Response { ValidationErrorMessage = "Usuario no existe" };
            }

            existingUser = BuildUser(request);

            _repository.Update(existingUser);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.update);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);

            return new Response { Success = true };

        }

        public async Task<Response> DeleteUser(UserRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.UserName, nameof(request.UserName));
            ThrowIf.Argument.IsZeroOrNegative(request.UserId, nameof(request.UserId));

            User user = await _repository.GetSingleAsync<User>(x=>x.Id == request.UserId && x.IsActive == true);

            if(user == null)
            {
                return new Response { ValidationErrorMessage = "Usuario no Existe" };
            }

            user.IsActive= false;
            _repository.Update(user);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.deleteUser);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);

            return new Response { Success = true };
        }

            public string CreateHash(string salt, string stringToHash)
        {
            //Utilizar las primeras 2 letras del nombre de usuario para el salt
            return HashData(string.Format("{0}{1}", salt.Substring(0, 2), stringToHash));
        }

        private string HashData(string stringToHash)
        {
            SHA256 hasher = new SHA256Managed();
            byte[] hashedData = hasher.ComputeHash(Encoding.Unicode.GetBytes(stringToHash));
            var sb = new StringBuilder(hashedData.Length * 2);

            foreach (byte b in hashedData)
            {
                sb.AppendFormat("{0:x2}", b);
            }

            return sb.ToString();
        }

        private string BuildToken(User user)
        {
            var tokenHandler = new JwtSecurityTokenHandler();

            var keyValue = Encoding.ASCII.GetBytes(_appSettings.Secreto);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                    new Claim(ClaimTypes.Name, user.UserName.ToString())
                }),
                Expires = System.DateTime.UtcNow.AddDays(1),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(keyValue), SecurityAlgorithms.HmacSha256Signature),
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        private User BuildUser(UserRequest request)
        {
            return new User
            {
                UserName = request.UserName,
                //Password = request.Password,
                FullName = request.FullName,
                EmailAddress = request.EmailAddress,
                Facility_Id = request.Facility_Id,
                AreaId = request.AreaId,
                LanguageId = request.LanguageId,
                RolId = request.RolId
            };
        }
    }
}
