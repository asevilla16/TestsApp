﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.UserAppService
{
    public interface IUserAppService : IDisposable
    {
        Task<List<UserDTO>> GetAllUsers();
        Task<UserDTO> GetUser(UserRequest request);
        Task<Response> CreateUser(UserRequest request);
        Task<Response> UpdateUser(UserRequest request);
        Task<LoginDTO> AuthenticateUser(LoginRequest request);
        Task<LoginDTO> AuthenticateAutomatic(AuthenticateAutomaticRequest request);
        Task<Response> DeleteUser(UserRequest request);
    }
}
