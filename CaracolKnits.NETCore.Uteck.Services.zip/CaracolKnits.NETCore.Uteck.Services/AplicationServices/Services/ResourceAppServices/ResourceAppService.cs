﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ResourceAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.ResourceAppServices
{
    public class ResourceAppService : BaseAppService, IResourceAppService
    {

        public ResourceAppService(IGenericRepository<IGenericDataContext> repository) : base(repository)
        {
        }


        public string Translate(string key, string language)
        {
            string value = Translations.CreateTranslation().GetTranslation(language, key);

            return value;
        }

        public async Task<List<ResourceDTO>> GetResourceFiltered(UnitRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsZeroOrNegative(request.UnitId, nameof(request.UnitId));

            IEnumerable<Resource> resources = await _repository.GetFilteredAsync<Resource>(x => x.UnitId == request.UnitId);
            List<ResourceDTO> resourcesList = resources.Select(x => new ResourceDTO
            {
                ResourceId = x.Id,
                Name = x.Name,
                TimeRequired = x.TimeRequired,
                ResourceUrl = x.ResourceUrl,
                ResourceType = x.ResourceType,
                IsRequired = x.IsRequired,
                FileExtension = x.FileExtension,
                FileName = x.FileName,
                ItemId = x.ItemId,
                UnitId = request.UnitId,
            }).ToList();

            return resourcesList;

        }

        public async Task<Response> CreateResource(ResourceRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.Name, nameof(request.Name));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.ResourceUrl, nameof(request.ResourceUrl));
            ThrowIf.Argument.IsNull(request.IsRequired, nameof(request.IsRequired));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.ResourceType, nameof(request.ResourceType));
            ThrowIf.Argument.IsZeroOrNegative(request.UnitId, nameof(request.UnitId));


            Resource resources = await _repository.GetSingleAsync<Resource>(x => x.Name == request.Name && x.UnitId == request.UnitId && x.IsActive==true);
            if (resources != null)
            {
                return new Response
                {
                    ValidationErrorMessage =
                    Translate(Translations.aResourceWithThatNameAlreadyExistsOnThisUnit, request.RequestUserInfo.Language)
                };

            }
            resources = new Resource()
            {
                UnitId = request.UnitId,
                Name = request.Name,
                ResourceUrl = request.ResourceUrl,
                IsRequired = request.IsRequired,
                ResourceType = request.ResourceType,
                FileName = request.FileName,
                FileExtension = request.FileExtension,
                ItemId = request.ItemId,
                TimeRequired = request.TimeRequired,
            };

            await _repository.AddAsync(resources);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.createResource);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);

            return new Response { Success = true };

        }

        public async Task<Response> EditResource(ResourceRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.Name, nameof(request.Name));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.ResourceUrl, nameof(request.ResourceUrl));
            ThrowIf.Argument.IsNull(request.IsRequired, nameof(request.IsRequired));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.ResourceType, nameof(request.ResourceType));
            ThrowIf.Argument.IsZeroOrNegative(request.UnitId, nameof(request.UnitId));
            ThrowIf.Argument.IsZeroOrNegative(request.ResourceId, nameof(request.ResourceId));


            Resource resources = await _repository.GetSingleAsync<Resource>(x => x.Id == request.ResourceId && x.IsActive == true);
            if (resources == null)
            {
                return new Response
                {
                    ValidationErrorMessage =
                    Translate(Translations.theResourceDoesNotExist, request.RequestUserInfo.Language)
                };

            }


            resources.Id = request.ResourceId;
            resources.UnitId = request.UnitId;
            resources.Name = request.Name;
            resources.ResourceUrl = request.ResourceUrl;
            resources.IsRequired = request.IsRequired;
            resources.ResourceType = request.ResourceType;
            resources.FileExtension = request.FileExtension;
            resources.FileName = request.FileName;
            resources.ItemId = request.ItemId;
            resources.TimeRequired = request.TimeRequired;

             _repository.Update(resources);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.createResource);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);

            return new Response { Success = true };

        }

        public async Task<Response> DeleteResource(ResourceRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsZeroOrNegative(request.ResourceId, nameof(request.ResourceId));


            Resource resources = await _repository.GetSingleAsync<Resource>(x => x.Id == request.ResourceId && x.IsActive == true);
            if (resources == null)
            {
                return new Response
                {
                    ValidationErrorMessage =
                    Translate(Translations.theResourceDoesNotExist, request.RequestUserInfo.Language)
                };

            }


            resources.IsActive = false;

            _repository.Update(resources);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.createResource);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);

            return new Response { Success = true };

        }

    }
}
