﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.ResourceAppServices
{
    public interface IResourceAppService
    {
        Task<List<ResourceDTO>> GetResourceFiltered(UnitRequest request);
        Task<Response> CreateResource(ResourceRequest request);
        Task<Response> EditResource(ResourceRequest request);
        Task<Response> DeleteResource(ResourceRequest request);
    }
}
