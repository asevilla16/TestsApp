﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.QuestionAppService
{
    public interface IQuestionAppService : IDisposable
    {
        Task<List<QuestionDTO>> GetAllQuestions(int examId);
        Task<Response> CreateQuestionWithAnswers(QuestionRequest request);
        Task<List<QuestionTypeDTO>> GetQuestionTypes();
    }
}
