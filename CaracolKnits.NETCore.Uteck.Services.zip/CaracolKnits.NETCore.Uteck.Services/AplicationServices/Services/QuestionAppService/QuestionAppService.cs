﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.AnswerAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.QuestionAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.QuestionTypeAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.QuestionAppService
{
    public class QuestionAppService : BaseAppService, IQuestionAppService
    {

        public QuestionAppService(IGenericRepository<IGenericDataContext> repository) : base(repository)
        {

        }

        public async Task<List<QuestionDTO>> GetAllQuestions(int examId)
        {
            List<string> includes = new List<string> { "Exam", "Answers" };
            IEnumerable<Question> questions = await _repository.GetAllIncludeAsync<Question>(x => x.ExamId == examId, includes);

            List<QuestionDTO> result = questions.Select(x => new QuestionDTO
            {
                id = x.Id,
                Description = x.Description,
                ImageURL = x.ImageURL,
                QuestionTypeId = x.QuestionTypeId,
                ExamId = x.ExamId,
                Answers = x.Answers.Select(x => new AnswerDTO { id = x.Id, Description = x.Description, IsCorrectAnswer = x.IsCorrectAnswer, QuestionId = x.QuestionId }).ToList()
            }).ToList();

            return result;
        }

        public async Task<Response> CreateQuestionWithAnswers(QuestionRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.Description, nameof(request.Description));
            ThrowIf.Argument.IsZeroOrNegative(request.QuestionTypeId, nameof(request.QuestionTypeId));
            ThrowIf.Argument.IsZeroOrNegative(request.ExamId, nameof(request.ExamId));

            Question existingQuestion = _repository.GetSingle<Question>(x => 
                                                x.Description == request.Description && 
                                                x.ExamId == request.ExamId);

            if (existingQuestion != null)
            {
                return new Response { ValidationErrorMessage = "La pregunta ingresada ya fue agregada al examen" };
            }

            Question question = new Question
            {
                Description = request.Description,
                ImageURL = request.ImageURL,
                QuestionTypeId = request.QuestionTypeId,
                ExamId = request.ExamId,
                Answers = request.Answers.Select(x => new Answer { Description = x.Description, IsCorrectAnswer = x.IsCorrectAnswer }).ToList()
            };

            await _repository.AddAsync(question);

            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.createExam);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);
            return new Response { Success = true };

        }

        public async Task<List<QuestionTypeDTO>> GetQuestionTypes()
        {
            var questionTypes = await _repository.GetAllAsync<QuestionType>();

            List<QuestionTypeDTO> result = questionTypes.Select(x => new QuestionTypeDTO
            {
                id = x.Id,
                Description = x.Description
            }).ToList();

            return result;
        }

    }
}
