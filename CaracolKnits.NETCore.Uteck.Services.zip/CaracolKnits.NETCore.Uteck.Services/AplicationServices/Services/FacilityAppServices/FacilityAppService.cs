﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.AreaAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.FacilityAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.FacilityAppServices
{
    public class FacilityAppService : BaseAppService, IFacilityAppService
    {
        public FacilityAppService(IGenericRepository<IGenericDataContext> repository) : base(repository)
        {

        }

        public async Task<List<FacilityDTO>> GetAllFacilities()
        {
            List<string> includes = new List<string> { "Area", "Position" };
            IEnumerable<Facility> facilities = await _repository.GetAllIncludeAsync<Facility>(includes);

            List<FacilityDTO> facilitiesResponse = facilities.Select(x => new FacilityDTO
            {
                FacilityId = x.Id,
                Facility_Id = x.Facility_Id,
                Name = x.Name,
                Description = x.Description,
                ImageLogo = x.ImageLogo,
                Areas = x.Area.Select(i => new AreaDTO
                {
                    AreaId = i.Id,
                    Code = i.Code,
                    Name = i.Name,
                    FacilityId = i.FacilityId,
                    Success = true,
                }).ToList(),
                Position = x.Position.Select(i => new PositionDTO
                {
                    PositionId = i.Id,
                    PositionJob = i.PositionJob,
                    Name = i.Name,
                    FacilityId = i.FacilityId,
                }).ToList(),
                Success = true,
            }).ToList();

            return facilitiesResponse;
        }

        public async Task<List<FacilityDTO>> GetAllFacilitiesWithPosition()
        {
            List<string> includes = new List<string> { "Position" };
            IEnumerable<Facility> facilities = await _repository.GetAllIncludeAsync<Facility>(includes);

            List<FacilityDTO> facilitiesResponse = facilities.Select(x => new FacilityDTO
            {
                FacilityId = x.Id,
                Facility_Id = x.Facility_Id,
                Name = x.Name,
                Description = x.Description,
                ImageLogo = x.ImageLogo,
                Position = x.Position.Select(i => new PositionDTO
                {
                    PositionId = i.Id,
                    PositionJob = i.PositionJob,
                    Name = i.Name,
                    FacilityId = i.FacilityId,
                }).ToList(),
                Success = true,
            }).ToList();

            return facilitiesResponse;
        }

        public async Task<Response> CreateFacility(FacilityRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.Name, nameof(request.Name));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.Facility_Id, nameof(request.Facility_Id));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.Description, nameof(request.Description));

            Facility facility = _repository.GetSingle<Facility>(x => x.Facility_Id == request.Facility_Id);
            if (facility != null)
            {
                return new Response { ValidationErrorMessage = "Ya existe esta planta" };
            }

            

            facility = new Facility
            {
                Facility_Id = request.Facility_Id,
                Name = request.Name,
                Description = request.Description,
                ImageLogo = request.ImageLogo,
                Area = request.Areas.Select(area => new Area { Code = area.Code, Name = area.Name }).ToList()

        };
            await _repository.AddAsync(facility);

            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.createRole);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);
            return new Response { Success = true };
        }

    }
}
