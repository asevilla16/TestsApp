﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.FacilityAppServices
{
    public interface IFacilityAppService
    {
        Task<Response> CreateFacility(FacilityRequest request);
        Task<List<FacilityDTO>> GetAllFacilities();
        Task<List<FacilityDTO>> GetAllFacilitiesWithPosition();
    }
}
