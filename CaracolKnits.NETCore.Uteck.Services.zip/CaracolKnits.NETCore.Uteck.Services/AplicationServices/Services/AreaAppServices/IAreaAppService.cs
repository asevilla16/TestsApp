﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.AreaAppServices
{
    public interface IAreaAppService
    {
        Task<Response> CreateArea(AreaRequest request);
        Task<List<AreaDTO>> GetAllAreas();
    }
}
