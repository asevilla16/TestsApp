﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.AreaAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.AreaAppServices
{
    public class AreaAppService : BaseAppService, IAreaAppService
    {
        public AreaAppService(IGenericRepository<IGenericDataContext> repository) : base(repository)
        {

        }

        public async Task<List<AreaDTO>> GetAllAreas()
        {
            List<string> includes = new List<string> { "User" };
            IEnumerable<Area> areas = await _repository.GetAllIncludeAsync<Area>(includes);

            List<AreaDTO> areasResponse = areas.Select(x => new AreaDTO
            {
                AreaId = x.Id,
                Code = x.Code,
                Name = x.Name,
                FacilityId = x.FacilityId,
                Users = x.User.Select(i => new UserDTO
                {
                    UserId = i.Id,
                    FullName = i.FullName,
                    Facility_Id = i.Facility_Id,
                    UserName = i.UserName,
                    EmailAddress = i.EmailAddress,
                    LanguageId = i.LanguageId,
                    RolId = i.RolId,
                    AreaId = i.AreaId,
                    Success = true,

                }).ToList(),
                Success = true,

            }).ToList();

            return areasResponse;
        }

        public async Task<Response> CreateArea(AreaRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsZeroOrNegative(request.Code, nameof(request.Code));
            ThrowIf.Argument.IsNull(request.Name, nameof(request.Name));
            ThrowIf.Argument.IsZeroOrNegative(request.FacilityId, nameof(request.FacilityId));
            Area area = _repository.GetSingle<Area>(x => x.Code == request.Code);
            if (area != null)
            {
                return new Response { ValidationErrorMessage = "Planta ya existe" };
            }

            area = new()
            {
                Code = request.Code,
                Name = request.Name,
                FacilityId = request.FacilityId,
            };

            await _repository.AddAsync(area);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.createFacility);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);

            return new Response { Success = true };
        }
    }
}
