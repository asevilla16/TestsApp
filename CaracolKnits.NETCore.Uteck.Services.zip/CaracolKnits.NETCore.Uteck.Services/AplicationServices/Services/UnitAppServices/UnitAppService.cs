﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ResourceAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UnitAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.UnitAppServices
{
    public class UnitAppService : BaseAppService, IUnitAppService
    {
        public UnitAppService(IGenericRepository<IGenericDataContext> repository) : base(repository)
        {

        }


        public string Translate(string key, string language)
        {
            string value = Translations.CreateTranslation().GetTranslation(language, key);

            return value;
        }

        public async Task<List<UnitDTO>> GetUnitsFiltered(UnitRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsZeroOrNegative(request.CareerId, nameof(request.CareerId));


            IEnumerable<Unit> units = await _repository.GetFilteredAsync<Unit>(x =>
                                                          x.CareerId == request.CareerId && x.IsActive == true);
            List<int> unitIds = units.Select(x => x.Id).ToList();

            _ = await _repository.GetFilteredAsync<Resource>(x => unitIds.Contains(x.UnitId) && x.IsActive==true);

            List<UnitDTO> unitsResponse = units.Select(x => new UnitDTO
            {
                UnitId = x.Id,
                Name = x.Name,
                Objective = x.Objective,
                CareerId = x.CareerId,
                ApprovalRate = x.NotaAprobacion,
                Resources = x.Resource?.Select(i=>new ResourceDTO()
                {
                    ResourceId = i.Id,
                    UnitId = i.UnitId,
                    Name = i.Name,
                    ResourceType = i.ResourceType,
                    ResourceUrl = i.ResourceUrl,
                    IsRequired = i.IsRequired,
                    TimeRequired = i.TimeRequired,
                    FileName = i.FileName,
                    FileExtension = i.FileExtension,
                    ItemId = i.ItemId,

                }).ToList(),
                Success = true,
            }).ToList();

            return unitsResponse;
        }

        public async Task<Response> CreateUnit(UnitRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsZeroOrNegative(request.CareerId, nameof(request.CareerId));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.Name, nameof(request.Name));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.Objective, nameof(request.Objective));
            ThrowIf.Argument.IsZeroOrNegative(request.ApprovalRate, nameof(request.ApprovalRate));



            Unit units = await _repository.GetSingleAsync<Unit>(x =>
                                                          x.CareerId == request.CareerId && x.Name == request.Name && x.IsActive == true);

            if (units != null)
            {
                return new Response { ValidationErrorMessage = Translate(Translations.thereIsAlreadyAUnitWithThatNameInThisCareer, request.RequestUserInfo.Language) };
            }

            units = new()
            {
                CareerId = request.CareerId,
                Name = request.Name,
                Objective = request.Objective,
                NotaAprobacion = request.ApprovalRate,
            };
            await _repository.AddAsync(units);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.createUnit);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);

            return new Response { Success = true };
        }

        public async Task<Response> EditUnit(UnitRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsZeroOrNegative(request.UnitId, nameof(request.UnitId));
            ThrowIf.Argument.IsZeroOrNegative(request.CareerId, nameof(request.CareerId));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.Name, nameof(request.Name));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.Objective, nameof(request.Objective));
            ThrowIf.Argument.IsZeroOrNegative(request.ApprovalRate, nameof(request.ApprovalRate));

            Unit units = await _repository.GetSingleAsync<Unit>(x =>
                                                          x.CareerId == request.CareerId && x.Id == request.UnitId && x.IsActive == true);

            if (units == null)
            {
                return new Response { ValidationErrorMessage = Translate(Translations.unitDoesNotExist, request.RequestUserInfo.Language) };
            }


            if (units.Name != request.Name)
            {
                Unit unitsSomeName = await _repository.GetSingleAsync<Unit>(x =>
                                                        x.CareerId == request.CareerId && x.Name == request.Name && x.IsActive == true);
                if (unitsSomeName != null)
                {

                    return new Response { ValidationErrorMessage = Translate(Translations.thereIsAlreadyAUnitWithThatNameInThisCareer, request.RequestUserInfo.Language) };
                }
            }

            units.Id = request.UnitId;
            units.CareerId = request.CareerId;
            units.Name = request.Name;
            units.Objective = request.Objective;
            units.NotaAprobacion = request.ApprovalRate;

            _repository.Update(units);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.editUnit);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);

            return new Response { Success = true };
        }

        public async Task<Response> DeleteUnit(UnitRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsZeroOrNegative(request.UnitId, nameof(request.UnitId));


            Unit units = await _repository.GetSingleAsync<Unit>(x => x.Id == request.UnitId && x.IsActive == true);

            if (units == null)
            {
                return new Response { ValidationErrorMessage = "La unidad no existe" };
            }

            units.IsActive = false;

            _repository.Update(units);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.deleteUnit);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);

            return new Response { Success = true };
        }

    }
}
