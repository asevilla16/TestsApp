﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.UnitAppServices
{
    public interface IUnitAppService
    {
        Task<List<UnitDTO>> GetUnitsFiltered(UnitRequest request);
        Task<Response> CreateUnit(UnitRequest request);
        Task<Response> DeleteUnit(UnitRequest request);
        Task<Response> EditUnit(UnitRequest request);
    }
}
