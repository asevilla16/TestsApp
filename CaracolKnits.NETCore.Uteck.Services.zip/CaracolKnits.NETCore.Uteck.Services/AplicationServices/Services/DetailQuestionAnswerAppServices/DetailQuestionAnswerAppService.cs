﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.DetailQuestionAnswerAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.DetailQuestionAnswerAppServices
{
    public class DetailQuestionAnswerAppService : BaseAppService, IDetailQuestionAnswerAppService
    {
        public DetailQuestionAnswerAppService(IGenericRepository<IGenericDataContext> repository) : base(repository)
        {
        }

        public async Task<Response> CreateDetailQuestionAndAnswers(List<DetailQuestionAnswerRequest> request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));

            List<DetailQuestionAnswer> detailQuestionAnswers = new List<DetailQuestionAnswer>();

            request.ForEach(item =>
            {
                DetailQuestionAnswer detailQuestionAnswer = new DetailQuestionAnswer
                {
                    ExamId = item.ExamId,
                    NameExam = item.NameExam,
                    Quetion = item.Quetion,
                    CorrectAnswer = item.CorrectAnswer,
                    SelectedAnswer = item.SelectedAnswer,
                    ExamAdvancementId = item.ExamAdvancementId,
                };

                detailQuestionAnswers.Add(detailQuestionAnswer);
            });
            
            await _repository.AddRangeAsync(detailQuestionAnswers);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request[0].RequestUserInfo, Transactions.createCareer);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);

            return new Response { Success = true };
        }

        public async Task<List<DetailQuestionAnswerDTO>> GetDetailQuestionAndAnswersByExam(int examId)
        {
            IEnumerable<DetailQuestionAnswer> detail = await _repository.GetFilteredAsync<DetailQuestionAnswer>(x => x.ExamId == examId
                                                                                        && x.IsActive == true);

            List<DetailQuestionAnswerDTO> detailResponse = detail.Select(x => new DetailQuestionAnswerDTO
            {
                ExamId = x.ExamId,
                NameExam = x.NameExam,
                Quetion = x.Quetion,
                CorrectAnswer = x.CorrectAnswer,
                SelectedAnswer = x.SelectedAnswer,
                ExamAdvancementId = x.ExamAdvancementId,
            }).ToList();

            return detailResponse;
        }
    }
}
