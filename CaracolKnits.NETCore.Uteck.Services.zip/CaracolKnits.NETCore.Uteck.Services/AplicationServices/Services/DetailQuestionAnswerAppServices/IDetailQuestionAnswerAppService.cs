﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.DetailQuestionAnswerAppServices
{
    public interface IDetailQuestionAnswerAppService
    {
        Task<List<DetailQuestionAnswerDTO>> GetDetailQuestionAndAnswersByExam(int examId);
        Task<Response> CreateDetailQuestionAndAnswers(List<DetailQuestionAnswerRequest> request);
    }
}
