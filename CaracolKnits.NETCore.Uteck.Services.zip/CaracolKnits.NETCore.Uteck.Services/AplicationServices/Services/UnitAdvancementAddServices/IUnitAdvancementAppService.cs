﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.UnitAdvancementAddServices
{
    public interface IUnitAdvancementAppService
    {
        Task<List<UnitAdvancementDTO>> GetUnitAdvancementFiltered(UnitAdvancementRequest request);
        Task<UnitAdvancementDTO> RegisterInitialDateUnit(UnitAdvancementRequest request);
        Task<UnitAdvancementDTO> RegisterFinalDateUnit(UnitAdvancementRequest request);
        Task<UnitAdvancementDTO> RegisterProgressUnit(UnitAdvancementRequest request);
        Task<UnitAdvancementDTO> RegisterApprovalNoteUnit(UnitAdvancementRequest request);
    }
}
