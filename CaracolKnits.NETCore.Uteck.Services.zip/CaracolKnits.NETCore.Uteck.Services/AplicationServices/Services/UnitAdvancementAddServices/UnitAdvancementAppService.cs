﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UnitAdvancementAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.UnitAdvancementAddServices
{
    public class UnitAdvancementAppService : BaseAppService, IUnitAdvancementAppService
    {
        public UnitAdvancementAppService(IGenericRepository<IGenericDataContext> repository) : base(repository)
        {
        }

        public string Translate(string key, string language)
        {
            string value = Translations.CreateTranslation().GetTranslation(language, key);

            return value;
        }

        public async Task<List<UnitAdvancementDTO>> GetUnitAdvancementFiltered(UnitAdvancementRequest request)
        {


            IEnumerable<UnitAdvancement> unitAdvancements = await _repository.GetFilteredAsync<UnitAdvancement>(x => x.CareerAdvancementId == request.CareerAdvancementId);

           
                List<UnitAdvancementDTO> unitAdvancementsResponse = unitAdvancements.Select(x=> new UnitAdvancementDTO()
                {
                    UnitAdvancementId = x.Id,
                    UnitId = x.UnitId,
                    CareerId = x.CareerId,
                    Unit = x.Unit,
                    Objective = x.Objective,
                    InitialDate = x.InitialDate,
                    FinalDate = x.FinalDate,
                    TimeSpent = x.TimeSpent,
                    Progress = x.Progress,
                    Period = x.Period,
                    IsOpen = x.IsOpen,
                    IsReplacement = x.IsReplacement,
                    NumReplacement = x.NumReplacement,
                    NotaAprobacion = x.NotaAprobacion,
                    CareerAdvancementId = x.CareerAdvancementId,

                }).ToList();


            return unitAdvancementsResponse;
        }

        public async Task<UnitAdvancementDTO> RegisterInitialDateUnit(UnitAdvancementRequest request)
        {
            UnitAdvancementDTO unitAdvancementResponse = new();

            UnitAdvancement unitAdvancement = await _repository.GetSingleAsync<UnitAdvancement>(x=> x.Id == request.UnitAdvancementId);

            if(unitAdvancement == null)
            {
                unitAdvancementResponse.ValidationErrorMessage = Translate(Translations.unitDoesNotExist, request.RequestUserInfo.Language);
                return unitAdvancementResponse;
            }

            unitAdvancement.InitialDate = DateTime.Now;

             _repository.Update(unitAdvancement);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.registerInitialDate);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);
            unitAdvancementResponse = MaterializeUnitAdvancement(unitAdvancement);



            return unitAdvancementResponse;
        }

        public async Task<UnitAdvancementDTO> RegisterFinalDateUnit(UnitAdvancementRequest request)
        {
            UnitAdvancementDTO unitAdvancementResponse = new();

            UnitAdvancement unitAdvancement = await _repository.GetSingleAsync<UnitAdvancement>(x => x.Id == request.UnitAdvancementId);

            if (unitAdvancement == null)
            {
                unitAdvancementResponse.ValidationErrorMessage = Translate(Translations.unitDoesNotExist, request.RequestUserInfo.Language);
                return unitAdvancementResponse;
            }

            unitAdvancement.FinalDate = DateTime.Now;

            _repository.Update(unitAdvancement);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.registerFinalDate);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);
            unitAdvancementResponse = MaterializeUnitAdvancement(unitAdvancement);

            return unitAdvancementResponse;
        }

        public async Task<UnitAdvancementDTO> RegisterProgressUnit(UnitAdvancementRequest request)
        {
            UnitAdvancementDTO unitAdvancementResponse = new();

            UnitAdvancement unitAdvancement = await _repository.GetSingleAsync<UnitAdvancement>(x => x.Id == request.UnitAdvancementId);

            if (unitAdvancement == null)
            {
                unitAdvancementResponse.ValidationErrorMessage = Translate(Translations.unitDoesNotExist, request.RequestUserInfo.Language);
                return unitAdvancementResponse;
            }

            unitAdvancement.Progress = request.Progress;

            _repository.Update(unitAdvancement);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.registerProgress);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);
            unitAdvancementResponse = MaterializeUnitAdvancement(unitAdvancement);
            return unitAdvancementResponse;
        }

        public async Task<UnitAdvancementDTO> RegisterApprovalNoteUnit(UnitAdvancementRequest request)
        {
            UnitAdvancementDTO unitAdvancementResponse = new();

            UnitAdvancement unitAdvancement = await _repository.GetSingleAsync<UnitAdvancement>(x => x.Id == request.UnitAdvancementId);

            if (unitAdvancement == null)
            {
                unitAdvancementResponse.ValidationErrorMessage = Translate(Translations.unitDoesNotExist, request.RequestUserInfo.Language);
                return unitAdvancementResponse;
            }

            unitAdvancement.NotaAprobacion = request.NotaAprobacion;

            _repository.Update(unitAdvancement);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.registerProgress);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);

            return unitAdvancementResponse;
        }

        private UnitAdvancementDTO MaterializeUnitAdvancement(UnitAdvancement unitAdvancement)
        {
            UnitAdvancementDTO unitAdvancementResponse = new();
            unitAdvancementResponse.UnitAdvancementId = unitAdvancement.Id;
            unitAdvancementResponse.UnitId = unitAdvancement.UnitId;
            unitAdvancementResponse.CareerId = unitAdvancement.CareerId;
            unitAdvancementResponse.Unit = unitAdvancement.Unit;
            unitAdvancementResponse.Objective = unitAdvancement.Objective;
            unitAdvancementResponse.InitialDate = unitAdvancement.InitialDate;
            unitAdvancementResponse.FinalDate = unitAdvancement.FinalDate;
            unitAdvancementResponse.TimeSpent = unitAdvancement.TimeSpent;
            unitAdvancementResponse.Progress = unitAdvancement.Progress;
            unitAdvancementResponse.Period = unitAdvancement.Period;
            unitAdvancementResponse.TotalScore = unitAdvancement.TotalScore;
            unitAdvancementResponse.IsOpen = unitAdvancement.IsOpen;
            unitAdvancementResponse.IsReplacement = unitAdvancement.IsReplacement;
            unitAdvancementResponse.NumReplacement = unitAdvancement.NumReplacement;
            unitAdvancementResponse.NotaAprobacion = unitAdvancement.NotaAprobacion;
            unitAdvancementResponse.CareerAdvancementId = unitAdvancement.CareerAdvancementId;

            return unitAdvancementResponse;
        }
    }
}
