﻿using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.DictonaryAppServices
{
    public interface IDictonaryAppService
    {
        string GetTranslation(string Language, string key);
    }
}
