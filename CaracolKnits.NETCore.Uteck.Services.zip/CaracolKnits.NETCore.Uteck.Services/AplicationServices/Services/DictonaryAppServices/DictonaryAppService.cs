﻿
using Microsoft.AspNetCore.Hosting;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.DictonaryAppServices
{
    public class DictonaryAppService : IDictonaryAppService
    {

        private readonly IConfiguration Configuration;
        public DictonaryAppService(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public string GetTranslation(string Language, string key)
        {
            ThrowIf.Argument.IsNullOrWhiteSpace(Language, nameof(Language));
            ThrowIf.Argument.IsNullOrWhiteSpace(key, nameof(key));
            string value = "";

            const string sql = "select LanguageId, [Key], Value " +
                               "from Commons.Dictonary " +
                               "where LanguageId = @Language And [Key] = @Key";


            var connectionString = Configuration.GetConnectionString("ConectionString_UAT");


            if (connectionString != null)
            {
                using (var ctsConexion = new SqlConnection(connectionString))
                {
                    var ctsCommand = ctsConexion.CreateCommand();
                    ctsCommand.CommandText = sql;
                    ctsCommand.Parameters.AddWithValue("@Language", Language);
                    ctsCommand.Parameters.AddWithValue("@Key", key);

                    ctsConexion.Open();

                    using (var reader = ctsCommand.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            value = reader["Value"].ToString();
                        }
                    }
                }
            }


            return value;
        }


    }
}
