﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.EnrollmentAppServices
{
    public interface IEnrollmentAppServices
    {
        Task<List<CareersAndUsersByPositionJobDTO>> GetUserAndCareerForPositioonJob(CareersAndUsersByPositionJobRequest request);
        Task<List<EnrollmentMasiveDTO>> EnrollmentMasivieOfCareer(EnrollMasiveRequest request);
    }
}
