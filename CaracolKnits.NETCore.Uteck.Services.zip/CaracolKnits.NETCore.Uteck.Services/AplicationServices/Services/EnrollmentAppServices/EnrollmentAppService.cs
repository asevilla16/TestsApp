﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.CareerAdvancementAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.CareerAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.CareerByPositionAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ExamAdvancementAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ExamnAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.PositionAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ResourceAdvancementAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ResourceAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UnitAdvancementAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UnitAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UserAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.EnrollmentAppServices
{
    public class EnrollmentAppService : BaseAppService, IEnrollmentAppServices
    {
        public EnrollmentAppService(IGenericRepository<IGenericDataContext> repository) : base(repository)
        {
        }

        public async Task<List<CareersAndUsersByPositionJobDTO>> GetUserAndCareerForPositioonJob(CareersAndUsersByPositionJobRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsNull(request.PositionsJobIds, nameof(request.PositionsJobIds));

            List<CareersAndUsersByPositionJobDTO> CareersAndUsersByPositionJob = new List<CareersAndUsersByPositionJobDTO>();

            IEnumerable<CareerByPosition> careersByPositions = await _repository.GetFilteredAsync<CareerByPosition>(x => request.PositionsJobIds.Contains(x.PositionId));

            List<int> careerIds = careersByPositions.Select(x => x.CareerId).ToList();

            List<int> PositionIds = careersByPositions.Select(x => x.PositionId).ToList();

            IEnumerable<Career> careers = await _repository.GetFilteredAsync<Career>(x => careerIds.Contains(x.Id));

            IEnumerable<Position> positions = await _repository.GetFilteredAsync<Position>(x => PositionIds.Contains(x.Id));

            IEnumerable<User> usersByPosition = await _repository.GetFilteredAsync<User>(x => PositionIds.Contains(x.PositionJobId));

            foreach (var position in request.PositionsJobIds)
            {

                CareersAndUsersByPositionJobDTO careersAndUsersByPositionJobDTO = new CareersAndUsersByPositionJobDTO()
                {
                    PositionId = position,
                    CareerForJobList = GetCareerForJob(careersByPositions, careers, position),
                    UserForJobList = GetUsersForPosition(usersByPosition, positions, position)
                };
                if (careersAndUsersByPositionJobDTO.CareerForJobList.Any() && careersAndUsersByPositionJobDTO.UserForJobList.Any())
                {
                    CareersAndUsersByPositionJob.Add(careersAndUsersByPositionJobDTO);
                }
            }

            return CareersAndUsersByPositionJob;
        }

        private List<CareerForPositionsJob> GetCareerForJob(IEnumerable<CareerByPosition> careersByPositions, IEnumerable<Career> careers, int positionId)
        {
            List<CareerForPositionsJob> careerForJob = new List<CareerForPositionsJob>();

            List<int> CareerIdsforPosition = careersByPositions.Where(x => x.PositionId == positionId).Select(x => x.CareerId).ToList();

            IEnumerable<Career> careersList = careers.Where(x => CareerIdsforPosition.Contains(x.Id)).ToList();

            foreach (var career in careersList)
            {
                careerForJob.Add(new CareerForPositionsJob()
                {
                    PositionJobId = positionId,
                    CareerId = career.Id,
                    Description = career.Description,
                    Name = career.Name,
                    IsSelected = true,
                    NoSemanas = career.NoSemanas,
                    NotaAprobacion = career.NotaAprobacion,

                });
            }
            return careerForJob;
        }

        private List<UserForPositionsJob> GetUsersForPosition(IEnumerable<User> usersByPosition, IEnumerable<Position> positions, int positionId)
        {
            List<UserForPositionsJob> userForPosition = new List<UserForPositionsJob>();

            Position postion = positions.FirstOrDefault(x => x.Id == positionId);

            if (postion != null)
            {

                foreach (var user in usersByPosition)
                {
                    if (user.PositionJobId == postion.Id)
                    {
                        userForPosition.Add(new UserForPositionsJob()
                        {
                            UserId = user.Id,
                            PositionJobId = positionId,
                            UserName = user.UserName,
                            Name = user.FullName,
                            PositionJob = string.Format("{0} {1}", postion.PositionJob, postion.Name),
                            IsSelected = true,
                        });
                    }
                }
            }

            return userForPosition;
        }

        public async Task<List<EnrollmentMasiveDTO>> EnrollmentMasivieOfCareer(EnrollMasiveRequest request)
        {
            Response response = new Response();

            List<EnrollmentMasiveDTO> enrollmentMasiveReponse = new List<EnrollmentMasiveDTO>();

            List<CareerAdvancement> usertoEnrollmentList = new List<CareerAdvancement>();


            foreach (var item in request.CareersAndUsersByPositionJob)
            {
                List<int> careerId = item.CareerForJobList.Select(x => x.CareerId).ToList();
                List<int> userId = item.UserForJobList.Select(x => x.UserId).ToList();
                IEnumerable<Unit> units = await _repository.GetFilteredAsync<Unit>(x => careerId.Contains(x.CareerId) && x.IsActive == true);
                List<int> unitIds = units.Select(x => x.Id).ToList();

                IEnumerable<Resource> resources = await _repository.GetFilteredAsync<Resource>(x => unitIds.Contains(x.UnitId) && x.IsActive == true);
                IEnumerable<Examn> exams = await _repository.GetFilteredAsync<Examn>(x => unitIds.Contains(x.UnitId) && x.IsActive == true);

                IEnumerable<CareerAdvancement> careerAdvancement =
                                                await _repository.GetFilteredAsync<CareerAdvancement>(
                                                    x => careerId.Contains(x.CareerId) && userId.Contains(x.UserId) && x.IsOpen == 1);

                foreach (var careerEnrollment in careerAdvancement)
                {
                    enrollmentMasiveReponse.Add(new EnrollmentMasiveDTO()
                    {
                        UserId = careerEnrollment.UserId,
                        CarrerId = careerEnrollment.CareerId,
                        CareerName = careerEnrollment.Career,
                        UserNAme = careerEnrollment.UserName,
                        FullName = careerEnrollment.UserFullName,
                    });
                }

                foreach (var career in item.CareerForJobList)
                {
                    foreach (var user in item.UserForJobList)
                    {
                        bool ItIsRegisteredCareerForTheUser = true;

                        var userExist = enrollmentMasiveReponse?.FirstOrDefault(x => x.UserId == user.UserId && x.CarrerId == career.CareerId);


                        ItIsRegisteredCareerForTheUser = user.UserId == userExist?.UserId;

                        if (!ItIsRegisteredCareerForTheUser)
                        {
                            IEnumerable<Unit> unitsForCareer = units.Where(x => x.CareerId == career.CareerId);

                            if (unitsForCareer.Any())
                            {

                                List<UnitAdvancement> unitAdvancementList = new List<UnitAdvancement>();
                               

                                foreach (var unit in unitsForCareer)
                                {
                                    List<ExamAdvancement> examAdvancement = new();
                                    List<ResourceAdvancement> resourceAdvancementList = new List<ResourceAdvancement>();
                                    IEnumerable<Resource> resourceToEnrollments = resources.Where(x => x.UnitId == unit.Id);
                                    Examn examToEnrollments = exams.FirstOrDefault(x => x.UnitId == unit.Id);



                                    if (resourceToEnrollments.Any())
                                    {
                                        foreach (var resource in resourceToEnrollments)
                                        {
                                            resourceAdvancementList.Add(new ResourceAdvancement
                                            {
                                                ResourceId = resource.Id,
                                                UnitId = unit.Id,
                                                Resource = resource.Name,
                                                ResourceUrl = resource.ResourceUrl,
                                                UserName = user.UserName,
                                                UserFullName = user.Name,
                                                IsRequired = resource.IsRequired,
                                                TimeSpent = 0,
                                                ItemId = resource.ItemId,
                                                FileExtension = resource.FileExtension,
                                                ResourceType = resource.ResourceType,
                                                FileName = resource.FileName,
                                                TimeResource = resource.TimeRequired,
                                                Period = string.Format("{0}-{1}", DateTime.Now.Year, DateTime.Now.Month),
                                                IsOpen = 1,
                                                UserId = user.UserId,
                                            });
                                        }
                                    }

                                    if (examToEnrollments != null)
                                    {


                                        examAdvancement.Add(new ExamAdvancement
                                        {
                                            ExamId = examToEnrollments.Id,
                                            NameExam = examToEnrollments.Name,
                                            ExamTime = examToEnrollments.ExamTime,
                                            NumberQuestions = examToEnrollments.NumberQuestions,
                                            UserName = user.UserName,
                                            UserFullName = user.Name,
                                            UserId = user.UserId,
                                            TimeSpent = 0,
                                            Period = string.Format("{0}-{1}", DateTime.Now.Year, DateTime.Now.Month),
                                            IsOpen = 0,
                                            TotalScore = 0,
                                        });

                                    }
                                    if (examToEnrollments != null && resourceAdvancementList.Any())
                                    {

                                        unitAdvancementList.Add(new UnitAdvancement()
                                        {
                                            UnitId = unit.Id,
                                            CareerId = career.CareerId,
                                            Unit = unit.Name,
                                            UserId = user.UserId,
                                            Objective = unit.Objective,
                                            Progress = 0,
                                            TimeSpent = 0,
                                            Period = string.Format("{0}-{1}", DateTime.Now.Year, DateTime.Now.Month),
                                            TotalScore = 0,
                                            IsOpen = 1,
                                            IsReplacement = 0,
                                            NumReplacement = 0,
                                            NotaAprobacion = unit.NotaAprobacion,
                                            ResourceAdvancement = resourceAdvancementList,
                                            ExamAdvancement = examAdvancement

                                        });
                                    }


                                }
                                if (unitAdvancementList.Any())
                                {

                                    usertoEnrollmentList.Add(new CareerAdvancement()
                                    {
                                        CareerId = career.CareerId,
                                        Career = career.Name,
                                        Description = career.Description,
                                        UserName = user.UserName,
                                        UserFullName = user.Name,
                                        InitialDate = DateTime.Now,
                                        Progress = 0,
                                        Period = string.Format("{0}-{1}", DateTime.Now.Year, DateTime.Now.Month),
                                        IsOpen = 1,
                                        TotalScore = 0,
                                        TimeSpent = 0,
                                        NotaAprobacion = career.NotaAprobacion,
                                        NoSemanas = career.NoSemanas,
                                        UserId = user.UserId,
                                        UnitAdvancement = unitAdvancementList,
                                    });
                                }



                            }


                        }
                    }
                }


            }
            if (usertoEnrollmentList.Any())
            {

                await _repository.AddRangeAsync(usertoEnrollmentList);
                TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.createCareer);
                await _repository.UnitOfWork.CommitAsync(transactionInfo);
            }



            return enrollmentMasiveReponse;
        }
    }
}
