﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.ConfigurationAppServices
{
    public interface IConfigurationAppService
    {
        Task<ConfigurationDTO> GetConfiguration(string Attribute, string Facility, string Language);
        Task<List<ConfigurationDTO>> GetAllConfigurations();
        Task<ConfigurationDTO> CreateConfiguration(ConfigurationRequest request);
    }
}
