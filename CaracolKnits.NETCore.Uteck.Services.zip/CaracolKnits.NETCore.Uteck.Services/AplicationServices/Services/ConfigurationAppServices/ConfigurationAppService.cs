﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ConfigurationAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.ConfigurationAppServices
{
    public class ConfigurationAppService : BaseAppService, IConfigurationAppService
    {
        public ConfigurationAppService(IGenericRepository<IGenericDataContext> repository) : base(repository)
        {

        }


        public string Translate(string key, string language)
        {
            string value = Translations.CreateTranslation().GetTranslation(language, key);

            return value;
        }

        public async Task<List<ConfigurationDTO>> GetAllConfigurations()
        {
            IEnumerable<Configuration> configurations = await _repository.GetAllAsync<Configuration>();

            List<ConfigurationDTO> configurationResponse = configurations.Select(x => new ConfigurationDTO
            {
                ConfirutarionId = x.Id,
                Facility = x.Facility,
                Description = x.Description,
                Attribute = x.Attribute,
                Value = x.Value,
                Success = true,

            }).ToList();

            return configurationResponse;
        }

        public async Task<ConfigurationDTO> GetConfiguration(string Attribute, string Facility, string Language)
        {
            Configuration configuration = await _repository.GetSingleAsync<Configuration>(i => i.Attribute == Attribute && i.Facility == Facility);

            if (configuration == null)
            {
                return new ConfigurationDTO
                {
                    ValidationErrorMessage = Translate(Translations.theConfigurationDoesNotExist, Language)
            };
            }

            return new ConfigurationDTO
            {
                ConfirutarionId = configuration.Id,
                Facility = configuration.Facility,
                Description = configuration.Description,
                Attribute = configuration.Attribute,
                Value = configuration.Value,
                Success = true,
            };
        }

        public async Task<ConfigurationDTO> CreateConfiguration(ConfigurationRequest request)
        {
            Configuration configuration = await _repository.GetSingleAsync<Configuration>(i => i.Attribute == request.Attribute && i.Facility == request.Facility);

            if (configuration != null)
            {
                return new ConfigurationDTO
                {
                    ValidationErrorMessage = "Ya existe una configuración con ese atributo en esta planta"
                };
            }

            configuration = new Configuration
            {
                Facility = request.Facility,
                Description = request.Description,
                Attribute = request.Attribute,
                Value = request.Value,
            };


            await _repository.AddAsync(configuration);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.createConfiguration);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);

            return new ConfigurationDTO
            {
                ConfirutarionId = configuration.Id,
                Facility = configuration.Facility,
                Description = configuration.Description,
                Attribute = configuration.Attribute,
                Value = configuration.Value,
                Success=true,
            };
        }

    }
}
