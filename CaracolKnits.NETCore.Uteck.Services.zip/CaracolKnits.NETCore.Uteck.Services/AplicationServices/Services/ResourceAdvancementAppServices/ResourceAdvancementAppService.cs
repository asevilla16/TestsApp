﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ResourceAdvancementAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.ResourceAdvancementAppServices
{
    public class ResourceAdvancementAppService : BaseAppService, IResourceAdvancementAppService
    {
        public ResourceAdvancementAppService(IGenericRepository<IGenericDataContext> repository) : base(repository)
        {
        }
        public string Translate(string key, string language)
        {
            string value = Translations.CreateTranslation().GetTranslation(language, key);

            return value;
        }

        public async Task<ResourceAdvancementDTO> RegisterInitialDateResource(ResourceAdvancementRequest request)
        {
            ResourceAdvancementDTO resourceAdvancementResponse = new();

            ResourceAdvancement resourceAdvancement = await _repository.GetSingleAsync<ResourceAdvancement>(x => x.Id == request.ResourceAdvancementId);

            if (resourceAdvancement == null)
            {
                resourceAdvancementResponse.ValidationErrorMessage = Translate(Translations.unitDoesNotExist, request.RequestUserInfo.Language);
                return resourceAdvancementResponse;
            }

            resourceAdvancement.InitialDate = DateTime.Now;

            _repository.Update(resourceAdvancement);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.registerInitialDate);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);
            resourceAdvancementResponse.ResourceAdvancementId = resourceAdvancement.Id;
            resourceAdvancementResponse.ResourceId = resourceAdvancement.ResourceId;
            resourceAdvancementResponse.Resource = resourceAdvancement.Resource;
            resourceAdvancementResponse.UnitId = resourceAdvancement.UnitId;
            resourceAdvancementResponse.ResourceUrl = resourceAdvancement.ResourceUrl;
            resourceAdvancementResponse.UserName = resourceAdvancement.UserName;
            resourceAdvancementResponse.UserFullName = resourceAdvancement.UserFullName;
            resourceAdvancementResponse.InitialDate = resourceAdvancement.InitialDate;
            resourceAdvancementResponse.FinalDate = resourceAdvancement.FinalDate;
            resourceAdvancementResponse.TimeResource = resourceAdvancement.TimeResource;
            resourceAdvancementResponse.TimeSpent = resourceAdvancement.TimeSpent;
            resourceAdvancementResponse.IsRequired = resourceAdvancement.IsRequired;
            resourceAdvancementResponse.Progress = resourceAdvancement.Progress;
            resourceAdvancementResponse.Period = resourceAdvancement.Period;
            resourceAdvancementResponse.IsOpen = resourceAdvancement.IsOpen;
            resourceAdvancementResponse.FileName = resourceAdvancement.FileName;
            resourceAdvancementResponse.FileExtension = resourceAdvancement.FileExtension;
            resourceAdvancementResponse.ItemId = resourceAdvancement.ItemId;
            resourceAdvancementResponse.ResourceType = resourceAdvancement.ResourceType;
            resourceAdvancementResponse.IsReplacement = resourceAdvancement.IsReplacement;
            resourceAdvancementResponse.NumReplacement = resourceAdvancement.NumReplacement;
            resourceAdvancementResponse.UserId = resourceAdvancement.UserId;
            resourceAdvancementResponse.UnitAdvancementId = resourceAdvancement.UnitAdvancementId;
            return resourceAdvancementResponse;
        }

        public async Task<ResourceAdvancementDTO> RegisterFinalDateResource(ResourceAdvancementRequest request)
        {
            ResourceAdvancementDTO resourceAdvancementResponse = new();

            ResourceAdvancement resourceAdvancement = await _repository.GetSingleAsync<ResourceAdvancement>(x => x.Id == request.ResourceAdvancementId);

            if (resourceAdvancement == null)
            {
                resourceAdvancementResponse.ValidationErrorMessage = Translate(Translations.unitDoesNotExist, request.RequestUserInfo.Language);
                return resourceAdvancementResponse;
            }

            resourceAdvancement.FinalDate = DateTime.Now;

            _repository.Update(resourceAdvancement);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.registerFinalDate);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);

            return resourceAdvancementResponse;
        }

        public async Task<ResourceAdvancementDTO> RegisterProgressResource(ResourceAdvancementRequest request)
        {
            ResourceAdvancementDTO resourceAdvancementResponse = new();

            ResourceAdvancement resourceAdvancement = await _repository.GetSingleAsync<ResourceAdvancement>(x => x.Id == request.ResourceAdvancementId);

            if (resourceAdvancement == null)
            {
                resourceAdvancementResponse.ValidationErrorMessage = Translate(Translations.unitDoesNotExist, request.RequestUserInfo.Language);
                return resourceAdvancementResponse;
            }

            resourceAdvancement.Progress = request.Progress;

            _repository.Update(resourceAdvancement);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.registerProgress);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);

            return resourceAdvancementResponse;
        }

    }
}
