﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.ResourceAdvancementAppServices
{
    public interface IResourceAdvancementAppService
    {
        Task<ResourceAdvancementDTO> RegisterInitialDateResource(ResourceAdvancementRequest request);
        Task<ResourceAdvancementDTO> RegisterFinalDateResource(ResourceAdvancementRequest request);
        Task<ResourceAdvancementDTO> RegisterProgressResource(ResourceAdvancementRequest request);
    }
}
