﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.RolAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.RolAppServices
{
    public class RolAppService : BaseAppService, IRolAppService
    {
        public RolAppService(IGenericRepository<IGenericDataContext> repository) : base(repository)
        {

        }


        public string Translate(string key, string language)
        {
            string value = Translations.CreateTranslation().GetTranslation(language, key);

            return value;
        }

        public async Task<List<RolDTO>> GetAllRoles()
        {
            List<string> includes = new List<string> { "User" };
            IEnumerable<Rol> roles = await _repository.GetAllIncludeAsync<Rol>(includes);

            List<RolDTO> rolesResponse = roles.Select(r => new RolDTO
            {
                RolId = r.Id,
                RolName = r.RolName,
                Users = r.User.Select(i => new UserDTO
                {
                    UserId = i.Id,
                    FullName = i.FullName,
                    Facility_Id = i.Facility_Id,
                    UserName = i.UserName,
                    EmailAddress = i.EmailAddress,
                    LanguageId = i.LanguageId,
                    RolId = i.RolId,
                    AreaId = i.AreaId,
                    Success = true,

                }).ToList(),
            }).ToList();

            return rolesResponse;
        }

        public async Task<Response> CreateRol(RolRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsNull(request.RolName, nameof(request.RolName));
            Rol rol = _repository.GetSingle<Rol>(x => x.RolName == request.RolName);
            if (rol != null)
            {
                return new Response { ValidationErrorMessage =   Translate(Translations.roleAlreadyExists, request.RequestUserInfo.Language) };
            }

            rol = new()
            {
                RolName = request.RolName,
            };
            await _repository.AddAsync(rol);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.createRole);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);
            return new Response { Success = true };
        }
    }
}
