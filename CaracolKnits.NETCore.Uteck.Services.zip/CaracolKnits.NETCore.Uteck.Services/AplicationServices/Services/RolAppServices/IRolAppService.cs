﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.RolAppServices
{
    public interface IRolAppService
    {
        Task<List<RolDTO>> GetAllRoles();
        Task<Response> CreateRol(RolRequest request);
    }
}
