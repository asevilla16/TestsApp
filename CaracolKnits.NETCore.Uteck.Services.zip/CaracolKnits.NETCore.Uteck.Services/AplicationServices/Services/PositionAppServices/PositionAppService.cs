﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.PositionAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.PositionAppServices
{
    public class PositionAppService : BaseAppService, IPositionAppService
    {
        public PositionAppService(IGenericRepository<IGenericDataContext> repository) : base(repository)
        {
        }
        public string Translate(string key, string language)
        {
            string value = Translations.CreateTranslation().GetTranslation(language, key);

            return value;
        }
        public async Task<Response> CreatePosition(PositionRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.Name, nameof(request.Name));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.PositionJob, nameof(request.PositionJob));
            ThrowIf.Argument.IsZeroOrNegative(request.FacilityId, nameof(request.FacilityId));

            Position position = await _repository.GetSingleAsync<Position>(x => x.PositionJob == request.PositionJob && x.IsActive == true);
            if (position != null)
            {
                return new Response
                {
                    ValidationErrorMessage =
                    Translate(Translations.aResourceWithThatNameAlreadyExistsOnThisUnit, request.RequestUserInfo.Language)
                };
            }

            position = new Position()
            {
                Name = request.Name,
                PositionJob = request.PositionJob,
                FacilityId = request.FacilityId,
            };

            await _repository.AddAsync(position);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.createResource);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);

            return new Response { Success = true };
        }
    }
}
