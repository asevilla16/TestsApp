﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.ExamMasterAppServices
{
    public interface IExamMasterAppService : IDisposable
    {
        Task<List<ExamDTO>> GetAllExams();
        Task<ExamDTO> GetExamByUnitId(int id);
        Task<Response> CreateExam(ExamRequest request);
        Task<ExamAdvancementDTO> OpenExamAdvancement(ExamAdvancementRequest request);
        Task<ExamAdvancementDTO> CloseExamAdvancement(ExamAdvancementRequest request);
    }
}
