﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.QuestionAppService;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.AnswerAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ExamAdvancementAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ExamnAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.QuestionAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UnitAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.ExamMasterAppServices
{
    public class ExamMasterAppService : BaseAppService, IExamMasterAppService
    {
        private readonly IQuestionAppService _questionAppService;

        public ExamMasterAppService(IGenericRepository<IGenericDataContext> repository, IQuestionAppService questionAppService) : base(repository)
        {
            _questionAppService = questionAppService;
        }

        public async Task<List<ExamDTO>> GetAllExams()
        {
            List<string> includes = new List<string> { "Unit" };
            IEnumerable<Examn> exams = await _repository.GetAllIncludeAsync<Examn>(includes);

            List<ExamDTO> result = exams.Select(x => new ExamDTO
            {
                id = x.Id,
                Name = x.Name,
                ExamTime = x.ExamTime,
                NumberQuestions = x.NumberQuestions,
                UnitId = x.UnitId,
                Unit = BuildUnit(x.Unit)
            }).ToList();

            return result;
        }

        public async Task<ExamDTO> GetExamByUnitId(int id)
        {
            ThrowIf.Argument.IsZeroOrNegative(id, nameof(id));

            Examn exam = await _repository.GetSingleAsync<Examn>(x => x.UnitId == id);

            if (exam == null)
            {
                return new ExamDTO { ValidationErrorMessage = "No se ha creado un examen para esta unidad." };
            }

            List<QuestionDTO> questions = await _questionAppService.GetAllQuestions(exam.Id);

            return new ExamDTO
            {
                id = exam.Id,
                ExamTime = exam.ExamTime,
                UnitId = exam.UnitId,
                NumberQuestions = exam.NumberQuestions,
                Name = exam.Name,
                Questions = questions
            };

        }

        public async Task<Response> CreateExam(ExamRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.Name, nameof(request.Name));
            ThrowIf.Argument.IsZeroOrNegative(request.NumberQuestions, nameof(request.NumberQuestions));
            ThrowIf.Argument.IsZeroOrNegative(request.ExamTime, nameof(request.ExamTime));
            ThrowIf.Argument.IsZeroOrNegative(request.UnitId, nameof(request.UnitId));

            Examn existingExam = _repository.GetSingle<Examn>(x => x.UnitId == request.UnitId);

            if (existingExam != null)
            {
                return new Response { ValidationErrorMessage = "Ya existe un examen para esta unidad" };
            }

            Examn exam = new Examn
            {
                Name = request.Name,
                NumberQuestions = request.NumberQuestions,
                ExamTime = request.ExamTime,
                UnitId = request.UnitId,
                Questions = request.Questions.Select(x => new Question
                {
                    Description = x.Description,
                    ImageURL = x.ImageURL,
                    QuestionTypeId = x.QuestionTypeId,
                    Answers = x.Answers.Select(e => new Answer
                    {
                        Description = e.Description,
                        IsCorrectAnswer = e.IsCorrectAnswer,
                    }).ToList(),

                }).ToList(),
            };

            await _repository.AddAsync(exam);

            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.createRole);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);
            return new Response { Success = true };
        }

        private UnitDTO BuildUnit(Unit unit)
        {
            UnitDTO unitDTO = new UnitDTO
            {
                UnitId = unit.Id,
                Name = unit.Name,
                Objective = unit.Objective,
                ApprovalRate = unit.NotaAprobacion,
                CareerId = unit.CareerId,
            };

            return unitDTO;
        }

        private ExamAdvancementDTO MaterializeEcamAdvancement(ExamAdvancement exam)
        {
            ExamAdvancementDTO examResponse = new ExamAdvancementDTO
            {
                ExamAdvancementId = exam.Id,
                ExamId = exam.ExamId,
                NameExam = exam.NameExam,
                NumberQuestions = exam.NumberQuestions,
                UserName = exam.UserName,
                UserFullName = exam.UserFullName,
                InitialDate = exam.InitialDate,
                FinalDate = exam.FinalDate,
                TimeSpent = exam.TimeSpent,
                Period = exam.Period,
                IsOpen = exam.IsOpen,
                TotalScore = exam.TotalScore,
                UnitAdvancementId = exam.UnitAdvancementId,
                UserId = exam.UserId,
            };

            return examResponse;
        }

        public async Task<ExamAdvancementDTO> OpenExamAdvancement(ExamAdvancementRequest request)
        {
            ThrowIf.Argument.IsZeroOrNegative(request.ExamAdvancementId, nameof(request.ExamAdvancementId));
            ExamAdvancementDTO examAdvancementResponse = new();
            ExamAdvancement examAdvancement = await _repository.GetSingleAsync<ExamAdvancement>(x => x.Id == request.ExamAdvancementId);
            if (examAdvancement == null)
            {
                examAdvancementResponse.ValidationErrorMessage = "No existe un examen en esta unidad";
                return examAdvancementResponse;
            }
            examAdvancement.IsOpen = 1;

            _repository.Update(examAdvancement);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.openExam);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);

            examAdvancementResponse = MaterializeEcamAdvancement(examAdvancement);

            return examAdvancementResponse;
        }

        public async Task<ExamAdvancementDTO> CloseExamAdvancement(ExamAdvancementRequest request)
        {
            ThrowIf.Argument.IsZeroOrNegative(request.ExamAdvancementId, nameof(request.ExamAdvancementId));
            ExamAdvancementDTO examAdvancementResponse = new();
            ExamAdvancement examAdvancement = await _repository.GetSingleAsync<ExamAdvancement>(x => x.Id == request.ExamAdvancementId);
            if (examAdvancement == null)
            {
                examAdvancementResponse.ValidationErrorMessage = "No existe un examen en esta unidad";
                return examAdvancementResponse;
            }
            examAdvancement.IsOpen = 0;

            _repository.Update(examAdvancement);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.closeExam);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);
            examAdvancementResponse = MaterializeEcamAdvancement(examAdvancement);

            return examAdvancementResponse;
        }

    }
}
