﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.CareerAdvancementAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.ResourceAdvancementAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.UnitAdvancementAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.CareerAdvancementAppServices
{
    public class CareerAdvancementAppService : BaseAppService, ICareerAdvancementAppService
    {
        public CareerAdvancementAppService(IGenericRepository<IGenericDataContext> repository) : base(repository)
        {
        }

        public string Translate(string key, string language)
        {
            string value = Translations.CreateTranslation().GetTranslation(language, key);

            return value;
        }

        public async Task<List<CareerAdvancementDTO>> GetCareerAdvancementByUser(CareerAdvancementRequest request)
        {
            List<string> includes = new List<string> { "ExamAdvancement", "ResourceAdvancement" };

            IEnumerable<CareerAdvancement> careerAdvancement = await _repository.GetFilteredAsync<CareerAdvancement>(x => x.UserId == request.UserId && x.IsActive == true);
            List<int> careerAdvancementIds = careerAdvancement.Select(x => x.Id).ToList();
            IEnumerable<UnitAdvancement> unitAdvancement = await _repository.GetAllIncludeAsync<UnitAdvancement>(x => careerAdvancementIds.Contains(x.CareerAdvancementId) && x.IsActive == true, includes);

            List<CareerAdvancementDTO> careerAdvancementResponse = careerAdvancement.Select(x => new CareerAdvancementDTO
            {
                CareerAdvancementId = x.Id,
                CareerId = x.CareerId,
                Description = x.Description,
                Career = x.Career,
                UserName = x.UserName,
                UserFullName = x.UserFullName,
                UserId = x.UserId,
                InitialDate = x.InitialDate,
                FinalDate = x.FinalDate,
                TimeSpent = x.TimeSpent,
                Progress = x.Progress,
                Period = x.Period,
                IsOpen = x.IsOpen,
                TotalScore = x.TotalScore,
                NotaAprobacion = x.NotaAprobacion,
                NoSemanas = x.NoSemanas,
                UnitAdvancements = MaterializeUnitAdvancement(x.Id, unitAdvancement),

            }).ToList();

            return careerAdvancementResponse;
        }

        public List<UnitAdvancementDTO> MaterializeUnitAdvancement(int carrerAdvancmentId, IEnumerable<UnitAdvancement> unitAdvancement)
        {
            List<UnitAdvancementDTO> unitAdvancementResponse = new List<UnitAdvancementDTO>();
            foreach (var unit in unitAdvancement)
            {
                if (carrerAdvancmentId == unit.CareerAdvancementId)
                {

                    unitAdvancementResponse.Add(new UnitAdvancementDTO
                    {
                        UnitAdvancementId = unit.Id,
                        UnitId = unit.UnitId,
                        CareerId = unit.CareerId,
                        Unit = unit.Unit,
                        Objective = unit.Objective,
                        InitialDate = unit.InitialDate,
                        FinalDate = unit.FinalDate,
                        TimeSpent = unit.TimeSpent,
                        Progress = unit.Progress,
                        Period = unit.Period,
                        TotalScore = unit.TotalScore,
                        IsOpen = unit.IsOpen,
                        IsReplacement = unit.IsReplacement,
                        NumReplacement = unit.NumReplacement,
                        NotaAprobacion = unit.NotaAprobacion,
                        CareerAdvancementId = unit.CareerAdvancementId,
                        ResourceAdvancements = unit.ResourceAdvancement.Select(x => new ResourceAdvancementDTO
                        {
                            ResourceAdvancementId = x.Id,
                            ResourceId = x.ResourceId,
                            Resource = x.Resource,
                            UnitId = x.UnitId,
                            ResourceUrl = x.ResourceUrl,
                            UserName = x.UserName,
                            UserFullName = x.UserFullName,
                            IsRequired = x.IsRequired,
                            InitialDate = x.InitialDate,
                            FinalDate = x.FinalDate,
                            TimeResource = x.TimeResource,
                            ResourceType = x.ResourceType,
                            FileExtension = x.FileExtension,
                            FileName = x.FileName,
                            ItemId = x.ItemId,
                            TimeSpent = x.TimeSpent,
                            Progress = x.Progress,
                            Period = x.Period,
                            IsOpen = x.IsOpen,
                            IsReplacement = x.IsReplacement,
                            NumReplacement = x.NumReplacement,
                            UserId = x.UserId,
                            UnitAdvancementId = x.UnitAdvancementId,
                        }).ToList(),

                        ExamAdvancement = unit.ExamAdvancement.Select(i => new ExamAdvancementDTO
                        {
                            ExamAdvancementId = i.Id,
                            ExamId = i.ExamId,
                            NameExam = i.NameExam,
                            ExamTime = i.ExamTime,
                            NumberQuestions = i.NumberQuestions,
                            UserName = i.UserName,
                            UserFullName = i.UserFullName,
                            InitialDate = i.InitialDate,
                            FinalDate = i.FinalDate,
                            TimeSpent = i.TimeSpent,
                            Period = i.Period,
                            IsOpen = i.IsOpen,
                            TotalScore = i.TotalScore,
                            UnitAdvancementId = i.UnitAdvancementId,
                            UserId = i.UserId,
                        }).ToList(),
                    });
                }
            }

            return unitAdvancementResponse;
        }

        public async Task<CareerAdvancementDTO> RegisterProgressCareer(CareerAdvancementRequest request)
        {
            CareerAdvancementDTO careerAdvancementResponse = new();

            CareerAdvancement careerAdvancement = await _repository.GetSingleAsync<CareerAdvancement>(x => x.Id == request.CareerAdvancementId);

            if (careerAdvancement == null)
            {
                careerAdvancementResponse.ValidationErrorMessage = Translate(Translations.careerDoesNotExist, request.RequestUserInfo.Language);
                return careerAdvancementResponse;
            }

            careerAdvancement.Progress = request.Progress;

            _repository.Update(careerAdvancement);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.registerProgress);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);
            careerAdvancementResponse = MaterializeCareerAdvancement(careerAdvancement);
            return careerAdvancementResponse;
        }

        private static CareerAdvancementDTO MaterializeCareerAdvancement(CareerAdvancement careerAdvancement)
        {
            CareerAdvancementDTO careerAdvancementDTO = new();
            careerAdvancementDTO.CareerAdvancementId = careerAdvancement.Id;
            careerAdvancementDTO.CareerId = careerAdvancement.CareerId;
            careerAdvancementDTO.Description = careerAdvancement.Description;
            careerAdvancementDTO.Career = careerAdvancement.Career;
            careerAdvancementDTO.UserName = careerAdvancement.UserName;
            careerAdvancementDTO.UserFullName = careerAdvancement.UserFullName;
            careerAdvancementDTO.UserId = careerAdvancement.UserId;
            careerAdvancementDTO.InitialDate = careerAdvancement.InitialDate;
            careerAdvancementDTO.FinalDate = careerAdvancement.FinalDate;
            careerAdvancementDTO.TimeSpent = careerAdvancement.TimeSpent;
            careerAdvancementDTO.Progress = careerAdvancement.Progress;
            careerAdvancementDTO.Period = careerAdvancement.Period;
            careerAdvancementDTO.IsOpen = careerAdvancement.IsOpen;
            careerAdvancementDTO.TotalScore = careerAdvancement.TotalScore;
            careerAdvancementDTO.NotaAprobacion = careerAdvancement.NotaAprobacion;
            careerAdvancementDTO.NoSemanas = careerAdvancement.NoSemanas;

            return careerAdvancementDTO;

        }
    }
}
