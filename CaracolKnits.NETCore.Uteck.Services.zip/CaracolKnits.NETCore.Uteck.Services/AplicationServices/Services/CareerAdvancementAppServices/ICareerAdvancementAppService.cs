﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.CareerAdvancementAppServices
{
    public interface ICareerAdvancementAppService
    {
        Task<List<CareerAdvancementDTO>> GetCareerAdvancementByUser(CareerAdvancementRequest request);
        Task<CareerAdvancementDTO> RegisterProgressCareer(CareerAdvancementRequest request);
    }
}
