﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.SecurityAppServices
{
    public interface ISecurityAppService
    {
        Task<List<PermissionDTO>> GetAllPermission();
        Task<PermissionDTO> CreatePermission(PermissionRequest request);
        Task<PermissionByRolDTO> AssignPermissionToRol(PermissionByRolRequest request);
    }
}
