﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.PermissionAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.PermissionByRolAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.RolAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.SecurityAppServices
{
    public class SecurityAppService : BaseAppService, ISecurityAppService
    {
        public SecurityAppService(IGenericRepository<IGenericDataContext> repository) : base(repository)
        {

        }

        public string Translate(string key, string language)
        {
            string value = Translations.CreateTranslation().GetTranslation(language, key);

            return value;
        }
        public async Task<List<PermissionDTO>> GetAllPermission()
        {
            IEnumerable<Permission> permissions = await _repository.GetAllAsync<Permission>();

            List<PermissionDTO> PermissionsResponse = permissions.Select(x => new PermissionDTO
            {
                PermissionId = x.Id,
                Name = x.Name,
                Description = x.Description,
                Success = true,
            }).ToList();

            return PermissionsResponse;
        }

        public async Task<PermissionDTO> CreatePermission(PermissionRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.Name, nameof(request.Name));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.Description, nameof(request.Description));

            Permission permission = await _repository.GetSingleAsync<Permission>(x => x.Name == request.Name);
            PermissionDTO PermissionsResponse = new();

            if (permission != null)
            {
                PermissionsResponse.ValidationErrorMessage =
                    Translate(Translations.aPermissionWithThatNameAlreadyExists, request.RequestUserInfo.Language);
                return PermissionsResponse;
            }

            permission = new Permission()
            {
                Name = request.Name,
                Description = request.Description,
            };

            await _repository.AddAsync(permission);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.createPermission);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);


            PermissionsResponse.PermissionId = permission.Id;
            PermissionsResponse.Name = permission.Name;
            PermissionsResponse.Description = permission.Description;
            PermissionsResponse.Success = true;

            return PermissionsResponse;
        }

        public async Task<PermissionByRolDTO> AssignPermissionToRol(PermissionByRolRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsZeroOrNegative(request.RolId, nameof(request.RolId));
            ThrowIf.Argument.IsZeroOrNegative(request.PermissionId, nameof(request.PermissionId));

            Permission permission = await _repository.GetSingleAsync<Permission>(x => x.Id == request.PermissionId);

            if (permission == null)
            {
                return new PermissionByRolDTO
                {
                    ValidationErrorMessage =
                    Translate(Translations.permissionDoesNotExist, request.RequestUserInfo.Language)
                };
            }

            Rol rol = await _repository.GetSingleAsync<Rol>(x => x.Id == request.RolId);

            if (rol == null)
            {
                return new PermissionByRolDTO
                {
                    ValidationErrorMessage =
                    Translate(Translations.roleDoesNotexist, request.RequestUserInfo.Language)
                };
            }

            PermissionByRol permissionByRol = await _repository.GetSingleAsync<PermissionByRol>(x =>
                                                                x.RolId == request.RolId && x.PermissionId == request.PermissionId);

            PermissionByRolDTO PermissionsByRolResponse = new();

            if (permissionByRol != null)
            {
                PermissionsByRolResponse.ValidationErrorMessage =
                    Translate(Translations.thePermissionIsAlreadyAssignedToTheRole, request.RequestUserInfo.Language);
                return PermissionsByRolResponse;
            }

            permissionByRol = new PermissionByRol()
            {
                RolId = request.RolId,
                PermissionId = request.PermissionId,
            };

            await _repository.AddAsync(permissionByRol);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.provideAccess);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);

            PermissionsByRolResponse.PermissionByRolId = permissionByRol.Id;
            PermissionsByRolResponse.RolId = request.RolId;
            PermissionsByRolResponse.PermissionId = request.PermissionId;
            PermissionsByRolResponse.Success = true;
            return PermissionsByRolResponse;
        }


    }
}
