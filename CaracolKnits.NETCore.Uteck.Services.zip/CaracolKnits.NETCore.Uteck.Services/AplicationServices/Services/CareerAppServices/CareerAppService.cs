﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.CareerAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Aggregates.CareerByPositionAgg;
using CaracolKnits.NETCore.Uteck.Services.Domain.Core;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.CareerAppServices
{
    public class CareerAppService : BaseAppService, ICareerAppService
    {
        public CareerAppService(IGenericRepository<IGenericDataContext> repository) : base(repository)
        {

        }

        public string Translate(string key, string language)
        {
            string value = Translations.CreateTranslation().GetTranslation(language, key);

            return value;
        }

        public async Task<List<CareerDTO>> GetAllCareerFiltered(CareerFilteredRequest request)
        {
            IEnumerable<Career> career = await _repository.GetFilteredAsync<Career>(x => x.FacilityId == request.FacilityId
                                                                                        && x.IsActive == true);

            List<CareerDTO> careerResponse = career.Select(x => new CareerDTO
            {
                CareerId = x.Id,
                Name = x.Name,
                Description = x.Description,
                FacilityId = x.FacilityId,
                ApprovalRate = x.NotaAprobacion,
                HasFollowUp = x.OscarSeguimiento,
                QuantityWeeksEnabled = x.NoSemanas,
                Units = new List<UnitDTO>(),
                Success = true,
            }).ToList();

            return careerResponse;
        }

        public async Task<Response> CreateCareer(CareerRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.Name, nameof(request.Name));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.Description, nameof(request.Description));
            ThrowIf.Argument.IsZeroOrNegative(request.FacilityId, nameof(request.FacilityId));
            ThrowIf.Argument.IsZeroOrNegative(request.NotaAprobacion, nameof(request.NotaAprobacion));

            Career career = await _repository.GetSingleAsync<Career>(x => x.Name == request.Name
                                                                    && x.FacilityId == request.FacilityId
                                                                    && x.IsActive == true);

            if (career != null)
            {
                return new Response
                {
                    ValidationErrorMessage = Translate(Translations.thereIsAlreadyACareerWithThatNameInThePlant, request.RequestUserInfo.Language)
                };
            }

            career = new()
            {
                Name = request.Name,
                Description = request.Description,
                FacilityId = request.FacilityId,
                NotaAprobacion = request.NotaAprobacion,
                OscarSeguimiento = request.OscarSeguimiento,
                NoSemanas = request.NoSemanas,
            };

            await _repository.AddAsync(career);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.createCareer);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);

            return new Response { Success = true };
        }

        public async Task<Response> ModifyCareer(CareerRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.Name, nameof(request.Name));
            ThrowIf.Argument.IsNullOrWhiteSpace(request.Description, nameof(request.Description));
            ThrowIf.Argument.IsZeroOrNegative(request.FacilityId, nameof(request.FacilityId));
            ThrowIf.Argument.IsZeroOrNegative(request.NotaAprobacion, nameof(request.NotaAprobacion));

            Career career = await _repository.GetSingleAsync<Career>(x => x.Id == request.CareerId
                                                                       && x.IsActive == true);
            if (career == null)
            {
                return new Response
                {
                    ValidationErrorMessage = Translate(Translations.careerDoesNotExist, request.RequestUserInfo.Language)
                };
            }

            if (career != null)
            {
                if (career.Name != request.Name)
                {
                    var careerNameIsSome = await _repository.GetSingleAsync<Career>(x => x.Name == request.Name
                                                                                 && x.FacilityId == request.FacilityId
                                                                                 && x.IsActive == true);
                    if (careerNameIsSome != null)
                    {
                        return new Response { ValidationErrorMessage = Translate(Translations.thereIsAlreadyACareerWithThatNameInThePlant, request.RequestUserInfo.Language) };
                    }
                }
            }

            career.Name = request.Name;
            career.Description = request.Description;
            career.FacilityId = request.FacilityId;
            career.NotaAprobacion = request.NotaAprobacion;
            career.OscarSeguimiento = request.OscarSeguimiento;
            career.NoSemanas = request.NoSemanas;

            _repository.Update(career);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.createCareer);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);

            return new Response { Success = true };
        }

        public async Task<List<CareerDTO>> GetCareerByPosition(PositionRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsZeroOrNegative(request.PositionId, nameof(request.PositionId));


            IEnumerable<CareerByPosition> careerByPosition = await _repository.GetFilteredAsync<CareerByPosition>(x =>
                                                          x.PositionId == request.PositionId && x.IsActive == true);

            var careerId = careerByPosition.Select(x => x.CareerId).ToList();

            IEnumerable<Career> careers = await _repository.GetFilteredAsync<Career>(i => careerId.Contains(i.Id) && i.IsActive == true);
            List<CareerDTO> careerByPositionResponse = careers.Select(x => new CareerDTO
            {
                CareerId = x.Id,
                Name = x.Name,
                Description = x.Description,
                FacilityId = x.FacilityId,
                ApprovalRate = x.NotaAprobacion,
                HasFollowUp = x.OscarSeguimiento,
                QuantityWeeksEnabled = x.NoSemanas,
                Units = new List<UnitDTO>(),
                Success = true,
            }).ToList();

            return careerByPositionResponse;
        }

        public async Task<Response> AssignCareerToPosition(AssignCareerToPositionListRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsNull(request.CareerToPositionList, nameof(request.CareerToPositionList));
            if (request.CareerToPositionList.Count == 0)
            {
                return new Response { ValidationErrorMessage = Translate(Translations.thereAreNoCareersToAssign, request.RequestUserInfo.Language) };
            }

            List<int> careerIds = request.CareerToPositionList.Select(i => i.CareerId).ToList();
            List<int> positionIds = request.CareerToPositionList.Select(i => i.PositionId).ToList();

            IEnumerable<CareerByPosition> careerByPosition = await _repository.GetFilteredAsync<CareerByPosition>(x =>
                                                             positionIds.Contains(x.PositionId)
                                                             && careerIds.Contains(x.CareerId)
                                                             && x.IsActive == true);
            if (careerByPosition.Any())
            {
                return new Response { ValidationErrorMessage = Translate(Translations.theseCareerAreAlreadyAssigned, request.RequestUserInfo.Language) };
            }

            careerByPosition = request.CareerToPositionList.Select(x => new CareerByPosition
            {
                PositionId = x.PositionId,
                CareerId = x.CareerId,
            });

            await _repository.AddRangeAsync(careerByPosition);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.assignCareerToPosition);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);
            return new Response { Success = true };
        }

        public async Task<Response> UnAssignCareerToPosition(AssignCareerToPositionListRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            if (request.CareerToPositionList.Count == 0)
            {
                return new Response { ValidationErrorMessage = Translate(Translations.thereAreNoCareersToAssign, request.RequestUserInfo.Language) };
            }

            List<int> careerIds = request.CareerToPositionList.Select(i => i.CareerId).ToList();
            List<int> positionIds = request.CareerToPositionList.Select(i => i.PositionId).ToList();

            IEnumerable<CareerByPosition> careerByPosition = await _repository.GetFilteredAsync<CareerByPosition>(x =>
                                                          positionIds.Contains(x.PositionId)
                                                          && careerIds.Contains(x.CareerId)
                                                          && x.IsActive == true);
            if (!careerByPosition.Any())
            {
                return new Response { ValidationErrorMessage = Translate(Translations.noCareersToUnassign, request.RequestUserInfo.Language) };
            }


            await _repository.RemoveRange(careerByPosition);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.assignCareerToPosition);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);
            return new Response { Success = true };
        }


        public async Task<Response> DeleteCareer(CareerRequest request)
        {
            ThrowIf.Argument.IsNull(request, nameof(request));
            ThrowIf.Argument.IsZeroOrNegative(request.CareerId, nameof(request.CareerId));

            Career career = await _repository.GetSingleAsync<Career>(x => x.Id == request.CareerId
                                                                       && x.IsActive == true);

            if (career == null)
            {
                return new Response { ValidationErrorMessage = Translate(Translations.careerDoesNotExist, request.RequestUserInfo.Language) };
            }


            career.IsActive = false;

            _repository.Update(career);
            TransactionInfo transactionInfo = TransactionInfoFactory.CrearTransactionInfo(request.RequestUserInfo, Transactions.createCareer);
            await _repository.UnitOfWork.CommitAsync(transactionInfo);

            return new Response { Success = true };
        }

    }
}
