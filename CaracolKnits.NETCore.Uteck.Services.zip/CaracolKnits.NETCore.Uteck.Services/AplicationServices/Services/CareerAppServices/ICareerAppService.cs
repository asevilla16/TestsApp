﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.CareerAppServices
{
    public interface ICareerAppService
    {
        Task<List<CareerDTO>> GetAllCareerFiltered(CareerFilteredRequest request);
        Task<Response> CreateCareer(CareerRequest request);
        Task<Response> ModifyCareer(CareerRequest request);
        Task<List<CareerDTO>> GetCareerByPosition(PositionRequest request);
        Task<Response> AssignCareerToPosition(AssignCareerToPositionListRequest request);
        Task<Response> UnAssignCareerToPosition(AssignCareerToPositionListRequest request);
        Task<Response> DeleteCareer(CareerRequest request);

    }
}
