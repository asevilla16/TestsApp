﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.ResourceAdvancementAppServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.Controllers.ResourceAdvancement
{
    [Route("api/resource-advancement")]
    [ApiController]
    public class ResourceAdvancementController : ControllerBase
    {
        private readonly IResourceAdvancementAppService _resourceAdvancmentAppService;

        public ResourceAdvancementController(IResourceAdvancementAppService resourceAdvancmentAppService)
        {
            _resourceAdvancmentAppService = resourceAdvancmentAppService;
        }

        [HttpPost]
        [Route("register-initial-date-resource")]
        public async Task<IActionResult> RegisterInitialDateUnit(ResourceAdvancementRequest request)
        {
            ResourceAdvancementDTO response = await _resourceAdvancmentAppService.RegisterInitialDateResource(request);

            return Ok(response);
        }

        [HttpPost]
        [Route("register-final-date-resource")]
        public async Task<IActionResult> RegisterFinalDateResource(ResourceAdvancementRequest request)
        {
            ResourceAdvancementDTO response = await _resourceAdvancmentAppService.RegisterFinalDateResource(request);

            return Ok(response);
        }

        [HttpPost]
        [Route("register-progress-resource")]
        public async Task<IActionResult> RegisterProgressResource(ResourceAdvancementRequest request)
        {
            ResourceAdvancementDTO response = await _resourceAdvancmentAppService.RegisterProgressResource(request);

            return Ok(response);
        }

    }
}
