﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.QuestionAppService;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.Controllers.Question
{
    [Route("api/[controller]")]
    [ApiController]
    public class QuestionController : ControllerBase
    {
        private readonly IQuestionAppService _questionAppServices;

        public QuestionController(IQuestionAppService questionAppServices)
        {
            _questionAppServices = questionAppServices;
        }

        //[HttpGet("get-all-questions-by-exam")]

        [HttpGet("get-question-types")]
        public async Task<IActionResult> GetQuestionTypes()
        {
            var result = await _questionAppServices.GetQuestionTypes();
            return Ok(result);
        }

        [HttpPost("save-question")]
        public async Task<IActionResult> SaveQuestion(QuestionRequest request)
        {
            var result = await _questionAppServices.CreateQuestionWithAnswers(request);
            return Ok(result);
        }


        [HttpPost("get-all-questions/{examId}")]
        public async Task<IActionResult> GetAllQuestions(int examId)
        {
            var result = await _questionAppServices.GetAllQuestions(examId);
            return Ok(result);
        }

    }
}
