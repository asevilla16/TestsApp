﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.UnitAdvancementAddServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.Controllers.UnitAdvancemente
{
    [Route("api/unit-advancement")]
    [ApiController]
    public class UnitAdvancementController : ControllerBase
    {
        private readonly IUnitAdvancementAppService _unitAdvancmentAppService;

        public UnitAdvancementController(IUnitAdvancementAppService unitAdvancmentAppService)
        {
            _unitAdvancmentAppService = unitAdvancmentAppService;
        }

        [HttpPost]
        [Route("get-unit-advancement-filtered")]
        public async Task<IActionResult> GetUnitAdvancementFiltered(UnitAdvancementRequest request)
        {
            List<UnitAdvancementDTO> response = await _unitAdvancmentAppService.GetUnitAdvancementFiltered(request);

            return Ok(response);
        }

        [HttpPost]
        [Route("register-initial-date-unit")]
        public async Task<IActionResult> RegisterInitialDateUnit(UnitAdvancementRequest request)
        {
            UnitAdvancementDTO response = await _unitAdvancmentAppService.RegisterInitialDateUnit(request);

            return Ok(response);
        }

        [HttpPost]
        [Route("register-final-date-unit")]
        public async Task<IActionResult> RegisterFinalDateUnit(UnitAdvancementRequest request)
        {
            UnitAdvancementDTO response = await _unitAdvancmentAppService.RegisterFinalDateUnit(request);

            return Ok(response);
        }

        [HttpPost]
        [Route("register-approval-note-unit")]
        public async Task<IActionResult> RegisterApprovalNoteUnit(UnitAdvancementRequest request)
        {
            UnitAdvancementDTO response = await _unitAdvancmentAppService.RegisterApprovalNoteUnit(request);

            return Ok(response);
        }

        [HttpPost]
        [Route("register-progress-unit")]
        public async Task<IActionResult> RegisterProgressUnit(UnitAdvancementRequest request)
        {
            UnitAdvancementDTO response = await _unitAdvancmentAppService.RegisterProgressUnit(request);

            return Ok(response);
        }
    }
}
