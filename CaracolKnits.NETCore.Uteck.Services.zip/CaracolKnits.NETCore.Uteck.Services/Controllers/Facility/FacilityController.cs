﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.FacilityAppServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.Controllers.Facility
{
    [Route("api/facility")]
    [ApiController]
    public class FacilityController : ControllerBase
    {
        private readonly IFacilityAppService _facilityAppServices;

        public FacilityController(IFacilityAppService facilityAppServices)
        {
            _facilityAppServices = facilityAppServices;
        }

        [HttpGet]
        [Route("all-facilities")]
        public async Task<IActionResult> GetAllFacilities()
        {
            List<FacilityDTO> response = await _facilityAppServices.GetAllFacilities();

            return Ok(response);
        }

        [HttpGet]
        [Route("all-facilities-with-position")]
        public async Task<IActionResult> GetAllFacilitiesWithPosition()
        {
            List<FacilityDTO> response = await _facilityAppServices.GetAllFacilitiesWithPosition();

            return Ok(response);
        }


        [HttpPost]
        [Route("create-facility")]
        public async Task<IActionResult> CreateFacility(FacilityRequest request)
        {
            Response response = await _facilityAppServices.CreateFacility(request);

            return Ok(response);
        }
    }
}
