﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.ExamMasterAppServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.Controllers.Exam
{
    [Route("api/exam")]
    [ApiController]
    public class ExamController : ControllerBase
    {
        private readonly IExamMasterAppService _examAppService;

        public ExamController(IExamMasterAppService examAppService)
        {
            _examAppService = examAppService;
        }

        [HttpGet]
        [Route("all-exams")]
        public async Task<IActionResult> GetAllExams()
        {
            List<ExamDTO> response = await _examAppService.GetAllExams();

            return Ok(response);
        }

        [HttpGet("get-exam-by-unit/{id}")]
        public async Task<IActionResult> GetExamByUnitId(int id)
        {
            ExamDTO res = await _examAppService.GetExamByUnitId(id);
            return Ok(res);
        }

        [HttpPost("create-exam")]
        public async Task<IActionResult> CreateExam(ExamRequest request)
        {
            Response response = await _examAppService.CreateExam(request);

            return Ok(response);
        }

        [HttpPost("open-exam")]
        public async Task<IActionResult> OpenExamAdvancement(ExamAdvancementRequest request)
        {
            ExamAdvancementDTO response = await _examAppService.OpenExamAdvancement(request);

            return Ok(response);
        }


        [HttpPost("close-exam")]
        public async Task<IActionResult> CloseExamAdvancement(ExamAdvancementRequest request)
        {
            ExamAdvancementDTO response = await _examAppService.CloseExamAdvancement(request);

            return Ok(response);
        }

    }
}
