﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.DetailQuestionAnswerAppServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.Controllers.DetailQuestionAnswer
{
    [Route("api/[controller]")]
    [ApiController]
    public class DetailQuestionAnswerController : ControllerBase
    {
        private readonly IDetailQuestionAnswerAppService _detailQuestionAnswerAppService;

        public DetailQuestionAnswerController(IDetailQuestionAnswerAppService detailQuestionAnswerAppService)
        {
            _detailQuestionAnswerAppService = detailQuestionAnswerAppService;
        }

        [HttpGet("get-questions-and-answers-by-exam/{examId}")]
        public async Task<IActionResult> GetDetailQuestionAndAnswersByExam(int examId)
        {
            var details = await _detailQuestionAnswerAppService.GetDetailQuestionAndAnswersByExam(examId);

            return Ok(details);
        }

        [HttpPost("save-questions-and-answers-by-exam")]
        public async Task<IActionResult> CreateDetailQuestionAndAnswers(List<DetailQuestionAnswerRequest> request)
        {
            var result = await _detailQuestionAnswerAppService.CreateDetailQuestionAndAnswers(request);

            return Ok(result);
        }

    }
}
