﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.ConfigurationAppServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.Controllers.Configuration
{
    [Route("api/configuration")]
    [ApiController]
    public class ConfigurationController : ControllerBase
    {
        private readonly IConfigurationAppService _configurationAppService;

        public ConfigurationController(IConfigurationAppService configurationAppService)
        {
            _configurationAppService = configurationAppService;
        }

        [HttpPost]
        [Route("create-configuration")]
        public async Task<IActionResult> CreateConfiguration(ConfigurationRequest request)
        {
            ConfigurationDTO response = await _configurationAppService.CreateConfiguration(request);

            return Ok(response);
        }
    }
}
