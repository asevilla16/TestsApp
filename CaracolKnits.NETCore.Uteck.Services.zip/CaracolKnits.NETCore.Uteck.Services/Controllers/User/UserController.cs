﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.UserAppService;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.Controllers.User
{
    [Route("api/user")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserAppService _userAppServices;

        public UserController(IUserAppService userAppService)
        {
            _userAppServices = userAppService;
        }

        [Authorize]
        [HttpGet]
        [Route("all-users")]
        public async Task<IActionResult> GetAllUsers()
        {
            var response = await  _userAppServices.GetAllUsers();
            return Ok(response);
        }

        
        [HttpPost]
        [Route("get-user")]
        public async Task<IActionResult> GetUser(UserRequest request)
        {
            var response = await _userAppServices.GetUser(request);
            return Ok(response);
        }

        [HttpPost]
        [Route("create-user")]
        public async Task<IActionResult> CreateUser(UserRequest request)
        {
            var response = await _userAppServices.CreateUser(request);
            return Ok(response);
        }

        [HttpPost]
        [Route("authenticate-user")]
        public async Task<IActionResult> AuthenticateUser(LoginRequest request)
        {
            var response = await _userAppServices.AuthenticateUser(request);
            return Ok(response);
        }

        [HttpPost]
        [Route("authenticate-automatic")]
        public async Task<IActionResult> AuthenticateAutomatic(AuthenticateAutomaticRequest request)
        {
            var response = await _userAppServices.AuthenticateAutomatic(request);
            return Ok(response);
        }

        [HttpPost]
        [Route("delete-user")]
        public async Task<IActionResult> DeleteUser(UserRequest request)
        {
            var response = await _userAppServices.DeleteUser(request);
            return Ok(response);
        }
    }
}
