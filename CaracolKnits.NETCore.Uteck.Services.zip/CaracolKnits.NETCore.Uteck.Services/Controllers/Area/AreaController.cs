﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.AreaAppServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.Controllers.Area
{
    [Route("api/area")]
    [ApiController]
    public class AreaController : ControllerBase
    {
        private readonly IAreaAppService _areaAppService;

        public AreaController(IAreaAppService areaAppService)
        {
            _areaAppService = areaAppService;
        }

        [HttpGet]
        [Route("all-areas")]
        public async Task<IActionResult> GetAllAreas()
        {
            List<AreaDTO> response = await _areaAppService.GetAllAreas();
            return Ok(response);
        }

        [HttpPost]
        [Route("create-area")]
        public async Task<IActionResult> CreateArea(AreaRequest request)
        {
            Response response = await _areaAppService.CreateArea(request);
            return Ok(response);
        }


    }
}
