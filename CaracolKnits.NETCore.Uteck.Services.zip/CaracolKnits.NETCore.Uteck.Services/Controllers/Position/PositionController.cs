﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.PositionAppServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.Controllers.Position
{
    [Route("api/position")]
    [ApiController]
    public class PositionController : ControllerBase
    {
        private readonly IPositionAppService _positionAppService;

        public PositionController(IPositionAppService positionAppService)
        {
            _positionAppService = positionAppService;
        }

        [HttpPost]
        [Route("create-position")]
        public async Task<IActionResult> CreateResource(PositionRequest request)
        {
            Response response = await _positionAppService.CreatePosition(request);

            return Ok(response);
        }

    }
}
