﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.RolAppServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.Controllers.Rol
{
    [Route("api/rol")]
    [ApiController]
    public class RolController : ControllerBase
    {
        private readonly IRolAppService _rolAppService;

        public RolController(IRolAppService rolAppService)
        {
            _rolAppService = rolAppService;
        }

        [HttpGet]
        [Route("all-roles")]
        public async Task<IActionResult> GetAllRoles()
        {
            List<RolDTO> response = await _rolAppService.GetAllRoles();

            return Ok(response);
        }

        [HttpPost]
        [Route("create-rol")]
        public async Task<IActionResult> CreateRol(RolRequest request)
        {
            Response response = await _rolAppService.CreateRol(request);

            return Ok(response);
        }

    }
}
