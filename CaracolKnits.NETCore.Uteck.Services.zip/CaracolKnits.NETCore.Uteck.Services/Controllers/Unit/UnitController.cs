﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.UnitAppServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.Controllers.Unit
{
    [Route("api/unit")]
    [ApiController]
    public class UnitController : ControllerBase
    {
        private readonly IUnitAppService _unitAppService;

        public UnitController(IUnitAppService unitAppService)
        {
            _unitAppService = unitAppService;
        }

        [HttpPost]
        [Route("get-units-filtered")]
        public async Task<IActionResult> GetUnitFiltered(UnitRequest request)
        {
            List<UnitDTO> response = await _unitAppService.GetUnitsFiltered(request);

            return Ok(response);
        }

        [HttpPost]
        [Route("create-unit")]
        public async Task<IActionResult> CreateUnit(UnitRequest request)
        {
            Response response = await _unitAppService.CreateUnit(request);

            return Ok(response);
        }

        [HttpPost]
        [Route("edit-unit")]
        public async Task<IActionResult> EditUnit(UnitRequest request)
        {
            Response response = await _unitAppService.EditUnit(request);

            return Ok(response);
        }

        [HttpPost]
        [Route("delete-unit")]
        public async Task<IActionResult> DeleteUnit(UnitRequest request)
        {
            Response response = await _unitAppService.DeleteUnit(request);

            return Ok(response);
        }
    }
}
