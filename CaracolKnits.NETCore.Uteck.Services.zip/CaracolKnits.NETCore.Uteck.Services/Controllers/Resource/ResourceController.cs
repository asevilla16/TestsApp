﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.ResourceAppServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.Controllers.Resource
{
    [Route("api/resource")]
    [ApiController]
    public class ResourceController : ControllerBase
    {
        private readonly IResourceAppService _resourceAppService;

        public ResourceController(IResourceAppService resourceAppService)
        {
            _resourceAppService = resourceAppService;
        }

        [HttpPost]
        [Route("create-resource")]
        public async Task<IActionResult> CreateResource(ResourceRequest request)
        {
            Response response = await _resourceAppService.CreateResource(request);

            return Ok(response);
        }

        [HttpPost]
        [Route("edit-resource")]
        public async Task<IActionResult> EditResource(ResourceRequest request)
        {
            Response response = await _resourceAppService.EditResource(request);

            return Ok(response);
        }

        [HttpPost]
        [Route("delete-resource")]
        public async Task<IActionResult> DeleteResource(ResourceRequest request)
        {
            Response response = await _resourceAppService.DeleteResource(request);

            return Ok(response);
        }
    }
}
