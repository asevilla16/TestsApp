﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.EnrollmentAppServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.Controllers.Enrollment
{
    [Route("api/enrollment")]
    [ApiController]
    public class EnrollmentController : ControllerBase
    {
        private readonly IEnrollmentAppServices _enrollmentAppService;

        public EnrollmentController(IEnrollmentAppServices enrollmentAppService)
        {
            _enrollmentAppService = enrollmentAppService;
        }

        [HttpPost]
        [Route("get-user-and-career-for-position")]
        public async Task<IActionResult> GetUserAndCareerForPositioonJob(CareersAndUsersByPositionJobRequest request)
        {
            List<CareersAndUsersByPositionJobDTO> response = await _enrollmentAppService.GetUserAndCareerForPositioonJob(request);

            return Ok(response);
        }

        [HttpPost]
        [Route("enrollment-masivie-of-career")]
        public async Task<IActionResult> EnrollmentMasivieOfCareer(EnrollMasiveRequest request)
        {
            List<EnrollmentMasiveDTO> response = await _enrollmentAppService.EnrollmentMasivieOfCareer(request);

            return Ok(response);
        }

    }
}
