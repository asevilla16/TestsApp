﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.CareerAppServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.Controllers.Career
{
    [Route("api/career")]
    [ApiController]
    public class CareerController : ControllerBase
    {
        private readonly ICareerAppService _careerAppService;

        public CareerController(ICareerAppService careerAppService)
        {
            _careerAppService = careerAppService;
        }


        [HttpPost]
        [Route("get-all-career-filtered")]
        public async Task<IActionResult> GetAllCareerFiltered(CareerFilteredRequest request)
        {
            List<CareerDTO> response = await _careerAppService.GetAllCareerFiltered(request);

            return Ok(response);
        }

        [HttpPost]
        [Route("create-career")]
        public async Task<IActionResult> CreateCareer(CareerRequest request)
        {
            Response response = await _careerAppService.CreateCareer(request);

            return Ok(response);
        }

        [HttpPost]
        [Route("modify-career")]
        public async Task<IActionResult> ModifyCareer(CareerRequest request)
        {
            Response response = await _careerAppService.ModifyCareer(request);

            return Ok(response);
        }

        [HttpPost]
        [Route("get-career-by-position")]
        public async Task<IActionResult> GetCareerByPosition(PositionRequest request)
        {
            List<CareerDTO> response = await _careerAppService.GetCareerByPosition(request);

            return Ok(response);
        }

        [HttpPost]
        [Route("assign-career-to-position")]
        public async Task<IActionResult> AssignCareerToPosition(AssignCareerToPositionListRequest request)
        {
            Response response = await _careerAppService.AssignCareerToPosition(request);

            return Ok(response);
        }

        [HttpPost]
        [Route("unassign-career-to-position")]
        public async Task<IActionResult> UnAssignCareerToPosition(AssignCareerToPositionListRequest request)
        {
            Response response = await _careerAppService.UnAssignCareerToPosition(request);

            return Ok(response);
        }

        [HttpPost]
        [Route("delete-career")]
        public async Task<IActionResult> DeleteCareer(CareerRequest request)
        {
            Response response = await _careerAppService.DeleteCareer(request);

            return Ok(response);
        }
    }
}
