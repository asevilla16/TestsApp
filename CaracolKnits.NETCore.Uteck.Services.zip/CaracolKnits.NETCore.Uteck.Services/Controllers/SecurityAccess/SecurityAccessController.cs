﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.SecurityAppServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.Controllers.SecurityAccess
{
    [Route("api/security-access")]
    [ApiController]
    public class SecurityAccessController : ControllerBase
    {
        private readonly ISecurityAppService _securityAppService;

        public SecurityAccessController(ISecurityAppService securityAppService)
        {
            _securityAppService = securityAppService;
        }

        [HttpGet]
        [Route("all-permission")]
        public async Task<IActionResult> GetAllPermission()
        {
            List<PermissionDTO> response = await _securityAppService.GetAllPermission();

            return Ok(response);
        }

        [HttpPost]
        [Route("create-permission")]
        public async Task<IActionResult> CreatePermission(PermissionRequest request)
        {
            PermissionDTO response = await _securityAppService.CreatePermission(request);

            return Ok(response);
        }

        [HttpPost]
        [Route("assign-permission-to-rol")]
        public async Task<IActionResult> AssignPermissionToRol(PermissionByRolRequest request)
        {
            PermissionByRolDTO response = await _securityAppService.AssignPermissionToRol(request);

            return Ok(response);
        }

    }
}
