﻿using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.DTOs;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Core.Requests;
using CaracolKnits.NETCore.Uteck.Services.AplicationServices.Services.CareerAdvancementAppServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CaracolKnits.NETCore.Uteck.Services.Controllers.CareerAdvancement
{
    [Route("api/career-advancement")]
    [ApiController]
    public class CareerAdvancementController : ControllerBase
    {
        private readonly ICareerAdvancementAppService _careerAdvancementAppService;

        public CareerAdvancementController(ICareerAdvancementAppService careerAdvancementAppService)
        {
            _careerAdvancementAppService = careerAdvancementAppService;
        }

        [HttpPost]
        [Route("get-career-advancement-filtered")]
        public async Task<IActionResult> GetCareerAdvancementFiltered(CareerAdvancementRequest request)
        {
            List<CareerAdvancementDTO> response = await _careerAdvancementAppService.GetCareerAdvancementByUser(request);

            return Ok(response);
        }

        [HttpPost]
        [Route("register-progress-career")]
        public async Task<IActionResult> RegisterProgressCareer(CareerAdvancementRequest request)
        {
            CareerAdvancementDTO response = await _careerAdvancementAppService.RegisterProgressCareer(request);

            return Ok(response);
        }
    }
}
